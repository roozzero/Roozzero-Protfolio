import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  FileText,
  Plus,
  BookOpen,
  Calendar,
  CheckCircle2,
  AlertCircle,
  Download,
  Github,
  Award,
  ChevronRight,
  MessageSquare,
  Upload,
  X,
  Sparkles
} from "lucide-react";
import { Assignment, Submission, Course, Session } from "../../types/teacher";

interface AssignmentsTabProps {
  assignments: Assignment[];
  courses: Course[];
  sessions: Session[];
  onCreateAssignment: (asg: Omit<Assignment, "id" | "submissions">) => void;
  onGradeSubmission: (asgId: string, subId: string, grade: number, feedback: string, correctedFile?: string) => void;
  showCustomToast: (msg: string, type?: "info" | "success" | "warning") => void;
}

export default function AssignmentsTab({
  assignments,
  courses,
  sessions,
  onCreateAssignment,
  onGradeSubmission,
  showCustomToast
}: AssignmentsTabProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [selectedCourseId, setSelectedCourseId] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [maxPoints, setMaxPoints] = useState("100");
  const [selectedSessionId, setSelectedSessionId] = useState("");

  const [activeAsgForGrading, setActiveAsgForGrading] = useState<Assignment | null>(null);
  const [selectedSubmission, setSelectedSubmission] = useState<Submission | null>(null);
  const [gradeScore, setGradeScore] = useState("");
  const [instructorFeedback, setInstructorFeedback] = useState("");
  const [correctedFile, setCorrectedFile] = useState<File | null>(null);

  // Advanced Filters States
  const [filterCourseId, setFilterCourseId] = useState("");
  const [filterAssignmentStatus, setFilterAssignmentStatus] = useState("");
  const [filterSubmissionStatus, setFilterSubmissionStatus] = useState("all");
  const [filterDeadline, setFilterDeadline] = useState("all");

  const handleClearFilters = () => {
    setFilterCourseId("");
    setFilterAssignmentStatus("");
    setFilterSubmissionStatus("all");
    setFilterDeadline("all");
    showCustomToast("All assignment filters have been reset.", "info");
  };

  const filteredAssignments = useMemo(() => {
    const todayStr = "2026-07-02"; // Standard simulation anchor date
    return assignments.filter((asg) => {
      // Course Filter
      if (filterCourseId && asg.courseId !== filterCourseId) {
        return false;
      }
      
      // Status Filter
      if (filterAssignmentStatus && asg.status !== filterAssignmentStatus) {
        return false;
      }

      // Submission Status Filter
      if (filterSubmissionStatus === "pending") {
        const hasPending = asg.submissions.some((sub) => sub.status === "Submitted");
        if (!hasPending) return false;
      } else if (filterSubmissionStatus === "fully-graded") {
        const hasPending = asg.submissions.some((sub) => sub.status === "Submitted");
        if (hasPending || asg.submissions.length === 0) return false;
      }

      // Deadline Filter
      const isOverdue = new Date(asg.dueDate) < new Date(todayStr) && asg.submissions.some((sub) => sub.status === "Submitted");
      const isUpcoming = new Date(asg.dueDate) >= new Date(todayStr);
      if (filterDeadline === "upcoming" && !isUpcoming) return false;
      if (filterDeadline === "overdue" && !isOverdue) return false;

      return true;
    });
  }, [assignments, filterCourseId, filterAssignmentStatus, filterSubmissionStatus, filterDeadline]);

  const stats = useMemo(() => {
    let published = assignments.length;
    let submitted = 0;
    let graded = 0;
    assignments.forEach((asg) => {
      asg.submissions.forEach((sub) => {
        if (sub.status === "Submitted") submitted++;
        if (sub.status === "Graded") graded++;
      });
    });
    return { published, submitted, graded };
  }, [assignments]);

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (title && selectedCourseId && dueDate) {
      const course = courses.find((c) => c.id === selectedCourseId);
      onCreateAssignment({
        title,
        description: desc,
        courseId: selectedCourseId,
        courseTitle: course ? course.title : "Academy Course",
        dueDate,
        publishDate: new Date().toISOString().split("T")[0],
        maxPoints: parseInt(maxPoints) || 100,
        status: "Published"
      });
      showCustomToast("Assignment published to syllabus feed!", "success");
      // Reset
      setTitle("");
      setDesc("");
      setSelectedCourseId("");
      setDueDate("");
      setMaxPoints("100");
      setSelectedSessionId("");
      setShowAddForm(false);
    }
  };

  const handleGradeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (activeAsgForGrading && selectedSubmission && gradeScore) {
      const score = parseInt(gradeScore);
      if (isNaN(score) || score < 0 || score > activeAsgForGrading.maxPoints) {
        showCustomToast(`Please enter a valid grade between 0 and ${activeAsgForGrading.maxPoints}`, "warning");
        return;
      }
      onGradeSubmission(
        activeAsgForGrading.id,
        selectedSubmission.id,
        score,
        instructorFeedback,
        correctedFile ? correctedFile.name : undefined
      );
      showCustomToast(`Grade registered successfully for ${selectedSubmission.studentName}!`, "success");
      // Reset
      setGradeScore("");
      setInstructorFeedback("");
      setCorrectedFile(null);
      setSelectedSubmission(null);
      setActiveAsgForGrading(null);
    }
  };

  const currentCourseSessions = useMemo(() => {
    if (!selectedCourseId) return [];
    return sessions.filter((s) => s.courseId === selectedCourseId);
  }, [selectedCourseId, sessions]);

  return (
    <div className="space-y-6 animate-fade-in text-left">
      {/* SECTION HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.04] pb-5">
        <div className="space-y-1">
          <h2 className="font-sans text-xl font-bold text-white uppercase tracking-wider">
            Curriculum Assignments
          </h2>
          <p className="font-sans text-xs text-white/40">
            Publish assessment specifications, trace student submissions, and write detailed performance reviews.
          </p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-sans font-extrabold text-[11px] tracking-widest uppercase transition-all shadow-[0_4px_15px_rgba(79,70,229,0.25)] cursor-pointer"
        >
          {showAddForm ? <X size={13} /> : <Plus size={13} />}
          <span>{showAddForm ? "Cancel Creation" : "Create Assignment"}</span>
        </button>
      </div>

      {/* STATISTICS BADGES */}
      <div className="grid grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-[#08080c]/90 border border-white/[0.04] text-center">
          <span className="block text-[10px] text-white/40 uppercase font-sans">Active Tasks</span>
          <span className="block text-xl font-mono font-bold text-white mt-1">{stats.published}</span>
        </div>
        <div className="p-4 rounded-2xl bg-[#08080c]/90 border border-white/[0.04] text-center">
          <span className="block text-[10px] text-white/40 uppercase font-sans">Awaiting Review</span>
          <span className="block text-xl font-mono font-bold text-amber-400 mt-1">{stats.submitted}</span>
        </div>
        <div className="p-4 rounded-2xl bg-[#08080c]/90 border border-white/[0.04] text-center">
          <span className="block text-[10px] text-white/40 uppercase font-sans">Evaluated Tasks</span>
          <span className="block text-xl font-mono font-bold text-emerald-400 mt-1">{stats.graded}</span>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {showAddForm ? (
          /* CREATE ASSIGNMENT FORM */
          <motion.div
            key="add-asg-form"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="p-6 rounded-3xl bg-[#08080c]/90 border border-white/[0.06] shadow-xl overflow-hidden"
          >
            <div className="flex items-center gap-2 border-b border-white/[0.04] pb-4 mb-5">
              <FileText size={16} className="text-indigo-400" />
              <h3 className="font-sans text-sm font-bold text-white uppercase tracking-wider">
                Publish New Assignment Guild Spec
              </h3>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-white/70 uppercase">Assignment Title</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Building custom state manager from scratch"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-white/20 focus:outline-none transition-colors duration-300 font-sans"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-white/70 uppercase">Select Target Course</label>
                  <select
                    required
                    value={selectedCourseId}
                    onChange={(e) => setSelectedCourseId(e.target.value)}
                    className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3.5 py-2.5 text-xs text-white/80 focus:outline-none transition-colors cursor-pointer"
                  >
                    <option value="">Choose Course...</option>
                    {courses.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.title}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-white/70 uppercase">Due Date</label>
                  <input
                    type="date"
                    required
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none transition-colors"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-white/70 uppercase">Maximum Evaluation Points</label>
                  <input
                    type="number"
                    required
                    value={maxPoints}
                    onChange={(e) => setMaxPoints(e.target.value)}
                    className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none transition-colors font-mono"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-white/70 uppercase">Related Masterclass Session</label>
                  <select
                    value={selectedSessionId}
                    onChange={(e) => setSelectedSessionId(e.target.value)}
                    disabled={!selectedCourseId}
                    className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3.5 py-2.5 text-xs text-white/80 focus:outline-none disabled:opacity-40 transition-colors cursor-pointer"
                  >
                    <option value="">None / Independent Task</option>
                    {currentCourseSessions.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.time} - {s.title}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-white/70 uppercase">Assignment Instructions</label>
                <textarea
                  placeholder="Provide precise assignment prompt, resource criteria, submission rules, and core evaluation matrices..."
                  rows={4}
                  value={desc}
                  onChange={(e) => setDesc(e.target.value)}
                  className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl p-3.5 text-xs text-white placeholder-white/20 focus:outline-none transition-colors duration-300 font-sans"
                />
              </div>

              <div className="pt-3 border-t border-white/[0.04] flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-4 py-2.5 rounded-xl border border-white/10 bg-white/[0.01] hover:bg-white/[0.04] text-xs font-bold text-white transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-sans font-bold text-xs transition-all shadow-[0_4px_15px_rgba(79,70,229,0.25)] cursor-pointer"
                >
                  Publish guidelines
                </button>
              </div>
            </form>
          </motion.div>
        ) : (
          /* ASSIGNMENTS LIST */
          <motion.div key="asg-list-panel" className="space-y-4">
            {/* ADVANCED FILTERS PANEL */}
            <div className="p-5 rounded-3xl bg-[#08080c]/90 border border-white/[0.05] space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/[0.03] pb-3">
                <div className="flex items-center gap-2">
                  <Sparkles size={14} className="text-indigo-400" />
                  <h4 className="font-sans text-xs font-bold text-white uppercase tracking-wider">
                    Advanced Filters
                  </h4>
                </div>
                {(filterCourseId || filterAssignmentStatus || filterSubmissionStatus !== "all" || filterDeadline !== "all") && (
                  <button
                    onClick={handleClearFilters}
                    className="px-3 py-1.5 rounded-xl border border-white/10 hover:border-white/20 bg-white/[0.01] hover:bg-[#0c0c14] text-[10px] font-extrabold text-white/70 hover:text-white uppercase tracking-widest transition-all cursor-pointer"
                  >
                    Clear Filters
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                {/* Course Selector */}
                <div className="space-y-1.5">
                  <label className="block text-[10px] text-white/50 font-bold uppercase tracking-wider">Course</label>
                  <select
                    value={filterCourseId}
                    onChange={(e) => setFilterCourseId(e.target.value)}
                    className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3.5 py-2 text-xs text-white/80 focus:outline-none transition-colors cursor-pointer"
                  >
                    <option value="">All Courses</option>
                    {courses.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.title}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Deadline Selector */}
                <div className="space-y-1.5">
                  <label className="block text-[10px] text-white/50 font-bold uppercase tracking-wider">Deadline</label>
                  <select
                    value={filterDeadline}
                    onChange={(e) => setFilterDeadline(e.target.value)}
                    className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3.5 py-2 text-xs text-white/80 focus:outline-none transition-colors cursor-pointer"
                  >
                    <option value="all">All Deadlines</option>
                    <option value="upcoming">Upcoming</option>
                    <option value="overdue">Overdue</option>
                  </select>
                </div>

                {/* Submission Status Selector */}
                <div className="space-y-1.5">
                  <label className="block text-[10px] text-white/50 font-bold uppercase tracking-wider">Submission Status</label>
                  <select
                    value={filterSubmissionStatus}
                    onChange={(e) => setFilterSubmissionStatus(e.target.value)}
                    className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3.5 py-2 text-xs text-white/80 focus:outline-none transition-colors cursor-pointer"
                  >
                    <option value="all">All Submissions</option>
                    <option value="pending">Awaiting Review</option>
                    <option value="fully-graded">Fully Graded</option>
                  </select>
                </div>

                {/* Assignment Publish Status Selector */}
                <div className="space-y-1.5">
                  <label className="block text-[10px] text-white/50 font-bold uppercase tracking-wider">Publish Status</label>
                  <select
                    value={filterAssignmentStatus}
                    onChange={(e) => setFilterAssignmentStatus(e.target.value)}
                    className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3.5 py-2 text-xs text-white/80 focus:outline-none transition-colors cursor-pointer"
                  >
                    <option value="">All Statuses</option>
                    <option value="Published">Published</option>
                    <option value="Draft">Draft</option>
                  </select>
                </div>
              </div>
            </div>

            {filteredAssignments.length === 0 ? (
              <div className="py-12 text-center text-white/30 font-sans text-xs bg-[#08080c]/90 border border-white/[0.05] rounded-3xl">
                No assignments match your selected filter options.
              </div>
            ) : (
              filteredAssignments.map((asg) => (
              <div
                key={asg.id}
                className="rounded-3xl bg-[#08080c]/90 border border-white/[0.05] p-5 space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 border-b border-white/[0.03] pb-3">
                  <div className="space-y-1 text-left">
                    <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/10">
                      {asg.courseTitle}
                    </span>
                    <h3 className="font-sans text-sm sm:text-base font-bold text-white mt-1">
                      {asg.title}
                    </h3>
                  </div>
                  <div className="text-left sm:text-right font-sans text-xs text-white/40">
                    <div className="flex items-center gap-1.5 sm:justify-end">
                      <Calendar size={12} className="text-indigo-400" />
                      <span>Due: <strong className="text-white/80">{asg.dueDate}</strong></span>
                    </div>
                    <span className="block text-[10px] mt-0.5">Max Score: <strong className="text-white/80 font-mono">{asg.maxPoints} pts</strong></span>
                  </div>
                </div>

                <p className="text-xs text-white/50 leading-relaxed text-left">
                  {asg.description}
                </p>

                {/* SUBMISSIONS SUMMARY SECTION */}
                <div className="space-y-2 text-xs">
                  <div className="flex items-center gap-1.5 text-white/40 font-semibold uppercase tracking-wider text-[10px]">
                    <CheckCircle2 size={12} className="text-emerald-400" />
                    <span>Student Submissions ({asg.submissions.length})</span>
                  </div>

                  {asg.submissions.length === 0 ? (
                    <p className="text-[11px] text-white/30 italic">No submissions registered yet for this assignment.</p>
                  ) : (
                    <div className="divide-y divide-white/[0.03] border border-white/[0.04] bg-white/[0.01] rounded-2xl overflow-hidden">
                      {asg.submissions.map((sub) => (
                        <div
                          key={sub.id}
                          className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 gap-3 hover:bg-white/[0.01] transition-colors"
                        >
                          <div className="flex items-center gap-2">
                            <div className="h-2 w-2 rounded-full bg-indigo-500" />
                            <div className="space-y-0.5 text-left">
                              <span className="font-bold text-white">{sub.studentName}</span>
                              <span className="block text-[9px] text-white/30">Submitted: {sub.submittedAt}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-3 self-start sm:self-center">
                            {sub.githubUrl && (
                              <a
                                href={sub.githubUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-black/40 border border-white/10 hover:border-white/20 text-[10px] font-mono text-white/70 hover:text-white transition-all cursor-pointer"
                              >
                                <Github size={11} />
                                <span>Repo</span>
                              </a>
                            )}
                            {sub.status === "Graded" ? (
                              <span className="px-2 py-1 rounded text-[10px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/15">
                                Graded: {sub.grade}/{asg.maxPoints}
                              </span>
                            ) : (
                              <button
                                onClick={() => {
                                  setActiveAsgForGrading(asg);
                                  setSelectedSubmission(sub);
                                }}
                                className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-sans font-bold text-[10px] tracking-wider uppercase transition-all cursor-pointer"
                              >
                                Evaluate Submission
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* EVALUATE SUBMISSION MODAL */}
      <AnimatePresence>
        {activeAsgForGrading && selectedSubmission && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#08080c] border border-white/10 rounded-3xl w-full max-w-lg p-6 relative overflow-hidden shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] max-h-[90vh] overflow-y-auto"
            >
              <button
                onClick={() => {
                  setSelectedSubmission(null);
                  setActiveAsgForGrading(null);
                }}
                className="absolute top-4 right-4 p-1.5 rounded-lg text-white/30 hover:text-white hover:bg-white/[0.04] transition-colors cursor-pointer"
              >
                <X size={15} />
              </button>

              <div className="flex items-center gap-2 border-b border-white/[0.04] pb-4 mb-5">
                <Award size={16} className="text-indigo-400" />
                <h3 className="font-sans text-sm font-bold text-white uppercase tracking-wider">
                  Grade Submission Report
                </h3>
              </div>

              <div className="space-y-4 text-xs text-left">
                <div className="p-3.5 rounded-2xl bg-white/[0.01] border border-white/[0.03] space-y-2">
                  <div className="flex justify-between items-center text-[10px] text-white/40 font-mono">
                    <span>Student: {selectedSubmission.studentName}</span>
                    <span>Task: {activeAsgForGrading.title}</span>
                  </div>
                  <p className="font-sans text-xs text-white/80 font-medium italic">
                    "{selectedSubmission.notes}"
                  </p>
                  {selectedSubmission.githubUrl && (
                    <a
                      href={selectedSubmission.githubUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-1.5 text-indigo-400 hover:text-indigo-300 transition-colors font-mono font-medium text-[11px]"
                    >
                      <Github size={12} />
                      <span>{selectedSubmission.githubUrl}</span>
                    </a>
                  )}
                </div>

                <form onSubmit={handleGradeSubmit} className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-semibold text-white/70 uppercase">Grade Score (Max {activeAsgForGrading.maxPoints})</label>
                    <input
                      type="number"
                      required
                      min={0}
                      max={activeAsgForGrading.maxPoints}
                      placeholder={`e.g. 95`}
                      value={gradeScore}
                      onChange={(e) => setGradeScore(e.target.value)}
                      className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-white/20 focus:outline-none font-mono"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-semibold text-white/70 uppercase">Instructor Feedback Note</label>
                    <textarea
                      required
                      placeholder="Write structural critiques, design suggestions, code optimization tips..."
                      rows={4}
                      value={instructorFeedback}
                      onChange={(e) => setInstructorFeedback(e.target.value)}
                      className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl p-3 text-xs text-white placeholder-white/20 focus:outline-none font-sans"
                    />
                  </div>

                  {/* Simulated attachment uploader */}
                  <div className="space-y-1.5">
                    <label className="block text-xs font-semibold text-white/70 uppercase">Corrected File Upload (Optional)</label>
                    <div className="border border-dashed border-white/10 hover:border-white/20 rounded-xl p-3.5 text-center bg-[#030304]/60 relative cursor-pointer">
                      <input
                        type="file"
                        onChange={(e) => {
                          if (e.target.files && e.target.files[0]) {
                            setCorrectedFile(e.target.files[0]);
                          }
                        }}
                        className="absolute inset-0 opacity-0 cursor-pointer"
                      />
                      <div className="flex flex-col items-center justify-center gap-1.5">
                        <Upload size={14} className="text-indigo-400" />
                        <span className="text-[10px] text-white/40">
                          {correctedFile ? `Selected: ${correctedFile.name}` : "Upload annotated file (PDF / ZIP)"}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-white/[0.04] flex items-center justify-end gap-3">
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedSubmission(null);
                        setActiveAsgForGrading(null);
                      }}
                      className="px-4 py-2.5 rounded-xl border border-white/10 bg-white/[0.01] hover:bg-white/[0.04] text-xs font-bold text-white transition-all cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-sans font-bold text-xs transition-all shadow-[0_4px_15px_rgba(16,185,129,0.25)] cursor-pointer"
                    >
                      Commit Evaluation
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
