import React, { useState } from "react";
import { motion } from "motion/react";
import { 
  Search, Filter, Plus, Edit2, Trash2, Shield, UserCheck, AlertTriangle, Key, Mail,
  GraduationCap, BookOpen, Users as UsersIcon, Award, SlidersHorizontal, ArrowRight, ToggleLeft
} from "lucide-react";
import { AdminUser } from "./types";
import { Student, Course } from "../../types/teacher";

interface UsersTabProps {
  users: AdminUser[];
  students: Student[];
  courses: Course[];
  activeSubTab?: string;
  onAddUser: (user: Partial<AdminUser>) => void;
  onUpdateUserStatus: (id: string, status: "Active" | "Suspended" | "Pending") => void;
  onResetPassword: (id: string) => void;
  onDeleteUser: (id: string) => void;
  onAddStudent: (student: Partial<Student>) => void;
}

export default function UsersTab({
  users,
  students,
  courses,
  activeSubTab,
  onAddUser,
  onUpdateUserStatus,
  onResetPassword,
  onDeleteUser,
  onAddStudent
}: UsersTabProps) {
  const [subTab, setSubTab] = useState<"all" | "students" | "teachers" | "admins">("all");

  React.useEffect(() => {
    if (activeSubTab && ["all", "students", "teachers", "admins"].includes(activeSubTab)) {
      setSubTab(activeSubTab as any);
    }
  }, [activeSubTab]);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  
  // Form states for creating users
  const [showAddModal, setShowAddModal] = useState(false);
  const [newUser, setNewUser] = useState<Partial<AdminUser>>({
    name: "",
    email: "",
    phone: "",
    role: "student",
    status: "Active"
  });

  const filteredUsers = users.filter(u => {
    // Search query matching
    const matchesSearch = u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          u.phone.includes(searchQuery);
    
    // Status filter
    const matchesStatus = statusFilter === "All" || u.status === statusFilter;

    // Sub-tab roles matching
    let matchesRole = true;
    if (subTab === "students") matchesRole = u.role === "student";
    else if (subTab === "teachers") matchesRole = u.role === "teacher";
    else if (subTab === "admins") matchesRole = u.role === "admin" || u.role === "super-admin";

    return matchesSearch && matchesStatus && matchesRole;
  });

  const handleCreateUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUser.name || !newUser.email) return;

    onAddUser(newUser);

    // If student role is chosen, also create student profile
    if (newUser.role === "student") {
      onAddStudent({
        id: "stu-" + Date.now(),
        name: newUser.name,
        email: newUser.email,
        phone: newUser.phone || "",
        progress: 0,
        attendance: 0,
        avgGrade: 0,
        status: "Active",
        joinedDate: new Date().toISOString().split("T")[0]
      });
    }

    setNewUser({ name: "", email: "", phone: "", role: "student", status: "Active" });
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Search & Filter tools */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-zinc-950/40 p-4 border border-white/[0.04] rounded-3xl">
        <div className="flex-1 flex flex-wrap gap-2">
          {/* Sub-tabs Selector */}
          {[
            { id: "all", label: "All Directory" },
            { id: "students", label: "Academy Students" },
            { id: "teachers", label: "LMS Instructors" },
            { id: "admins", label: "Administrators" }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => { setSubTab(tab.id as any); }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                subTab === tab.id 
                  ? "bg-indigo-500 text-white font-black" 
                  : "text-white/60 hover:text-white hover:bg-white/[0.02]"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-2">
          {/* Search Bar */}
          <div className="relative w-full sm:w-60">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40"><Search size={13} /></span>
            <input 
              type="text" 
              placeholder="Search by name, email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-zinc-900 border border-white/5 rounded-xl py-1.5 pl-8 pr-3 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Status Filter */}
          <select 
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full sm:w-32 bg-zinc-900 border border-white/5 rounded-xl py-1.5 px-3 text-xs text-white focus:outline-none focus:border-indigo-500"
          >
            <option value="All">All Status</option>
            <option value="Active">Active</option>
            <option value="Suspended">Suspended</option>
            <option value="Pending">Pending</option>
          </select>

          {/* Create User Button */}
          <button 
            onClick={() => setShowAddModal(true)}
            className="w-full sm:w-auto px-4 py-1.5 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-black text-xs font-bold transition-all flex items-center justify-center gap-1"
          >
            <Plus size={13} />
            <span>Create User</span>
          </button>
        </div>
      </div>

      {/* Directory Table View */}
      <div className="p-6 rounded-3xl border border-white/[0.06] bg-zinc-950/60 backdrop-blur-md overflow-x-auto text-left">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-white/[0.05] text-white/30 uppercase tracking-widest text-[9px] font-black">
              <th className="pb-3 font-black">Name & Contact</th>
              <th className="pb-3 font-black">System Role</th>
              <th className="pb-3 font-black">Status Indicator</th>
              {subTab === "students" && (
                <>
                  <th className="pb-3 font-black">LMS Progress</th>
                  <th className="pb-3 font-black text-center">Avg Grade</th>
                </>
              )}
              {subTab === "teachers" && (
                <>
                  <th className="pb-3 font-black">Instructed Courses</th>
                </>
              )}
              <th className="pb-3 font-black">Last System Login</th>
              <th className="pb-3 text-right font-black">Administrative Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/[0.02]">
            {filteredUsers.length === 0 ? (
              <tr>
                <td colSpan={8} className="text-center py-10 text-white/40">
                  No directory records matched your search parameters.
                </td>
              </tr>
            ) : (
              filteredUsers.map((user) => {
                // If student list, fetch matching profile info
                const studentProfile = students.find(s => s.email === user.email);

                return (
                  <tr key={user.id} className="hover:bg-white/[0.01] transition-colors">
                    <td className="py-4">
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-indigo-500 via-indigo-600 to-purple-600 flex items-center justify-center font-black text-white text-[11px] uppercase">
                          {user.name.substring(0, 2)}
                        </div>
                        <div>
                          <p className="font-extrabold text-white">{user.name}</p>
                          <p className="text-[10px] text-white/40">{user.email}</p>
                          {user.phone && <p className="text-[9px] text-indigo-400 font-mono mt-0.5">{user.phone}</p>}
                        </div>
                      </div>
                    </td>
                    <td className="py-4">
                      <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider ${
                        user.role === "super-admin"
                          ? "bg-rose-500/10 border border-rose-500/20 text-rose-400"
                          : user.role === "admin"
                          ? "bg-purple-500/10 border border-purple-500/20 text-purple-400"
                          : user.role === "teacher"
                          ? "bg-indigo-500/10 border border-indigo-500/20 text-indigo-400"
                          : "bg-emerald-500/10 border border-emerald-500/20 text-emerald-400"
                      }`}>
                        {user.role}
                      </span>
                    </td>
                    <td className="py-4">
                      <span className={`flex items-center gap-1.5 text-[10px] font-bold ${
                        user.status === "Active"
                          ? "text-emerald-400"
                          : user.status === "Suspended"
                          ? "text-rose-400"
                          : "text-amber-400"
                      }`}>
                        <span className={`h-1.5 w-1.5 rounded-full ${
                          user.status === "Active"
                            ? "bg-emerald-400 animate-pulse"
                            : user.status === "Suspended"
                            ? "bg-rose-400"
                            : "bg-amber-400"
                        }`} />
                        {user.status}
                      </span>
                    </td>

                    {/* Conditional sub-tab metadata */}
                    {subTab === "students" && (
                      <>
                        <td className="py-4 min-w-[120px]">
                          {studentProfile ? (
                            <div className="space-y-1 max-w-[120px]">
                              <div className="flex justify-between text-[9px] font-mono text-white/40">
                                <span>Progress</span>
                                <span>{studentProfile.progress}%</span>
                              </div>
                              <div className="h-1 w-full bg-white/[0.05] rounded-full overflow-hidden">
                                <div className="h-full bg-emerald-400 rounded-full" style={{ width: `${studentProfile.progress}%` }} />
                              </div>
                              <p className="text-[9px] text-white/30 truncate">{studentProfile.courseTitle}</p>
                            </div>
                          ) : (
                            <span className="text-white/30">No profile link</span>
                          )}
                        </td>
                        <td className="py-4 text-center font-mono font-bold text-emerald-400">
                          {studentProfile ? `${studentProfile.avgGrade}%` : "-"}
                        </td>
                      </>
                    )}

                    {subTab === "teachers" && (
                      <td className="py-4 max-w-[180px] truncate">
                        <span className="text-white/70">
                          {user.email === "teacher@academy.local" ? "React, Typography" : "LMS Operations"}
                        </span>
                      </td>
                    )}

                    <td className="py-4 font-mono text-white/40 text-[10px]">
                      {user.lastLogin || "Never"}
                    </td>

                    <td className="py-4 text-right">
                      <div className="flex justify-end gap-1.5">
                        {/* Toggle Status button */}
                        <button 
                          onClick={() => onUpdateUserStatus(user.id, user.status === "Active" ? "Suspended" : "Active")}
                          className="p-1.5 rounded-lg bg-white/[0.02] border border-white/[0.04] text-white/50 hover:text-white hover:bg-white/[0.05] transition-all"
                          title={user.status === "Active" ? "Suspend Account" : "Activate Account"}
                        >
                          <UserCheck size={11} />
                        </button>
                        
                        {/* Reset Password */}
                        <button 
                          onClick={() => onResetPassword(user.id)}
                          className="p-1.5 rounded-lg bg-white/[0.02] border border-white/[0.04] text-white/50 hover:text-amber-400 hover:bg-amber-500/10 transition-all"
                          title="Reset Password"
                        >
                          <Key size={11} />
                        </button>

                        {/* Delete User */}
                        {user.role !== "super-admin" && (
                          <button 
                            onClick={() => onDeleteUser(user.id)}
                            className="p-1.5 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400 hover:bg-rose-500 hover:text-black transition-all"
                            title="Delete User"
                          >
                            <Trash2 size={11} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Slide-over Modal: Create New User */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-50 p-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md bg-[#0d0d12] border border-white/10 rounded-3xl p-6 text-left space-y-4"
          >
            <div className="flex justify-between items-center border-b border-white/[0.05] pb-3">
              <h3 className="text-xs font-black text-white uppercase tracking-wider">Create New Academy User</h3>
              <button onClick={() => setShowAddModal(false)} className="text-white/40 hover:text-white"><Plus className="rotate-45" size={16} /></button>
            </div>

            <form onSubmit={handleCreateUserSubmit} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-[9px] text-white/40 uppercase font-black tracking-widest">Full Name</label>
                <input 
                  type="text" 
                  required
                  placeholder="e.g. Liam Peterson"
                  value={newUser.name}
                  onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                  className="w-full bg-zinc-900 border border-white/10 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[9px] text-white/40 uppercase font-black tracking-widest">Email Address</label>
                <input 
                  type="email" 
                  required
                  placeholder="liam@academy.local"
                  value={newUser.email}
                  onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                  className="w-full bg-zinc-900 border border-white/10 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[9px] text-white/40 uppercase font-black tracking-widest">Phone Number</label>
                <input 
                  type="text" 
                  placeholder="+1 (555) 987-6543"
                  value={newUser.phone}
                  onChange={(e) => setNewUser({ ...newUser, phone: e.target.value })}
                  className="w-full bg-zinc-900 border border-white/10 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[9px] text-white/40 uppercase font-black tracking-widest">LMS Role</label>
                  <select
                    value={newUser.role}
                    onChange={(e) => setNewUser({ ...newUser, role: e.target.value as any })}
                    className="w-full bg-zinc-900 border border-white/10 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="student">Student</option>
                    <option value="teacher">Instructor</option>
                    <option value="admin">Administrator</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] text-white/40 uppercase font-black tracking-widest">Status</label>
                  <select
                    value={newUser.status}
                    onChange={(e) => setNewUser({ ...newUser, status: e.target.value as any })}
                    className="w-full bg-zinc-900 border border-white/10 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Active">Active</option>
                    <option value="Pending">Pending</option>
                    <option value="Suspended">Suspended</option>
                  </select>
                </div>
              </div>

              <div className="bg-amber-500/10 border border-amber-500/20 p-3 rounded-2xl flex gap-3 text-amber-400">
                <AlertTriangle size={15} className="shrink-0 mt-0.5" />
                <p className="text-[10px] leading-relaxed">
                  Default login password for the created credentials will be set as <span className="font-mono font-bold text-white bg-black/40 px-1 rounded">Academy@123</span>. User will be forced to rotate password upon first authorization.
                </p>
              </div>

              <div className="pt-3 flex gap-2">
                <button 
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-indigo-500 text-black font-bold tracking-wider uppercase hover:bg-indigo-400 transition-all flex items-center justify-center gap-1.5"
                >
                  <UserCheck size={14} />
                  <span>Authorize User</span>
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

    </div>
  );
}
