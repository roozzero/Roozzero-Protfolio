import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Users,
  Search,
  Filter,
  Eye,
  Mail,
  Phone,
  MessageSquare,
  GraduationCap,
  Calendar,
  X,
  Plus,
  Trash2,
  ChevronLeft,
  ChevronRight,
  MoreVertical
} from "lucide-react";
import { Student } from "../../types/teacher";

interface StudentsTabProps {
  students: Student[];
  onSendMessage: (studentName: string) => void;
  onGradeStudent: (studentId: string, grade: number) => void;
}

export default function StudentsTab({
  students,
  onSendMessage,
  onGradeStudent
}: StudentsTabProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [courseFilter, setCourseFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [messageText, setMessageText] = useState("");

  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      const matchSearch =
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.email.toLowerCase().includes(searchQuery.toLowerCase());
      const matchCourse = courseFilter === "all" || s.courseId === courseFilter;
      const matchStatus = statusFilter === "all" || s.status.toLowerCase() === statusFilter;
      return matchSearch && matchCourse && matchStatus;
    });
  }, [students, searchQuery, courseFilter, statusFilter]);

  // Pagination
  const totalPages = Math.ceil(filteredStudents.length / itemsPerPage) || 1;
  const paginatedStudents = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredStudents.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredStudents, currentPage]);

  const uniqueCourses = useMemo(() => {
    const coursesMap = new Map();
    students.forEach((s) => coursesMap.set(s.courseId, s.courseTitle));
    return Array.from(coursesMap.entries()).map(([id, title]) => ({ id, title }));
  }, [students]);

  const handleMessageSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (messageText && selectedStudent) {
      onSendMessage(selectedStudent.name);
      setMessageText("");
    }
  };

  return (
    <div className="space-y-6 animate-fade-in text-left">
      {/* SECTION HEADER */}
      <div className="border-b border-white/[0.04] pb-5">
        <h2 className="font-sans text-xl font-bold text-white uppercase tracking-wider">
          Enrolled Academy Students
        </h2>
        <p className="font-sans text-xs text-white/40">
          Conduct performance evaluations, monitor daily attendance percentages, and issue targeted warnings.
        </p>
      </div>

      {/* FILTER & SEARCH BAR */}
      <div className="flex flex-col xl:flex-row gap-4 items-center justify-between">
        {/* Search */}
        <div className="relative w-full xl:w-96 select-none">
          <Search size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30 pointer-events-none" />
          <input
            type="text"
            placeholder="Search students by name or email..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full bg-[#08080c]/90 border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl pl-11 pr-4 py-2.5 text-xs text-white placeholder-white/20 focus:outline-none transition-all duration-300 font-sans font-normal"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3 w-full xl:w-auto">
          <div className="flex items-center gap-2 px-3 py-2 bg-white/[0.02] border border-white/[0.06] rounded-xl text-white/40 text-xs">
            <Filter size={12} />
            <span className="font-semibold">Filters:</span>
          </div>

          <select
            value={courseFilter}
            onChange={(e) => {
              setCourseFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="bg-[#08080c] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white/80 hover:text-white focus:outline-none focus:border-indigo-500 transition-colors cursor-pointer"
          >
            <option value="all">All Courses</option>
            {uniqueCourses.map((c) => (
              <option key={c.id} value={c.id}>
                {c.title}
              </option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="bg-[#08080c] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white/80 hover:text-white focus:outline-none focus:border-indigo-500 transition-colors cursor-pointer"
          >
            <option value="all">All Statuses</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>

      {/* STUDENTS TABLE */}
      <div className="bg-[#08080c]/90 border border-white/[0.05] rounded-3xl overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse font-sans text-xs">
            <thead>
              <tr className="border-b border-white/[0.04] bg-white/[0.01]">
                <th className="py-4 px-6 text-[10px] font-bold text-white/40 uppercase tracking-wider">Student Name</th>
                <th className="py-4 px-6 text-[10px] font-bold text-white/40 uppercase tracking-wider">Course</th>
                <th className="py-4 px-6 text-[10px] font-bold text-white/40 uppercase tracking-wider">Attendance</th>
                <th className="py-4 px-6 text-[10px] font-bold text-white/40 uppercase tracking-wider">Average Grade</th>
                <th className="py-4 px-6 text-[10px] font-bold text-white/40 uppercase tracking-wider">Status</th>
                <th className="py-4 px-6 text-[10px] font-bold text-white/40 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.03]">
              {paginatedStudents.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-white/30 font-sans text-xs">
                    No students match the selected filter criteria.
                  </td>
                </tr>
              ) : (
                paginatedStudents.map((student) => (
                  <tr key={student.id} className="hover:bg-white/[0.01] transition-colors group">
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                        <div className="h-9 w-9 rounded-full bg-gradient-to-tr from-indigo-500/20 via-purple-500/10 to-transparent border border-white/10 flex items-center justify-center font-sans font-bold text-indigo-300">
                          {student.name.split(" ").map((n) => n[0]).join("")}
                        </div>
                        <div className="space-y-0.5">
                          <h4 className="font-semibold text-white group-hover:text-indigo-400 transition-colors">
                            {student.name}
                          </h4>
                          <span className="block text-[10px] text-white/30 font-mono">{student.email}</span>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6 text-white/70">
                      <div className="space-y-0.5">
                        <span className="block font-medium">{student.courseTitle}</span>
                        <span className="block text-[9px] text-white/30">Joined: {student.joinedDate}</span>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-2">
                        <div className="w-16 bg-white/[0.02] border border-white/[0.04] rounded-full h-1.5 overflow-hidden">
                          <div
                            className={`h-full rounded-full ${student.attendance >= 90 ? "bg-emerald-500" : student.attendance >= 80 ? "bg-indigo-500" : "bg-amber-500"}`}
                            style={{ width: `${student.attendance}%` }}
                          />
                        </div>
                        <span className="font-mono font-bold text-white/80">{student.attendance}%</span>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`font-mono font-bold px-2 py-0.5 rounded text-[10px] ${student.avgGrade >= 90 ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/15" : student.avgGrade >= 80 ? "bg-indigo-500/10 text-indigo-400 border border-indigo-500/15" : student.avgGrade > 0 ? "bg-amber-500/10 text-amber-400 border border-amber-500/15" : "bg-white/[0.02] text-white/30 border border-white/5"}`}>
                        {student.avgGrade > 0 ? `${student.avgGrade}%` : "N/A"}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-sans font-extrabold tracking-widest uppercase border ${student.status === "Active" ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : "bg-white/[0.02] border-white/10 text-white/30"}`}>
                        {student.status}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setSelectedStudent(student)}
                          className="p-2 rounded-lg text-white/40 hover:text-white hover:bg-white/[0.04] transition-all cursor-pointer"
                          title="Evaluate Student Profile"
                        >
                          <Eye size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* PAGINATION PANEL */}
        <div className="flex items-center justify-between border-t border-white/[0.04] p-4 bg-white/[0.01]">
          <span className="text-[10px] font-sans font-semibold text-white/30">
            Showing Page {currentPage} of {totalPages}
          </span>
          <div className="flex items-center gap-1">
            <button
              disabled={currentPage === 1}
              onClick={() => setCurrentPage((p) => p - 1)}
              className="p-1.5 rounded-lg border border-white/10 bg-white/[0.01] hover:bg-white/[0.04] text-white/50 hover:text-white disabled:opacity-30 disabled:pointer-events-none transition-all cursor-pointer"
            >
              <ChevronLeft size={13} />
            </button>
            <button
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage((p) => p + 1)}
              className="p-1.5 rounded-lg border border-white/10 bg-white/[0.01] hover:bg-white/[0.04] text-white/50 hover:text-white disabled:opacity-30 disabled:pointer-events-none transition-all cursor-pointer"
            >
              <ChevronRight size={13} />
            </button>
          </div>
        </div>
      </div>

      {/* STUDENT PROFILE EVALUATION MODAL */}
      <AnimatePresence>
        {selectedStudent && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#08080c] border border-white/10 rounded-3xl w-full max-w-2xl p-6 relative overflow-hidden shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] max-h-[90vh] overflow-y-auto space-y-6"
            >
              {/* Close */}
              <button
                onClick={() => setSelectedStudent(null)}
                className="absolute top-4 right-4 p-1.5 rounded-lg text-white/30 hover:text-white hover:bg-white/[0.04] transition-colors cursor-pointer"
              >
                <X size={15} />
              </button>

              {/* Modal Header */}
              <div className="flex items-center gap-4 border-b border-white/[0.04] pb-4">
                <div className="h-14 w-14 rounded-2xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-transparent p-[1px] flex items-center justify-center shadow-lg">
                  <div className="h-full w-full rounded-2xl bg-[#08080c] flex items-center justify-center font-sans font-bold text-lg text-indigo-400">
                    {selectedStudent.name.split(" ").map((n) => n[0]).join("")}
                  </div>
                </div>
                <div className="space-y-1">
                  <h3 className="font-sans text-base sm:text-lg font-black text-white leading-none">
                    {selectedStudent.name}
                  </h3>
                  <p className="font-sans text-xs text-white/40">
                    Student ID: <span className="font-mono text-indigo-300">{selectedStudent.id}</span>
                  </p>
                </div>
              </div>

              {/* Profile Details Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-left">
                {/* Information Card */}
                <div className="p-4 rounded-2xl border border-white/[0.04] bg-white/[0.01] space-y-3.5">
                  <h4 className="font-sans text-[11px] font-bold text-indigo-400 uppercase tracking-widest border-b border-white/[0.03] pb-1.5">
                    Academics Profile
                  </h4>
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-white/40">Registered Course:</span>
                      <span className="font-medium text-white/90">{selectedStudent.courseTitle}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-white/40">Registered Phone:</span>
                      <span className="font-mono text-white/80">{selectedStudent.phone}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-white/40">Registered Email:</span>
                      <span className="font-mono text-white/80">{selectedStudent.email}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-white/40">Enrolled Date:</span>
                      <span className="text-white/80">{selectedStudent.joinedDate}</span>
                    </div>
                  </div>
                </div>

                {/* Score Indicators */}
                <div className="p-4 rounded-2xl border border-white/[0.04] bg-white/[0.01] space-y-3.5">
                  <h4 className="font-sans text-[11px] font-bold text-emerald-400 uppercase tracking-widest border-b border-white/[0.03] pb-1.5">
                    Metric Performance
                  </h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-xl bg-white/[0.01] border border-white/[0.03] text-center">
                      <span className="block text-[10px] text-white/40 uppercase">Attendance</span>
                      <span className="block text-lg font-mono font-bold text-white mt-1">
                        {selectedStudent.attendance}%
                      </span>
                    </div>
                    <div className="p-3 rounded-xl bg-white/[0.01] border border-white/[0.03] text-center">
                      <span className="block text-[10px] text-white/40 uppercase">Avg Grade</span>
                      <span className="block text-lg font-mono font-bold text-indigo-400 mt-1">
                        {selectedStudent.avgGrade > 0 ? `${selectedStudent.avgGrade}%` : "N/A"}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Modal Forms Column */}
              <div className="border-t border-white/[0.04] pt-6">
                {/* Message form */}
                <form onSubmit={handleMessageSubmit} className="space-y-3 max-w-lg mx-auto">
                  <h4 className="font-sans text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <MessageSquare size={13} className="text-indigo-400" />
                    <span>Send Student Notice</span>
                  </h4>
                  <textarea
                    required
                    placeholder="Enter urgent notification text..."
                    rows={3}
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl p-3 text-xs text-white placeholder-white/20 focus:outline-none transition-all duration-300 font-sans"
                  />
                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-sans font-bold text-xs transition-all cursor-pointer"
                  >
                    Send Notice
                  </button>
                </form>
              </div>

              {/* Close Footer */}
              <div className="border-t border-white/[0.04] pt-4 flex items-center justify-end">
                <button
                  onClick={() => setSelectedStudent(null)}
                  className="px-4 py-2 rounded-xl border border-white/10 bg-white/[0.01] hover:bg-white/[0.04] text-xs font-bold text-white transition-all cursor-pointer"
                >
                  Dismiss Profile
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
