import React, { useState } from "react";
import { motion } from "motion/react";
import { 
  Megaphone, Calendar, BarChart3, ShieldCheck, Activity, Plus, Search,
  Check, X, FileText, Download, Sliders, ArrowRight, Shield, RefreshCw, Key
} from "lucide-react";
import { ActivityLog, RolePermission } from "./AdminDashboard/types";
import { Announcement, CalendarEvent } from "../types/teacher";

interface ServicesTabProps {
  announcements: Announcement[];
  calendarEvents: CalendarEvent[];
  logs: ActivityLog[];
  roles: RolePermission[];
  activeSubTab?: string;
  onAddAnnouncement: (ann: Announcement) => void;
  onDeleteAnnouncement: (id: string) => void;
  onAddCalendarEvent: (event: CalendarEvent) => void;
  onUpdateRolePermissions: (roleName: string, permissionName: string, value: boolean) => void;
}

export default function ServicesTab({
  announcements,
  calendarEvents,
  logs,
  roles,
  activeSubTab,
  onAddAnnouncement,
  onDeleteAnnouncement,
  onAddCalendarEvent,
  onUpdateRolePermissions
}: ServicesTabProps) {
  const [subTab, setSubTab] = useState<"announcements" | "calendar" | "analytics" | "permissions" | "logs">("announcements");

  React.useEffect(() => {
    if (activeSubTab && ["announcements", "calendar", "analytics", "permissions", "logs"].includes(activeSubTab)) {
      setSubTab(activeSubTab as any);
    }
  }, [activeSubTab]);
  
  // Announcements form
  const [showAnnModal, setShowAnnModal] = useState(false);
  const [newAnn, setNewAnn] = useState({
    title: "",
    content: "",
    target: "Everyone"
  });

  // Export progress overlay
  const [exportProgress, setExportProgress] = useState<string | null>(null);

  // Active Role filter for permissions
  const [selectedRole, setSelectedRole] = useState("super-admin");

  // Logs search and pagination
  const [logsQuery, setLogsQuery] = useState("");

  const handleCreateAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAnn.title || !newAnn.content) return;

    onAddAnnouncement({
      id: "ann-" + Date.now(),
      title: newAnn.title,
      description: newAnn.content,
      courseId: "all",
      courseTitle: "All Courses",
      audience: newAnn.target,
      publishedAt: new Date().toISOString().split("T")[0],
      status: "Published"
    });

    setNewAnn({ title: "", content: "", target: "Everyone" });
    setShowAnnModal(false);
  };

  const handleSimulateExport = (format: string) => {
    setExportProgress("Compiling LMS metadata and generating " + format + " file structure...");
    setTimeout(() => {
      setExportProgress("Optimizing analytics arrays...");
      setTimeout(() => {
        setExportProgress(null);
        // Download simulation
        const dataStr = "data:text/csv;charset=utf-8,LMS PERFORMANCE REPORT\nYear,Enrolled,Revenue,PassRate\n2026,184,$42500,94%\n";
        const downloadAnchor = document.createElement("a");
        downloadAnchor.setAttribute("href", encodeURI(dataStr));
        downloadAnchor.setAttribute("download", `academy_lms_report_${Date.now()}.${format.toLowerCase()}`);
        document.body.appendChild(downloadAnchor);
        downloadAnchor.click();
        downloadAnchor.remove();
      }, 800);
    }, 1200);
  };

  const filteredLogs = logs.filter(log => 
    log.username.toLowerCase().includes(logsQuery.toLowerCase()) ||
    log.action.toLowerCase().includes(logsQuery.toLowerCase()) ||
    log.module.toLowerCase().includes(logsQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      
      {/* Sub tabs switcher */}
      <div className="flex border-b border-white/[0.05] gap-6 text-xs">
        {[
          { id: "announcements", label: "Announcements Composer" },
          { id: "calendar", label: "Academy Calendar" },
          { id: "analytics", label: "Reports & Analytics" },
          { id: "permissions", label: "Roles & Permissions (RBAC)" },
          { id: "logs", label: "System Activity Audit" }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSubTab(tab.id as any)}
            className={`pb-3 font-extrabold tracking-wider uppercase transition-all relative ${
              subTab === tab.id 
                ? "text-indigo-400" 
                : "text-white/40 hover:text-white"
            }`}
          >
            {tab.label}
            {subTab === tab.id && (
              <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-indigo-400" />
            )}
          </button>
        ))}
      </div>

      {/* SUB-TAB: ANNOUNCEMENTS COMPOSER */}
      {subTab === "announcements" && (
        <div className="space-y-4 text-left">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider">Rich Announcements Board</h3>
              <p className="text-[10px] text-white/40">Broadcast priority alerts, holidays schedule, and general notifications to targeted cohorts.</p>
            </div>
            <button 
              onClick={() => setShowAnnModal(true)}
              className="px-4 py-1.5 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-black text-xs font-bold transition-all flex items-center gap-1"
            >
              <Plus size={13} />
              <span>Compose Announcement</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {announcements.map((ann) => (
              <div 
                key={ann.id}
                className="p-5 rounded-3xl border border-white/[0.04] bg-zinc-950/60 backdrop-blur-md flex flex-col justify-between hover:border-white/[0.08] transition-all relative"
              >
                <div className="space-y-2.5">
                  <div className="flex justify-between items-center text-[9px] font-mono">
                    <span className="px-2 py-0.5 rounded uppercase bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-bold">
                      Target: {ann.audience}
                    </span>
                    <span className="text-white/30">{ann.publishedAt}</span>
                  </div>

                  <h4 className="font-extrabold text-white text-xs">{ann.title}</h4>
                  <p className="text-[11px] text-white/50 leading-relaxed font-sans">{ann.description}</p>
                </div>

                <div className="mt-4 pt-4 border-t border-white/[0.04] flex justify-end">
                  <button 
                    onClick={() => onDeleteAnnouncement(ann.id)}
                    className="p-1.5 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400 hover:bg-rose-500 hover:text-black transition-all"
                    title="Delete Broadcast"
                  >
                    <Download className="rotate-45" size={11} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB: ACADEMY CALENDAR */}
      {subTab === "calendar" && (
        <div className="space-y-4 text-left">
          <div>
            <h3 className="text-sm font-black text-white uppercase tracking-wider">Academy Scheduler Calendar</h3>
            <p className="text-[10px] text-white/40">Oversee, track, and register crucial milestones, assignment deadlines, holidays, and live sessions.</p>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
            {/* Calendar grid mockup (7 cols) */}
            <div className="xl:col-span-8 p-6 rounded-3xl border border-white/[0.06] bg-zinc-950/60 backdrop-blur-md space-y-4">
              <div className="flex justify-between items-center text-xs">
                <h4 className="font-extrabold text-white uppercase tracking-wider">July 2026</h4>
                <div className="flex gap-1">
                  {["Month", "Week", "Day"].map((mode) => (
                    <button key={mode} className="px-2.5 py-1 rounded bg-white/[0.02] border border-white/5 text-white/60 hover:text-white text-[10px] font-bold">
                      {mode}
                    </button>
                  ))}
                </div>
              </div>

              {/* Grid dates */}
              <div className="grid grid-cols-7 gap-1 text-center font-mono text-[9px] text-white/30 uppercase pb-2 border-b border-white/[0.05]">
                <span>Sun</span><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span>
              </div>
              <div className="grid grid-cols-7 gap-1.5 h-[300px] text-left">
                {Array.from({ length: 35 }).map((_, idx) => {
                  const dayNum = idx - 2; // Simulated offsets
                  const isCurrentMonth = dayNum > 0 && dayNum <= 31;
                  const hasEvent = dayNum === 2 || dayNum === 15 || dayNum === 22;

                  return (
                    <div 
                      key={idx} 
                      className={`p-1.5 rounded-xl border border-white/[0.03] flex flex-col justify-between ${
                        isCurrentMonth ? "bg-white/[0.01]" : "opacity-20 bg-transparent"
                      } ${dayNum === 2 ? "border-indigo-500 bg-indigo-500/[0.02]" : ""}`}
                    >
                      <span className="text-[9px] font-mono text-white/40">{isCurrentMonth ? dayNum : ""}</span>
                      {hasEvent && isCurrentMonth && (
                        <span className="h-1 w-full bg-indigo-500 rounded-full" />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Event list panel (4 cols) */}
            <div className="xl:col-span-4 p-6 rounded-3xl border border-white/[0.06] bg-zinc-950/60 backdrop-blur-md space-y-4">
              <h4 className="font-extrabold text-white text-xs uppercase tracking-wider">Scheduled Milestones</h4>
              
              <div className="space-y-3">
                {calendarEvents.map((evt) => (
                  <div key={evt.id} className="p-3.5 rounded-2xl border border-white/[0.04] bg-white/[0.01] text-xs space-y-1">
                    <div className="flex justify-between text-[8px] font-mono text-white/30">
                      <span>{evt.type}</span>
                      <span>{evt.date}</span>
                    </div>
                    <p className="font-extrabold text-white">{evt.title}</p>
                    <p className="text-[10px] text-white/50">{evt.courseId || "Academy-wide"}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB: REPORTS & PERFORMANCE ANALYTICS (SVG CHARTS) */}
      {subTab === "analytics" && (
        <div className="space-y-6 text-left">
          
          <div className="flex justify-between items-center flex-wrap gap-4">
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider">LMS Performance Analytics</h3>
              <p className="text-[10px] text-white/40">Review real-time statistical performance, growth trackers, and payment ratios.</p>
            </div>

            <div className="flex gap-2">
              <button 
                onClick={() => handleSimulateExport("CSV")}
                className="px-3.5 py-1.5 rounded-xl bg-white/[0.02] border border-white/10 text-white/70 text-[10px] font-black uppercase hover:text-white hover:bg-white/[0.04] flex items-center gap-1"
              >
                <Download size={11} />
                <span>Export CSV</span>
              </button>
              <button 
                onClick={() => handleSimulateExport("PDF")}
                className="px-3.5 py-1.5 rounded-xl bg-white/[0.02] border border-white/10 text-white/70 text-[10px] font-black uppercase hover:text-white hover:bg-white/[0.04] flex items-center gap-1"
              >
                <FileText size={11} />
                <span>Export PDF</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Chart: Student Growth Trend (SVG Line) */}
            <div className="p-6 rounded-3xl border border-white/[0.06] bg-zinc-950/60 backdrop-blur-md space-y-4">
              <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Sliders size={12} className="text-indigo-400" />
                <span>Student Growth Trend (2026)</span>
              </h4>

              {/* Interactive SVG */}
              <div className="h-48 w-full bg-white/[0.01] border border-white/[0.03] rounded-2xl p-4 flex items-end relative overflow-hidden">
                <svg className="absolute inset-0 h-full w-full p-4 overflow-visible" viewBox="0 0 400 150">
                  {/* Grid lines */}
                  <line x1="0" y1="30" x2="400" y2="30" stroke="rgba(255,255,255,0.03)" strokeWidth="1" />
                  <line x1="0" y1="75" x2="400" y2="75" stroke="rgba(255,255,255,0.03)" strokeWidth="1" />
                  <line x1="0" y1="120" x2="400" y2="120" stroke="rgba(255,255,255,0.03)" strokeWidth="1" />
                  
                  {/* Glowing smooth cubic trend path */}
                  <path 
                    d="M 10 140 Q 90 120, 150 90 T 290 50 T 390 10" 
                    fill="none" 
                    stroke="#6366f1" 
                    strokeWidth="3.5" 
                    strokeLinecap="round"
                  />
                  <path 
                    d="M 10 140 Q 90 120, 150 90 T 290 50 T 390 10 L 390 150 L 10 150 Z" 
                    fill="url(#indigo-grad)" 
                    opacity="0.12" 
                  />

                  {/* Gradient definition */}
                  <defs>
                    <linearGradient id="indigo-grad" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#6366f1" />
                      <stop offset="100%" stopColor="transparent" />
                    </linearGradient>
                  </defs>
                </svg>

                <div className="absolute bottom-2 left-4 right-4 flex justify-between font-mono text-[8px] text-white/30 uppercase">
                  <span>Jan</span><span>Mar</span><span>May</span><span>Jul</span><span>Sep</span><span>Nov</span>
                </div>
              </div>
            </div>

            {/* Chart: Revenue and payments (SVG Bar Chart) */}
            <div className="p-6 rounded-3xl border border-white/[0.06] bg-zinc-950/60 backdrop-blur-md space-y-4">
              <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-2">
                <BarChart3 size={12} className="text-emerald-400" />
                <span>Monthly Academy Cashflows</span>
              </h4>

              <div className="h-48 w-full bg-white/[0.01] border border-white/[0.03] rounded-2xl p-4 flex items-end justify-around relative">
                {/* Simulated vertical Bars using standard HTML layouts */}
                {[
                  { m: "Jan", val: 40, amt: "$8,500" },
                  { m: "Feb", val: 55, amt: "$12,400" },
                  { m: "Mar", val: 78, amt: "$19,200" },
                  { m: "Apr", val: 62, amt: "$14,500" },
                  { m: "May", val: 95, amt: "$24,000" },
                  { m: "Jun", val: 100, amt: "$26,500" }
                ].map((bar) => (
                  <div key={bar.m} className="flex flex-col items-center gap-2 group cursor-pointer relative">
                    {/* Hover detail tooltip */}
                    <span className="absolute -top-8 bg-black border border-white/10 px-2 py-0.5 rounded text-[8px] text-emerald-400 font-mono font-bold opacity-0 group-hover:opacity-100 transition-opacity z-10">
                      {bar.amt}
                    </span>
                    <div 
                      className="w-5 sm:w-8 bg-gradient-to-t from-[#10b981]/50 to-[#10b981] rounded-t-lg group-hover:brightness-110 transition-all" 
                      style={{ height: `${bar.val * 1.1}px` }}
                    />
                    <span className="font-mono text-[9px] text-white/40">{bar.m}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* SUB-TAB: ROLES & PERMISSIONS MATRIX */}
      {subTab === "permissions" && (
        <div className="space-y-4 text-left">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider">Access Control privileges Matrix</h3>
              <p className="text-[10px] text-white/40">Toggle operational roles and security permissions dynamically for safety audits.</p>
            </div>
            
            <div className="flex gap-1.5">
              {roles.map((role) => (
                <button
                  key={role.role}
                  onClick={() => setSelectedRole(role.role)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold uppercase transition-all ${
                    selectedRole === role.role
                      ? "bg-indigo-500 text-black font-black"
                      : "bg-white/[0.02] text-white/50 border border-white/5 hover:text-white"
                  }`}
                >
                  {role.role}
                </button>
              ))}
            </div>
          </div>

          <div className="p-6 rounded-3xl border border-white/[0.06] bg-zinc-950/60 backdrop-blur-md space-y-3">
            {roles.filter(r => r.role === selectedRole).map((role) => (
              <div key={role.role} className="divide-y divide-white/[0.03] text-xs">
                {Object.entries(role.permissions).map(([perm, checked]) => (
                  <div key={perm} className="py-3 flex justify-between items-center">
                    <div>
                      <p className="font-extrabold text-white capitalize">{perm.replace(/([A-Z])/g, " $1")}</p>
                      <p className="text-[9px] text-white/40">Grants capability to execute actions related to this model category.</p>
                    </div>

                    <button
                      onClick={() => onUpdateRolePermissions(role.role, perm, !checked)}
                      className={`h-5 w-10 rounded-full p-0.5 transition-colors relative cursor-pointer ${
                        checked ? "bg-indigo-500" : "bg-zinc-800"
                      }`}
                    >
                      <span className={`h-4 w-4 rounded-full bg-white block transition-transform ${
                        checked ? "translate-x-5" : "translate-x-0"
                      }`} />
                    </button>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB: IMMUTABLE AUDIT LOGS */}
      {subTab === "logs" && (
        <div className="space-y-4 text-left">
          <div className="flex justify-between items-center flex-wrap gap-4">
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider">LMS Activity Audit log</h3>
              <p className="text-[10px] text-white/40">Immutable log records monitoring authorization and CRUD manipulations.</p>
            </div>

            <div className="relative w-64">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40"><Search size={13} /></span>
              <input 
                type="text" 
                placeholder="Filter logs by operator, action..."
                value={logsQuery}
                onChange={(e) => setLogsQuery(e.target.value)}
                className="w-full bg-zinc-900 border border-white/5 rounded-xl py-1.5 pl-8 pr-3 text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="p-6 rounded-3xl border border-white/[0.06] bg-zinc-950/60 backdrop-blur-md overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-white/[0.05] text-white/30 uppercase tracking-widest text-[9px] font-black">
                  <th className="pb-3 font-black">System Operator</th>
                  <th className="pb-3 font-black">Role</th>
                  <th className="pb-3 font-black">Committed Action</th>
                  <th className="pb-3 font-black">Target Module</th>
                  <th className="pb-3 font-black">Audit Status</th>
                  <th className="pb-3 text-right font-black">Audit Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.02]">
                {filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-white/[0.01] transition-all">
                    <td className="py-4 font-extrabold text-white">
                      {log.username}
                    </td>
                    <td className="py-4 font-mono text-[9px] text-indigo-400 uppercase">
                      {log.role}
                    </td>
                    <td className="py-4 text-white/70 font-sans">
                      {log.action}
                    </td>
                    <td className="py-4 text-white/40 uppercase font-bold text-[9px]">
                      {log.module}
                    </td>
                    <td className="py-4">
                      <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider ${
                        log.status === "Success"
                          ? "bg-emerald-500/10 text-emerald-400"
                          : "bg-rose-500/10 text-rose-400"
                      }`}>
                        {log.status}
                      </span>
                    </td>
                    <td className="py-4 font-mono text-[10px] text-white/30 text-right">
                      {log.timestamp}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Rich announcements dialog form */}
      {showAnnModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-md bg-[#0d0d12] border border-white/10 rounded-3xl p-6 text-left space-y-4 text-xs">
            <h3 className="text-xs font-black text-white uppercase tracking-wider">Broadcast Academy Announcement</h3>
            
            <form onSubmit={handleCreateAnnouncement} className="space-y-4">
              <div className="space-y-1">
                <label className="text-[9px] text-white/40 uppercase font-black tracking-widest">Broadcast Title</label>
                <input 
                  type="text" 
                  required
                  placeholder="e.g. Schedule Maintenance and Backups"
                  value={newAnn.title}
                  onChange={(e) => setNewAnn({ ...newAnn, title: e.target.value })}
                  className="w-full bg-zinc-900 border border-white/10 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[9px] text-white/40 uppercase font-black tracking-widest">Audience target</label>
                <select
                  value={newAnn.target}
                  onChange={(e) => setNewAnn({ ...newAnn, target: e.target.value })}
                  className="w-full bg-zinc-900 border border-white/10 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="Everyone">Everyone (All Direct Roster)</option>
                  <option value="Instructors Only">Instructors Only</option>
                  <option value="Students Only">Students Only</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[9px] text-white/40 uppercase font-black tracking-widest">Broadcast Body Markdown</label>
                <textarea 
                  rows={4}
                  required
                  placeholder="Announcements body text..."
                  value={newAnn.content}
                  onChange={(e) => setNewAnn({ ...newAnn, content: e.target.value })}
                  className="w-full bg-zinc-900 border border-white/10 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-indigo-500 font-sans"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button type="submit" className="flex-1 py-2 bg-indigo-500 text-black font-bold uppercase tracking-wider rounded-xl">Broadcast Now</button>
                <button type="button" onClick={() => setShowAnnModal(false)} className="flex-1 py-2 bg-white/[0.04] text-white/60 uppercase rounded-xl">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Export progress loader overlay */}
      {exportProgress && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md flex flex-col items-center justify-center z-50 p-4">
          <RefreshCw className="text-indigo-400 animate-spin mb-4" size={30} />
          <p className="text-xs font-bold text-white uppercase tracking-wider animate-pulse">{exportProgress}</p>
        </div>
      )}

    </div>
  );
}
