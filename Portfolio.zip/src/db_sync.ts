/**
 * Academy LMS Database Synchronization Interceptor
 * Transparently binds the React client to the Express + MySQL backend
 * without modifying any dashboard UI, UX, components or local states.
 */

const SYNC_KEYS = [
  "admin_profile",
  "teacher_profile",
  "lms_student_profile",
  "teacher_courses",
  "teacher_students",
  "teacher_sessions",
  "teacher_assignments",
  "teacher_discussions",
  "teacher_resources",
  "teacher_announcements",
  "teacher_calendar_events",
  "teacher_course_seasons",
  "teacher_grades",
  "teacher_certificates",
  "cms_current_config",
  "userResources",
  "userAssignments",
  "userCourseConversations",
  "student_course_sessions",
  "student_sim_active_sessions",
  "admin_users",
  "admin_course_requests",
  "admin_enrollments",
  "admin_exams",
  "admin_activity_logs",
  "admin_roles_permissions"
];

// Mutex flag to prevent infinite loops during initial loading populates
let isInitializing = false;

/**
 * Initializes the client-side state with the backend MySQL database
 */
export async function initializeDatabaseSync() {
  if (isInitializing) return;
  isInitializing = true;

  console.log("[DBSync] Initializing connection to database API layer...");

  try {
    // 1. Fetch current consolidated database structure from Express server
    const response = await fetch("/api/get-all-data");
    if (!response.ok) {
      throw new Error(`Failed to fetch database state: ${response.statusText}`);
    }

    const data = await response.json();
    console.log("[DBSync] Database state retrieved successfully:", Object.keys(data));

    // 2. Populate localStorage keys transparently
    for (const key of Object.keys(data)) {
      if (SYNC_KEYS.includes(key) || key === "lms_student_profile") {
        const localKey = key === "lms_student_profile" ? "studentProfile" : key;
        const currentVal = localStorage.getItem(localKey);
        const newVal = JSON.stringify(data[key]);

        if (currentVal !== newVal) {
          console.log(`[DBSync] Syncing ${localKey} to match MySQL database`);
          localStorage.setItem(localKey, newVal);
        }
      }
    }

    console.log("[DBSync] Client-side states synced successfully with database.");
  } catch (err: any) {
    console.error("[DBSync] Database initialization sync failed, running in local-only backup mode:", err.message);
  } finally {
    isInitializing = false;
    // 3. Setup Monkey-Patching for real-time MySQL writes
    setupRealtimeWrites();
  }
}

/**
 * Monkey-patches localStorage.setItem to automatically capture client writes
 * and stream updates back to the MySQL database.
 */
function setupRealtimeWrites() {
  const originalSetItem = localStorage.setItem;

  localStorage.setItem = function (key: string, value: string) {
    // Execute original write to satisfy local state binds
    originalSetItem.apply(this, [key, value]);

    // If initial loading is busy, do not trigger background write loops
    if (isInitializing) return;

    // Check if written key belongs to our database schemas
    const syncKey = key === "studentProfile" ? "lms_student_profile" : key;
    if (SYNC_KEYS.includes(syncKey)) {
      // Stream update to the MySQL database API asynchronously
      fetch("/api/save-key", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          key: syncKey,
          value: value
        })
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          console.log(`[DBSync] Real-time write saved to MySQL for: ${syncKey}`);
        } else {
          console.warn(`[DBSync] Failed to stream write to MySQL:`, data.error);
        }
      })
      .catch(err => {
        console.error(`[DBSync] Network error streaming database write:`, err.message);
      });
    }
  };

  console.log("[DBSync] Real-time MySQL database writes setup successfully.");
}
