import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  FolderOpen,
  Upload,
  FileText,
  FileArchive,
  Download,
  Trash2,
  Edit2,
  X,
  Play,
  Eye,
  FileCode,
  FileImage,
  RefreshCw,
  Plus,
  EyeOff,
  AlertTriangle
} from "lucide-react";
import { Resource, Course, Session } from "../../types/teacher";

interface ResourcesTabProps {
  resources: Resource[];
  courses: Course[];
  sessions: Session[];
  onUploadResource: (res: Omit<Resource, "id" | "uploadedAt">) => void;
  onDeleteResource: (resId: string) => void;
  onReplaceResource: (resId: string, updatedRes: Resource) => void;
  showCustomToast: (msg: string, type?: "info" | "success" | "warning") => void;
}

export default function ResourcesTab({
  resources,
  courses,
  sessions,
  onUploadResource,
  onDeleteResource,
  onReplaceResource,
  showCustomToast
}: ResourcesTabProps) {
  const [dragActive, setDragActive] = useState(false);
  const [selectedCourseId, setSelectedCourseId] = useState("");
  const [fileType, setFileType] = useState<"pdf" | "zip" | "doc" | "code" | "video">("pdf");
  const [uploadTitle, setUploadTitle] = useState("");
  const [uploadDesc, setUploadDesc] = useState("");
  const [uploadSessionId, setUploadSessionId] = useState("");
  const [uploadVisibility, setUploadVisibility] = useState<"Visible" | "Hidden">("Visible");
  const [uploadDisplayOrder, setUploadDisplayOrder] = useState<number>(1);
  const [uploadFileName, setUploadFileName] = useState("");

  const [activePreviewRes, setActivePreviewRes] = useState<Resource | null>(null);
  
  // EDIT MODAL STATE
  const [editingRes, setEditingRes] = useState<Resource | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editDesc, setEditDesc] = useState("");
  const [editCourseId, setEditCourseId] = useState("");
  const [editSessionId, setEditSessionId] = useState("");
  const [editFileType, setEditFileType] = useState<"pdf" | "zip" | "doc" | "code" | "video">("pdf");
  const [editVisibility, setEditVisibility] = useState<"Visible" | "Hidden">("Visible");
  const [editDisplayOrder, setEditDisplayOrder] = useState<number>(1);
  const [editFileName, setEditFileName] = useState("");
  const [editFileSize, setEditFileSize] = useState("");

  // DELETION CONFIRMATION STATE
  const [resToDelete, setResToDelete] = useState<Resource | null>(null);

  // Filtered Sessions for creation form
  const availableCreateSessions = useMemo(() => {
    return sessions.filter((s) => s.courseId === selectedCourseId);
  }, [sessions, selectedCourseId]);

  // Filtered Sessions for editing form
  const availableEditSessions = useMemo(() => {
    return sessions.filter((s) => s.courseId === editCourseId);
  }, [sessions, editCourseId]);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setUploadTitle(file.name.split(".").slice(0, -1).join(" ") || file.name);
      setUploadFileName(file.name);
      
      const ext = file.name.split(".").pop()?.toLowerCase();
      if (ext === "pdf") setFileType("pdf");
      else if (ext === "zip" || ext === "rar") setFileType("zip");
      else if (ext === "js" || ext === "ts" || ext === "tsx" || ext === "py" || ext === "html" || ext === "css") setFileType("code");
      else if (ext === "doc" || ext === "docx") setFileType("doc");
      else if (ext === "mp4" || ext === "mov" || ext === "mkv") setFileType("video");
      showCustomToast(`File detected: "${file.name}". Adjust specs to publish.`, "info");
    }
  };

  const handleManualUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setUploadTitle(file.name.split(".").slice(0, -1).join(" ") || file.name);
      setUploadFileName(file.name);
      
      const ext = file.name.split(".").pop()?.toLowerCase();
      if (ext === "pdf") setFileType("pdf");
      else if (ext === "zip" || ext === "rar") setFileType("zip");
      else if (ext === "js" || ext === "ts" || ext === "tsx" || ext === "py") setFileType("code");
      else if (ext === "doc" || ext === "docx") setFileType("doc");
      showCustomToast(`File loaded: "${file.name}". Adjust specs to publish.`, "info");
    }
  };

  // Trigger when they click Edit
  const handleEditOpen = (res: Resource) => {
    setEditingRes(res);
    setEditTitle(res.title);
    setEditDesc(res.description || "");
    setEditCourseId(res.courseId);
    setEditSessionId(res.relatedSessionId || "");
    setEditFileType(res.fileType);
    setEditVisibility(res.visibility || "Visible");
    setEditDisplayOrder(res.displayOrder || 1);
    setEditFileName(res.fileName || `${res.title.toLowerCase().replace(/\s+/g, "_")}.pdf`);
    setEditFileSize(res.fileSize);
  };

  const handleEditFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      // File Replacement Logic
      const newSize = `${(file.size / (1024 * 1024)).toFixed(1)} MB`;
      setEditFileName(file.name);
      setEditFileSize(newSize);
      
      // Auto adjust category
      const ext = file.name.split(".").pop()?.toLowerCase();
      if (ext === "pdf") setEditFileType("pdf");
      else if (ext === "zip" || ext === "rar") setEditFileType("zip");
      else if (ext === "js" || ext === "ts" || ext === "tsx" || ext === "py") setEditFileType("code");
      else if (ext === "doc" || ext === "docx") setEditFileType("doc");
      else if (ext === "mp4" || ext === "mov" || ext === "mkv") setEditFileType("video");

      showCustomToast(`Replaced old resource. Storage file replaced with "${file.name}"!`, "info");
    }
  };

  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (uploadTitle && selectedCourseId) {
      const course = courses.find((c) => c.id === selectedCourseId);
      const session = sessions.find((s) => s.id === uploadSessionId);
      
      onUploadResource({
        title: uploadTitle,
        courseId: selectedCourseId,
        courseTitle: course ? course.title : "Academy Course",
        fileType,
        fileSize: `${(Math.random() * 5 + 1).toFixed(1)} MB`,
        description: uploadDesc,
        relatedSessionId: uploadSessionId || undefined,
        relatedSessionTitle: session ? session.title : undefined,
        visibility: uploadVisibility,
        displayOrder: uploadDisplayOrder,
        fileName: uploadFileName || `${uploadTitle.toLowerCase().replace(/\s+/g, "_")}.pdf`
      });

      showCustomToast(`Material published to course file system!`, "success");
      // Reset
      setUploadTitle("");
      setUploadDesc("");
      setSelectedCourseId("");
      setUploadSessionId("");
      setUploadFileName("");
      setUploadDisplayOrder(1);
    }
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingRes && editTitle && editCourseId) {
      const course = courses.find((c) => c.id === editCourseId);
      const session = sessions.find((s) => s.id === editSessionId);

      onReplaceResource(editingRes.id, {
        ...editingRes,
        title: editTitle,
        description: editDesc,
        courseId: editCourseId,
        courseTitle: course ? course.title : "Academy Course",
        fileType: editFileType,
        relatedSessionId: editSessionId || undefined,
        relatedSessionTitle: session ? session.title : undefined,
        visibility: editVisibility,
        displayOrder: editDisplayOrder,
        fileName: editFileName,
        fileSize: editFileSize
      });

      showCustomToast("Course material specs successfully updated!", "success");
      setEditingRes(null);
    }
  };

  const confirmDelete = () => {
    if (resToDelete) {
      onDeleteResource(resToDelete.id);
      showCustomToast(`Successfully deleted resource: "${resToDelete.title}"`, "success");
      setResToDelete(null);
    }
  };

  const getFileIcon = (type: string) => {
    switch (type) {
      case "pdf":
        return <FileText className="text-rose-400" size={16} />;
      case "zip":
        return <FileArchive className="text-amber-400" size={16} />;
      case "code":
        return <FileCode className="text-indigo-400" size={16} />;
      case "video":
        return <FileImage className="text-emerald-400" size={16} />;
      default:
        return <FileText className="text-white/60" size={16} />;
    }
  };

  return (
    <div className="space-y-6 animate-fade-in text-left">
      {/* SECTION HEADER */}
      <div className="border-b border-white/[0.04] pb-5">
        <h2 className="font-sans text-xl font-bold text-white uppercase tracking-wider">
          Class Course Materials
        </h2>
        <p className="font-sans text-xs text-white/40">
          Upload, configure visibility, set logical display orders, and update reading syllabi or template folders.
        </p>
      </div>

      {/* TOP UPLOADER AND MANAGER GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* DRAG AND DROP FORM */}
        <div className="lg:col-span-5 bg-[#08080c]/90 border border-white/[0.05] rounded-3xl p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-white/[0.04] pb-3">
            <Upload size={15} className="text-indigo-400" />
            <h3 className="font-sans text-xs font-bold text-white uppercase tracking-wider">
              Publish Class Material
            </h3>
          </div>

          <div
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-2xl p-6 text-center transition-all ${
              dragActive ? "border-indigo-500 bg-indigo-500/[0.02]" : "border-white/10 hover:border-white/20 bg-black/40"
            } relative cursor-pointer`}
          >
            <input
              type="file"
              onChange={handleManualUpload}
              className="absolute inset-0 opacity-0 cursor-pointer"
            />
            <div className="flex flex-col items-center justify-center gap-2 select-none">
              <Upload size={20} className="text-indigo-400 animate-pulse" />
              <span className="text-xs text-white/80 font-semibold font-sans">Drag and drop file here</span>
              <span className="text-[10px] text-white/30 font-sans">or click to browse local folders (PDF, ZIP, CODE)</span>
            </div>
          </div>

          {uploadFileName && (
            <div className="p-3 bg-white/[0.02] border border-white/[0.04] rounded-xl text-[10px] text-white/60 flex items-center justify-between">
              <span className="truncate max-w-[80%]">📁 Loaded: {uploadFileName}</span>
              <button
                onClick={() => setUploadFileName("")}
                className="text-white/30 hover:text-white"
              >
                <X size={10} />
              </button>
            </div>
          )}

          <form onSubmit={handleUploadSubmit} className="space-y-3.5 text-xs text-left">
            <div className="grid grid-cols-1 gap-3.5">
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-white/50 uppercase">Material Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Lecture 1 Notes - Reconciliation Spec"
                  value={uploadTitle}
                  onChange={(e) => setUploadTitle(e.target.value)}
                  className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-white placeholder-white/20 focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-white/50 uppercase">Description</label>
                <textarea
                  placeholder="Summarize the resource's purpose..."
                  rows={2}
                  value={uploadDesc}
                  onChange={(e) => setUploadDesc(e.target.value)}
                  className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-white placeholder-white/20 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-white/50 uppercase">Target Course</label>
                <select
                  required
                  value={selectedCourseId}
                  onChange={(e) => {
                    setSelectedCourseId(e.target.value);
                    setUploadSessionId("");
                  }}
                  className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-white/80 focus:outline-none cursor-pointer"
                >
                  <option value="">Choose Course...</option>
                  {courses.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.title}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-white/50 uppercase">Related Session</label>
                <select
                  disabled={!selectedCourseId}
                  value={uploadSessionId}
                  onChange={(e) => setUploadSessionId(e.target.value)}
                  className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-white/80 focus:outline-none cursor-pointer disabled:opacity-40"
                >
                  <option value="">No Session Link</option>
                  {availableCreateSessions.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.title}
                    </option>
                  ))}
                </select>
                {selectedCourseId && availableCreateSessions.length === 0 && (
                  <span className="block text-[10px] text-amber-400 mt-1 font-sans">
                    ⚠ No masterclass sessions found for this course.
                  </span>
                )}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div className="space-y-1 col-span-1">
                <label className="block text-[10px] font-bold text-white/50 uppercase">Order</label>
                <input
                  type="number"
                  min={1}
                  value={uploadDisplayOrder}
                  onChange={(e) => setUploadDisplayOrder(parseInt(e.target.value) || 1)}
                  className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-white placeholder-white/20 focus:outline-none"
                />
              </div>
              <div className="space-y-1 col-span-1">
                <label className="block text-[10px] font-bold text-white/50 uppercase">Visibility</label>
                <select
                  value={uploadVisibility}
                  onChange={(e) => setUploadVisibility(e.target.value as any)}
                  className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-2 py-2 text-[11px] text-white/80 focus:outline-none cursor-pointer"
                >
                  <option value="Visible">Visible</option>
                  <option value="Hidden">Hidden</option>
                </select>
              </div>
              <div className="space-y-1 col-span-1">
                <label className="block text-[10px] font-bold text-white/50 uppercase">Type</label>
                <select
                  value={fileType}
                  onChange={(e) => setFileType(e.target.value as any)}
                  className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-2 py-2 text-[11px] text-white/80 focus:outline-none cursor-pointer"
                >
                  <option value="pdf">PDF</option>
                  <option value="zip">ZIP</option>
                  <option value="code">Code</option>
                  <option value="doc">Doc</option>
                  <option value="video">Video</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              disabled={!uploadTitle || !selectedCourseId}
              className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-sans font-bold text-xs tracking-wider uppercase transition-all shadow-[0_4px_12px_rgba(79,70,229,0.2)] cursor-pointer"
            >
              Publish Resource File
            </button>
          </form>
        </div>

        {/* RESOURCE LIST */}
        <div className="lg:col-span-7 bg-[#08080c]/90 border border-white/[0.05] rounded-3xl p-5 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center gap-2 border-b border-white/[0.04] pb-3">
              <FolderOpen size={15} className="text-amber-400" />
              <h3 className="font-sans text-xs font-bold text-white uppercase tracking-wider">
                Academic Resource Repository ({resources.length})
              </h3>
            </div>

            <div className="space-y-3">
              {resources.map((res) => (
                <div
                  key={res.id}
                  className="p-3.5 rounded-2xl bg-white/[0.01] border border-white/[0.03] hover:border-white/[0.08] transition-all flex items-center justify-between gap-3 group text-xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-white/[0.03] rounded-xl border border-white/[0.05] shrink-0">
                      {getFileIcon(res.fileType)}
                    </div>
                    <div className="space-y-0.5 text-left">
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-white group-hover:text-indigo-400 transition-colors">
                          {res.title}
                        </h4>
                        {res.visibility === "Hidden" && (
                          <span className="flex items-center text-[8px] font-sans font-bold tracking-wide text-white/30 uppercase bg-white/[0.04] px-1.5 py-0.5 rounded gap-0.5 border border-white/5">
                            <EyeOff size={8} /> Hidden
                          </span>
                        )}
                        {res.displayOrder && res.displayOrder > 1 && (
                          <span className="text-[8px] font-mono font-bold text-indigo-400 px-1 rounded bg-indigo-500/5 border border-indigo-500/10">
                            #{res.displayOrder}
                          </span>
                        )}
                      </div>
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[10px] text-white/30 font-sans leading-none">
                        <span className="text-white/40">{res.courseTitle}</span>
                        <span>•</span>
                        {res.relatedSessionTitle && (
                          <>
                            <span className="text-indigo-400/70">Session: {res.relatedSessionTitle}</span>
                            <span>•</span>
                          </>
                        )}
                        <span className="font-mono">{res.fileSize}</span>
                        <span>•</span>
                        <span>{res.uploadedAt}</span>
                      </div>
                      {res.description && (
                        <p className="text-[10px] text-white/40 mt-1 font-sans italic leading-relaxed">{res.description}</p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => setActivePreviewRes(res)}
                      className="p-1.5 rounded-lg hover:bg-white/[0.04] text-white/30 hover:text-white transition-colors cursor-pointer"
                      title="Preview Document Template"
                    >
                      <Eye size={12} />
                    </button>
                    <button
                      onClick={() => handleEditOpen(res)}
                      className="p-1.5 rounded-lg hover:bg-white/[0.04] text-white/30 hover:text-white transition-colors cursor-pointer"
                      title="Edit Resource Details"
                    >
                      <Edit2 size={12} />
                    </button>
                    <button
                      onClick={() => setResToDelete(res)}
                      className="p-1.5 rounded-lg hover:bg-white/[0.04] text-white/30 hover:text-red-400 transition-colors cursor-pointer"
                      title="Remove resource file"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* DOCUMENT PREVIEW MODAL */}
      <AnimatePresence>
        {activePreviewRes && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#08080c] border border-white/10 rounded-3xl w-full max-w-2xl p-6 relative overflow-hidden shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] max-h-[85vh] overflow-y-auto space-y-4"
            >
              <button
                onClick={() => setActivePreviewRes(null)}
                className="absolute top-4 right-4 p-1.5 rounded-lg text-white/30 hover:text-white hover:bg-white/[0.04] transition-colors cursor-pointer"
              >
                <X size={15} />
              </button>

              <div className="flex items-center gap-2 border-b border-white/[0.04] pb-4">
                {getFileIcon(activePreviewRes.fileType)}
                <h3 className="font-sans text-sm font-bold text-white uppercase tracking-wider">
                  Material Document Preview
                </h3>
              </div>

              <div className="space-y-2.5 text-left text-xs">
                <div className="p-4 rounded-2xl bg-[#030304] border border-white/5 font-mono text-white/60 space-y-3 text-[10px] sm:text-[11px] leading-relaxed">
                  <div className="border-b border-white/[0.04] pb-2 text-white/35 uppercase tracking-widest flex justify-between">
                    <span>Document Header: {activePreviewRes.fileType.toUpperCase()} Spec</span>
                    <span>SIZE: {activePreviewRes.fileSize}</span>
                  </div>
                  {activePreviewRes.fileType === "code" ? (
                    <pre className="overflow-x-auto text-indigo-300">
                      {`// Course: ${activePreviewRes.courseTitle}
// Published: ${activePreviewRes.uploadedAt}
// File: ${activePreviewRes.fileName || "template.tsx"}

import React, { useState, useEffect } from "react";

export default function ReconcilerKernel({ dispatch }) {
  const [frameLane, setFrameLane] = useState(31);
  
  useEffect(() => {
    // Commit layout phase baseline grids
    dispatch({ type: "SYNC_baseline_ALIGN", payload: frameLane });
  }, [frameLane]);

  return <div className="baseline-kernel font-sans text-xs font-semibold" />;
}`}
                    </pre>
                  ) : (
                    <div className="space-y-3 font-sans">
                      <p className="text-white/80 font-bold text-xs uppercase tracking-wide">Course Syllabus Outline — Part 1</p>
                      <p>
                        Welcome to {activePreviewRes.courseTitle}. This specification governs class assessments, weekly deadlines, code repositories, and grading bounds.
                      </p>
                      {activePreviewRes.description && (
                        <p className="text-indigo-400 font-sans italic">
                          Instructor Note: {activePreviewRes.description}
                        </p>
                      )}
                      <p>
                        Students must submit all assignments through standard institutional GitHub commits. Any local compiler error will result in automatic review flags.
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div className="border-t border-white/[0.04] pt-4 flex items-center justify-between">
                <span className="font-sans text-[10px] text-white/30 font-semibold uppercase">
                  Class Room Viewer Engine
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      showCustomToast("Preparing binary stream download...", "info");
                      setTimeout(() => showCustomToast("Downloaded course resource successfully!", "success"), 1000);
                    }}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-sans font-bold text-xs transition-all cursor-pointer"
                  >
                    <Download size={12} />
                    <span>Download Material</span>
                  </button>
                  <button
                    onClick={() => setActivePreviewRes(null)}
                    className="px-4 py-2 rounded-xl border border-white/10 bg-white/[0.01] hover:bg-white/[0.04] text-xs font-bold text-white transition-all cursor-pointer"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* RENAME & UPDATE DETAILED PROPERTIES MODAL */}
      <AnimatePresence>
        {editingRes && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#08080c] border border-white/10 rounded-3xl w-full max-w-md p-6 relative overflow-hidden shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] max-h-[90vh] overflow-y-auto text-left"
            >
              <button
                onClick={() => setEditingRes(null)}
                className="absolute top-4 right-4 p-1.5 rounded-lg text-white/30 hover:text-white hover:bg-white/[0.04] transition-colors cursor-pointer"
              >
                <X size={15} />
              </button>

              <div className="flex items-center gap-2 border-b border-white/[0.04] pb-4 mb-5">
                <RefreshCw size={15} className="text-indigo-400" />
                <h3 className="font-sans text-sm font-bold text-white uppercase tracking-wider">
                  Edit Resource Specifications
                </h3>
              </div>

              <form onSubmit={handleEditSubmit} className="space-y-4 text-xs">
                {/* Title */}
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-white/50 uppercase">Resource Title</label>
                  <input
                    type="text"
                    required
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none"
                  />
                </div>

                {/* Description */}
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-white/50 uppercase">Description</label>
                  <textarea
                    rows={2}
                    value={editDesc}
                    onChange={(e) => setEditDesc(e.target.value)}
                    className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none"
                  />
                </div>

                {/* Course & Sessions */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold text-white/50 uppercase">Related Course</label>
                    <select
                      value={editCourseId}
                      onChange={(e) => {
                        setEditCourseId(e.target.value);
                        setEditSessionId("");
                      }}
                      className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-2 py-2 text-xs text-white focus:outline-none cursor-pointer"
                    >
                      {courses.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.title}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold text-white/50 uppercase">Related Session</label>
                    <select
                      value={editSessionId}
                      onChange={(e) => setEditSessionId(e.target.value)}
                      disabled={!editCourseId}
                      className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-2 py-2 text-xs text-white/80 focus:outline-none cursor-pointer disabled:opacity-40"
                    >
                      <option value="">None</option>
                      {availableEditSessions.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.title}
                        </option>
                      ))}
                    </select>
                    {editCourseId && availableEditSessions.length === 0 && (
                      <span className="block text-[10px] text-amber-400 mt-1 font-sans">
                        ⚠ No masterclass sessions found for this course.
                      </span>
                    )}
                  </div>
                </div>

                {/* Category & Visibility & Display Order */}
                <div className="grid grid-cols-3 gap-2">
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold text-white/50 uppercase">Category</label>
                    <select
                      value={editFileType}
                      onChange={(e) => setEditFileType(e.target.value as any)}
                      className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-1.5 py-2 text-[11px] text-white/80 focus:outline-none cursor-pointer"
                    >
                      <option value="pdf">PDF Spec</option>
                      <option value="zip">ZIP Archive</option>
                      <option value="code">Source Code</option>
                      <option value="doc">Text Doc</option>
                      <option value="video">Tutorial Video</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold text-white/50 uppercase">Visibility</label>
                    <select
                      value={editVisibility}
                      onChange={(e) => setEditVisibility(e.target.value as any)}
                      className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-1.5 py-2 text-[11px] text-white/80 focus:outline-none cursor-pointer"
                    >
                      <option value="Visible">Visible</option>
                      <option value="Hidden">Hidden</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold text-white/50 uppercase">Display Order</label>
                    <input
                      type="number"
                      min={1}
                      value={editDisplayOrder}
                      onChange={(e) => setEditDisplayOrder(parseInt(e.target.value) || 1)}
                      className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none"
                    />
                  </div>
                </div>

                {/* Mock File Replacement */}
                <div className="space-y-1.5 bg-black/40 border border-white/[0.04] p-3 rounded-2xl relative">
                  <label className="block text-[10px] font-bold text-white/50 uppercase">Replace Material File</label>
                  <p className="text-[10px] text-white/30 mb-2 truncate">Current File: {editFileName} ({editFileSize})</p>
                  
                  <div className="relative border border-white/10 hover:border-white/20 bg-[#030304] rounded-xl py-2 px-3 text-center cursor-pointer flex items-center justify-center gap-1.5 transition-colors">
                    <input
                      type="file"
                      onChange={handleEditFileChange}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                    <Upload size={12} className="text-indigo-400" />
                    <span className="text-[10px] font-sans font-bold text-indigo-400">Choose replacement file...</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-white/[0.04] flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setEditingRes(null)}
                    className="px-4 py-2.5 rounded-xl border border-white/10 bg-white/[0.01] hover:bg-white/[0.04] text-xs font-bold text-white cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-sans font-bold text-xs transition-all shadow-[0_4px_15px_rgba(79,70,229,0.25)] cursor-pointer"
                  >
                    Save Specifications
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* DELETE CONFIRMATION MODAL */}
      <AnimatePresence>
        {resToDelete && (
          <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#08080c] border border-rose-500/20 rounded-3xl w-full max-w-sm p-6 relative overflow-hidden shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] text-left"
            >
              <div className="flex items-center gap-2 border-b border-rose-500/10 pb-4 mb-4 text-rose-400">
                <AlertTriangle size={16} />
                <h3 className="font-sans text-sm font-bold uppercase tracking-wider">
                  Confirm Deletion
                </h3>
              </div>

              <div className="space-y-3.5 text-xs text-white/70 leading-relaxed font-sans">
                <p>
                  Are you sure you want to delete this resource? <strong>This action cannot be undone.</strong>
                </p>
                <div className="p-3 bg-rose-500/5 rounded-xl border border-rose-500/10 text-white">
                  <span className="block text-[8px] uppercase tracking-wider font-bold text-rose-400">Target File</span>
                  <span className="font-bold">{resToDelete.title}</span>
                </div>
              </div>

              <div className="pt-5 flex items-center justify-end gap-3 select-none">
                <button
                  onClick={() => setResToDelete(null)}
                  className="px-4 py-2 rounded-xl border border-white/10 bg-white/[0.01] hover:bg-white/[0.04] text-xs font-bold text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmDelete}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-sans font-bold text-xs shadow-lg shadow-rose-900/20 cursor-pointer"
                >
                  Delete Resource
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
