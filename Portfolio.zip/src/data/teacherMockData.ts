import {
  Course,
  Student,
  Session,
  Assignment,
  DiscussionThread,
  Resource,
  Announcement,
  GradeRecord,
  Certificate,
  CalendarEvent,
  TeacherProfile
} from "../types/teacher";

export const initialCourses: Course[] = [
  {
    id: "react-adv",
    title: "Advanced React & Architecture",
    code: "CS-402",
    studentsCount: 28,
    sessionsCount: 16,
    progress: 75,
    status: "Active",
    image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?q=80&w=300&auto=format&fit=crop"
  },
  {
    id: "swiss-typo",
    title: "Swiss Typography & Editorial Layout",
    code: "DES-301",
    studentsCount: 18,
    sessionsCount: 12,
    progress: 90,
    status: "Active",
    image: "https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?q=80&w=300&auto=format&fit=crop"
  },
  {
    id: "ml-found",
    title: "AI & Machine Learning Foundations",
    code: "CS-501",
    studentsCount: 35,
    sessionsCount: 20,
    progress: 40,
    status: "Active",
    image: "https://images.unsplash.com/photo-1527474305487-b87b222841cc?q=80&w=300&auto=format&fit=crop"
  }
];

export const initialStudents: Student[] = [
  {
    id: "stu-1",
    name: "Courtney Henry",
    email: "courtney.henry@academy.local",
    phone: "+1 (555) 234-5678",
    courseId: "react-adv",
    courseTitle: "Advanced React & Architecture",
    progress: 88,
    attendance: 95,
    avgGrade: 92,
    status: "Active",
    joinedDate: "2026-04-10"
  },
  {
    id: "stu-2",
    name: "Cody Fisher",
    email: "cody.fisher@academy.local",
    phone: "+1 (555) 345-6789",
    courseId: "react-adv",
    courseTitle: "Advanced React & Architecture",
    progress: 94,
    attendance: 100,
    avgGrade: 96,
    status: "Active",
    joinedDate: "2026-04-12"
  },
  {
    id: "stu-3",
    name: "Esther Howard",
    email: "esther.howard@academy.local",
    phone: "+1 (555) 456-7890",
    courseId: "swiss-typo",
    courseTitle: "Swiss Typography & Editorial Layout",
    progress: 72,
    attendance: 84,
    avgGrade: 78,
    status: "Active",
    joinedDate: "2026-05-01"
  },
  {
    id: "stu-4",
    name: "Eleanor Pena",
    email: "eleanor.pena@academy.local",
    phone: "+1 (555) 567-8901",
    courseId: "swiss-typo",
    courseTitle: "Swiss Typography & Editorial Layout",
    progress: 100,
    attendance: 100,
    avgGrade: 98,
    status: "Active",
    joinedDate: "2026-05-03"
  },
  {
    id: "stu-5",
    name: "Jane Cooper",
    email: "jane.cooper@academy.local",
    phone: "+1 (555) 678-9012",
    courseId: "ml-found",
    courseTitle: "AI & Machine Learning Foundations",
    progress: 45,
    attendance: 90,
    avgGrade: 84,
    status: "Active",
    joinedDate: "2026-05-15"
  },
  {
    id: "stu-6",
    name: "Wade Warren",
    email: "wade.warren@academy.local",
    phone: "+1 (555) 789-0123",
    courseId: "ml-found",
    courseTitle: "AI & Machine Learning Foundations",
    progress: 32,
    attendance: 75,
    avgGrade: 68,
    status: "Active",
    joinedDate: "2026-05-18"
  },
  {
    id: "stu-7",
    name: "Robert Fox",
    email: "robert.fox@academy.local",
    phone: "+1 (555) 890-1234",
    courseId: "react-adv",
    courseTitle: "Advanced React & Architecture",
    progress: 0,
    attendance: 0,
    avgGrade: 0,
    status: "Inactive",
    joinedDate: "2026-06-01"
  }
];

export const initialSessions: Session[] = [
  {
    id: "sess-1",
    courseId: "react-adv",
    courseTitle: "Advanced React & Architecture",
    title: "Architectural Patterns & Custom State Management",
    date: "2026-07-02",
    time: "10:00 AM",
    duration: "2 hours",
    link: "https://meet.google.com/abc-defg-hij",
    status: "Scheduled",
    studentCount: 28
  },
  {
    id: "sess-2",
    courseId: "swiss-typo",
    courseTitle: "Swiss Typography & Editorial Layout",
    title: "The Grid System & Spatial Layout Rules",
    date: "2026-07-02",
    time: "02:00 PM",
    duration: "1.5 hours",
    link: "https://meet.google.com/klm-nopq-rst",
    status: "Scheduled",
    studentCount: 18
  },
  {
    id: "sess-3",
    courseId: "ml-found",
    courseTitle: "AI & Machine Learning Foundations",
    title: "Linear Regression & Feature Engineering",
    date: "2026-07-03",
    time: "11:00 AM",
    duration: "2.5 hours",
    link: "https://meet.google.com/uvw-xyz1-abc",
    status: "Scheduled",
    studentCount: 35
  },
  {
    id: "sess-4",
    courseId: "react-adv",
    courseTitle: "Advanced React & Architecture",
    title: "Performance Optimization & Fiber Tree Reconciliation",
    date: "2026-06-30",
    time: "10:00 AM",
    duration: "2 hours",
    link: "https://meet.google.com/abc-defg-hij",
    status: "Completed",
    studentCount: 26
  }
];

export const initialAssignments: Assignment[] = [
  {
    id: "asg-1",
    courseId: "react-adv",
    courseTitle: "Advanced React & Architecture",
    title: "Custom Reactive State Orchestrator",
    description: "Build a highly optimized reactive state management library from scratch supporting atomic updates, memoized selectors, and deep nested path subscription tracking.",
    publishDate: "2026-06-25",
    dueDate: "2026-07-10",
    maxPoints: 100,
    status: "Published",
    submissions: [
      {
        id: "sub-1-1",
        studentId: "stu-1",
        studentName: "Courtney Henry",
        submittedAt: "2026-06-29 14:32",
        githubUrl: "https://github.com/courtney-h/reactive-orchestrator",
        notes: "Optimized atomic re-renders with a custom dependency tracker. Added robust tests with 98% coverage.",
        status: "Submitted",
        grade: null,
        feedback: null
      },
      {
        id: "sub-1-2",
        studentId: "stu-2",
        studentName: "Cody Fisher",
        submittedAt: "2026-06-30 09:15",
        githubUrl: "https://github.com/codyfisher/react-state-atomic",
        notes: "Supports custom transitions and concurrent scheduling. Solved memory leaks in useEffect bindings.",
        status: "Graded",
        grade: 98,
        feedback: "Outstanding structural organization. Deep understanding of concurrent rendering mechanics."
      }
    ]
  },
  {
    id: "asg-2",
    courseId: "swiss-typo",
    courseTitle: "Swiss Typography & Editorial Layout",
    title: "Modernist Tri-Fold Poster Design",
    description: "Design a grid-aligned tri-fold brochure celebrating Swiss graphic designers, utilizing strict baseline alignment and high contrast typographic hierarchies.",
    publishDate: "2026-06-20",
    dueDate: "2026-07-05",
    maxPoints: 100,
    status: "Published",
    submissions: [
      {
        id: "sub-2-1",
        studentId: "stu-4",
        studentName: "Eleanor Pena",
        submittedAt: "2026-06-28 17:05",
        githubUrl: "https://github.com/eleanor-p/swiss-grid-layout",
        notes: "Baseline grids are aligned perfectly. Used a clean black/white/red minimalist color palette.",
        status: "Submitted",
        grade: null,
        feedback: null
      }
    ]
  },
  {
    id: "asg-3",
    courseId: "ml-found",
    courseTitle: "AI & Machine Learning Foundations",
    title: "Gradient Descent Optimizer",
    description: "Implement Stochastic Gradient Descent from scratch. Analyze learning curves with various step values and plot custom training metrics.",
    publishDate: "2026-07-01",
    dueDate: "2026-07-18",
    maxPoints: 50,
    status: "Published",
    submissions: []
  }
];

export const initialDiscussions: DiscussionThread[] = [
  {
    id: "disc-1",
    courseId: "react-adv",
    courseTitle: "Advanced React & Architecture",
    studentName: "Courtney Henry",
    title: "Concurrent Mode & useTransition re-rendering",
    text: "Can someone clarify how react's virtual scheduler prioritizes states marked under useTransition? Is there a fiber lane allocation table I can reference?",
    time: "10:05 AM",
    status: "New",
    replies: [
      {
        id: "rep-1-1",
        sender: "Dr. Sarah Vance",
        role: "Instructor",
        time: "11:20 AM",
        text: "Yes, Courtney! React uses 31 lanes of update priority. Transition lanes are normally allocated from lanes 6 to 21. Look at the React Fiber Lane definitions in react-reconciler."
      }
    ]
  },
  {
    id: "disc-2",
    courseId: "swiss-typo",
    courseTitle: "Swiss Typography & Editorial Layout",
    studentName: "Eleanor Pena",
    title: "Strict baseline grids in CSS tailwind layouts",
    text: "When managing spacing in Tailwind, should we rely strictly on leading-relaxed or is it safer to configure custom tracking metrics to ensure absolute baseline match?",
    time: "Yesterday",
    status: "Replied",
    replies: [
      {
        id: "rep-2-1",
        sender: "Dr. Sarah Vance",
        role: "Instructor",
        time: "Yesterday",
        text: "Using a baseline pixel alignment helper or defining line-height in multiples of 4px in tailwind.config is usually the most resilient approach for clean Swiss styling."
      }
    ]
  },
  {
    id: "disc-3",
    courseId: "ml-found",
    courseTitle: "AI & Machine Learning Foundations",
    studentName: "Jane Cooper",
    title: "Underfitting on SGD with large learning rate",
    text: "Why is my cost function diverging when setting alpha to 0.05? It jumps between extreme ranges instead of settling.",
    time: "Monday",
    status: "Under Review",
    replies: []
  }
];

export const initialResources: Resource[] = [
  {
    id: "res-1",
    title: "Lecture 1: Fiber Tree Reconciliation & Concurrent Rendering Specs",
    courseId: "react-adv",
    courseTitle: "Advanced React & Architecture",
    fileType: "pdf",
    fileSize: "4.2 MB",
    uploadedAt: "2026-06-15"
  },
  {
    id: "res-2",
    title: "Full Course Syllabus & Reading Requirements (2026)",
    courseId: "react-adv",
    courseTitle: "Advanced React & Architecture",
    fileType: "doc",
    fileSize: "1.1 MB",
    uploadedAt: "2026-06-10"
  },
  {
    id: "res-3",
    title: "Baseline Layout Grids & Geometric System Templates",
    courseId: "swiss-typo",
    courseTitle: "Swiss Typography & Editorial Layout",
    fileType: "zip",
    fileSize: "18.5 MB",
    uploadedAt: "2026-06-21"
  },
  {
    id: "res-4",
    title: "Interactive Linear Algebra Refresher Workspace (Jupyter)",
    courseId: "ml-found",
    courseTitle: "AI & Machine Learning Foundations",
    fileType: "code",
    fileSize: "850 KB",
    uploadedAt: "2026-06-28"
  }
];

export const initialAnnouncements: Announcement[] = [
  {
    id: "ann-1",
    title: "Midterm Assignment Instructions Published",
    description: "The instructions and source boilerplate for the midterm custom orchestrator assignment are now active on the assignments page. Please review carefully.",
    courseId: "react-adv",
    courseTitle: "Advanced React & Architecture",
    audience: "All Students",
    publishedAt: "2026-06-25",
    status: "Published"
  },
  {
    id: "ann-2",
    title: "Guest Speaker Seminar: Typography Legend Erik Spiekermann",
    description: "We are thrilled to announce a virtual guest lecture with iconic typographer Erik Spiekermann next Tuesday. Mark your schedules!",
    courseId: "swiss-typo",
    courseTitle: "Swiss Typography & Editorial Layout",
    audience: "Design Department",
    publishedAt: "2026-06-28",
    status: "Published"
  }
];

export const initialGrades: GradeRecord[] = [
  {
    id: "grd-1",
    studentId: "stu-1",
    studentName: "Courtney Henry",
    courseId: "react-adv",
    courseTitle: "Advanced React & Architecture",
    assignmentId: "asg-1",
    assignmentTitle: "Custom Reactive State Orchestrator",
    score: 95,
    maxPoints: 100,
    letterGrade: "A",
    publishedDate: "2026-07-01"
  },
  {
    id: "grd-2",
    studentId: "stu-2",
    studentName: "Cody Fisher",
    courseId: "react-adv",
    courseTitle: "Advanced React & Architecture",
    assignmentId: "asg-1",
    assignmentTitle: "Custom Reactive State Orchestrator",
    score: 98,
    maxPoints: 100,
    letterGrade: "A",
    publishedDate: "2026-06-30"
  },
  {
    id: "grd-3",
    studentId: "stu-4",
    studentName: "Eleanor Pena",
    courseId: "swiss-typo",
    courseTitle: "Swiss Typography & Editorial Layout",
    assignmentId: "asg-2",
    assignmentTitle: "Modernist Tri-Fold Poster Design",
    score: 96,
    maxPoints: 100,
    letterGrade: "A",
    publishedDate: "2026-06-29"
  }
];

export const initialCertificates: Certificate[] = [
  {
    id: "cert-1",
    studentId: "stu-2",
    studentName: "Cody Fisher",
    courseId: "react-adv",
    courseTitle: "Advanced React & Architecture",
    gpa: 4.0,
    status: "Approved",
    issueDate: "2026-06-30"
  },
  {
    id: "cert-2",
    studentId: "stu-4",
    studentName: "Eleanor Pena",
    courseId: "swiss-typo",
    courseTitle: "Swiss Typography & Editorial Layout",
    gpa: 3.95,
    status: "Approved",
    issueDate: "2026-06-29"
  },
  {
    id: "cert-3",
    studentId: "stu-1",
    studentName: "Courtney Henry",
    courseId: "react-adv",
    courseTitle: "Advanced React & Architecture",
    gpa: 3.82,
    status: "Draft"
  }
];

export const initialCalendarEvents: CalendarEvent[] = [
  { id: "e1", title: "Advanced React Lecture", date: "2026-07-02", type: "Class", courseId: "react-adv", time: "10:00 AM" },
  { id: "e2", title: "Swiss Typography Seminar", date: "2026-07-02", type: "Class", courseId: "swiss-typo", time: "02:00 PM" },
  { id: "e3", title: "Poster Design Assignment Due", date: "2026-07-05", type: "Deadline", courseId: "swiss-typo", time: "11:59 PM" },
  { id: "e4", title: "AI/ML Lecture & SGD Review", date: "2026-07-03", type: "Class", courseId: "ml-found", time: "11:00 AM" },
  { id: "e5", title: "React Office Hours", date: "2026-07-04", type: "Office Hours", courseId: "react-adv", time: "03:00 PM" },
  { id: "e6", title: "Midterm Theory Exam", date: "2026-07-08", type: "Exam", courseId: "react-adv", time: "09:00 AM" },
  { id: "e7", title: "Academy Founders Day Holiday", date: "2026-07-07", type: "Holiday", time: "All Day" }
];

export const initialTeacherProfile: TeacherProfile = {
  name: "Sarah Vance",
  email: "teacher@academy.local",
  phone: "+98 9123456789",
  department: "Computer Science & Interactive Design",
  bio: "Dr. Sarah Vance holds a Ph.D. in Software Engineering from MIT. She specializes in reactive programming models, human-computer interaction, and typography layouts.",
  photo: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200&auto=format&fit=crop",
  status: "online",
  theme: "dark",
  titlePrefix: "Dr.",
  specialization: "Full Stack Developer",
  socialLinks: {
    github: "https://github.com/sarah-vance-phd",
    twitter: "https://twitter.com/sarah_vance",
    instagram: "https://instagram.com/sarah_v",
    linkedin: "https://linkedin.com/in/sarah-vance-phd",
    telegram: "https://t.me/sarah_vance"
  }
};
