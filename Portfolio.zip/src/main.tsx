import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { initializeDatabaseSync } from './db_sync.ts';

// Transparently synchronize local storage with backend Express + MySQL database on boot
initializeDatabaseSync().then(() => {
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
}).catch(err => {
  console.error("Database sync failed to initialize:", err);
  // Guarantee system boot-up even if sync has fatal rejects
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
});

