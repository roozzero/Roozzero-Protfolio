import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  LayoutDashboard,
  BookOpen,
  Users,
  Clock,
  CheckSquare,
  MessageSquare,
  FolderOpen,
  ClipboardList,
  Megaphone,
  GraduationCap,
  Award,
  Calendar,
  BarChart3,
  Settings,
  LogOut,
  Search,
  Plus,
  Trash2,
  Edit2,
  Download,
  CheckCircle2,
  AlertTriangle,
  X,
  Play,
  ArrowRight,
  Eye,
  Check,
  ChevronLeft,
  ChevronRight,
  Calendar as CalendarIcon
} from "lucide-react";

import {
  Course,
  Student,
  Session,
  Assignment,
  DiscussionThread,
  Resource,
  Announcement,
  GradeRecord,
  Certificate,
  CalendarEvent,
  TeacherProfile,
  CourseSeason
} from "../types/teacher";

const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

const initialCourseSeasons: CourseSeason[] = [
  {
    id: "season-1",
    name: "Summer 2026 Core",
    courseId: "react-adv",
    courseTitle: "Advanced React & Architecture",
    startDate: "2026-06-01",
    endDate: "2026-08-31",
    maxCapacity: 25,
    registrationStatus: "Open",
    notes: "Intense 3-month track covering Vite, Tailwind, and Redux architecture.",
    status: "Active"
  },
  {
    id: "season-2",
    name: "Autumn 2026 Typography",
    courseId: "swiss-typo",
    courseTitle: "Swiss Typography & Editorial Layout",
    startDate: "2026-09-01",
    endDate: "2026-11-30",
    maxCapacity: 20,
    registrationStatus: "Not Available",
    notes: "Requires Swiss Design Basics as a prerequisite.",
    status: "Pending Admin Approval"
  }
];

import {
  initialCourses,
  initialStudents,
  initialSessions,
  initialAssignments,
  initialDiscussions,
  initialResources,
  initialAnnouncements,
  initialGrades,
  initialCertificates,
  initialCalendarEvents,
  initialTeacherProfile
} from "../data/teacherMockData";

// Import modular sub-tabs
import DashboardTab from "./TeacherDashboard/DashboardTab";
import CoursesTab from "./TeacherDashboard/CoursesTab";
import StudentsTab from "./TeacherDashboard/StudentsTab";
import AssignmentsTab from "./TeacherDashboard/AssignmentsTab";
import ResourcesTab from "./TeacherDashboard/ResourcesTab";
import AnalyticsTab from "./TeacherDashboard/AnalyticsTab";
import SettingsTab from "./TeacherDashboard/SettingsTab";

interface TeacherDashboardProps {
  onLogout?: () => void;
  onGoHome?: () => void;
}

export default function TeacherDashboard({ onLogout, onGoHome }: TeacherDashboardProps) {
  // Navigation State
  const [activeTab, setActiveTab] = useState<string>("dashboard");

  // Core Data States
  const [courses, setCourses] = useState<Course[]>(() => {
    const saved = localStorage.getItem("teacher_courses");
    return saved ? JSON.parse(saved) : initialCourses;
  });
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem("teacher_students");
    return saved ? JSON.parse(saved) : initialStudents;
  });
  const [sessions, setSessions] = useState<Session[]>(() => {
    const saved = localStorage.getItem("teacher_sessions");
    return saved ? JSON.parse(saved) : initialSessions;
  });
  const [assignments, setAssignments] = useState<Assignment[]>(() => {
    const saved = localStorage.getItem("teacher_assignments");
    return saved ? JSON.parse(saved) : initialAssignments;
  });
  const [discussions, setDiscussions] = useState<DiscussionThread[]>(() => {
    const saved = localStorage.getItem("teacher_discussions");
    return saved ? JSON.parse(saved) : initialDiscussions;
  });
  const [resources, setResources] = useState<Resource[]>(() => {
    const saved = localStorage.getItem("teacher_resources");
    return saved ? JSON.parse(saved) : initialResources;
  });
  const [announcements, setAnnouncements] = useState<Announcement[]>(() => {
    const saved = localStorage.getItem("teacher_announcements");
    return saved ? JSON.parse(saved) : initialAnnouncements;
  });
  const [grades, setGrades] = useState<GradeRecord[]>(() => {
    const saved = localStorage.getItem("teacher_grades");
    return saved ? JSON.parse(saved) : initialGrades;
  });
  const [certificates, setCertificates] = useState<Certificate[]>(() => {
    const saved = localStorage.getItem("teacher_certificates");
    return saved ? JSON.parse(saved) : initialCertificates;
  });
  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>(() => {
    const saved = localStorage.getItem("teacher_calendar_events");
    return saved ? JSON.parse(saved) : initialCalendarEvents;
  });
  const [profile, setProfile] = useState<TeacherProfile>(initialTeacherProfile);
  const [courseSeasons, setCourseSeasons] = useState<CourseSeason[]>(initialCourseSeasons);

  // Sync core states to localStorage
  React.useEffect(() => {
    localStorage.setItem("teacher_courses", JSON.stringify(courses));
  }, [courses]);
  React.useEffect(() => {
    localStorage.setItem("teacher_students", JSON.stringify(students));
  }, [students]);
  React.useEffect(() => {
    localStorage.setItem("teacher_sessions", JSON.stringify(sessions));
  }, [sessions]);
  React.useEffect(() => {
    localStorage.setItem("teacher_assignments", JSON.stringify(assignments));
  }, [assignments]);
  React.useEffect(() => {
    localStorage.setItem("teacher_discussions", JSON.stringify(discussions));
  }, [discussions]);
  React.useEffect(() => {
    localStorage.setItem("teacher_resources", JSON.stringify(resources));
  }, [resources]);
  React.useEffect(() => {
    localStorage.setItem("teacher_announcements", JSON.stringify(announcements));
  }, [announcements]);
  React.useEffect(() => {
    localStorage.setItem("teacher_grades", JSON.stringify(grades));
  }, [grades]);
  React.useEffect(() => {
    localStorage.setItem("teacher_certificates", JSON.stringify(certificates));
  }, [certificates]);
  React.useEffect(() => {
    localStorage.setItem("teacher_calendar_events", JSON.stringify(calendarEvents));
  }, [calendarEvents]);

  // Start Masterclass modal states
  const [selectedSessionToStart, setSelectedSessionToStart] = useState<Session | null>(null);
  const [isStartClassModalOpen, setIsStartClassModalOpen] = useState(false);
  const [meetingPlatform, setMeetingPlatform] = useState("Google Meet");
  const [meetingPlatformCustom, setMeetingPlatformCustom] = useState("");
  const [meetingLink, setMeetingLink] = useState("");
  const [isSavingMeeting, setIsSavingMeeting] = useState(false);
  const [meetingLinkError, setMeetingLinkError] = useState("");

  // Toast Notification State
  const [customToasts, setCustomToasts] = useState<{ id: string; message: string; type: "info" | "success" | "warning" }[]>([]);

  const showCustomToast = (message: string, type: "info" | "success" | "warning" = "info") => {
    const id = Math.random().toString(36).substr(2, 9);
    setCustomToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setCustomToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  // State mutator helpers (LMS logic)
  const handleCreateCourse = (newC: Omit<Course, "id" | "progress">) => {
    const id = `course-${Date.now()}`;
    const course: Course = { ...newC, id, progress: 0 };
    setCourses((prev) => [...prev, course]);
    showCustomToast(`Course "${newC.title}" published!`, "success");
  };

  const handleToggleCourseStatus = (courseId: string) => {
    setCourses((prev) =>
      prev.map((c) => {
        if (c.id === courseId) {
          const nextStatus = c.status === "Active" ? "Finished" : "Active";
          showCustomToast(`Course status updated to ${nextStatus}`, "info");
          return { ...c, status: nextStatus };
        }
        return c;
      })
    );
  };

  const handleSendMessage = (studentName: string) => {
    showCustomToast(`Administrative notice transmitted to ${studentName}!`, "success");
  };

  const handleGradeStudentOverride = (studentId: string, gradeScore: number) => {
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id === studentId) {
          return { ...s, avgGrade: gradeScore };
        }
        return s;
      })
    );
    showCustomToast(`Overrode average grade to ${gradeScore}%`, "success");
  };

  const handleCreateAssignment = (newA: Omit<Assignment, "id" | "submissions">) => {
    const id = `asg-${Date.now()}`;
    const asg: Assignment = { ...newA, id, submissions: [] };
    setAssignments((prev) => [...prev, asg]);
  };

  const handleGradeSubmission = (asgId: string, subId: string, score: number, feedback: string, correctedFile?: string) => {
    setAssignments((prev) =>
      prev.map((asg) => {
        if (asg.id === asgId) {
          const updatedSub = asg.submissions.map((sub) => {
            if (sub.id === subId) {
              return {
                ...sub,
                status: "Graded" as const,
                grade: score,
                feedback,
                correctedFileName: correctedFile
              };
            }
            return sub;
          });
          return { ...asg, submissions: updatedSub };
        }
        return asg;
      })
    );
  };

  const handleUploadResource = (newR: Omit<Resource, "id" | "uploadedAt">) => {
    const id = `res-${Date.now()}`;
    const res: Resource = {
      ...newR,
      id,
      uploadedAt: new Date().toISOString().split("T")[0]
    };
    setResources((prev) => [...prev, res]);
  };

  const handleDeleteResource = (resId: string) => {
    setResources((prev) => prev.filter((r) => r.id !== resId));
    showCustomToast("Resource deleted from curriculum repository.", "info");
  };

  const handleReplaceResource = (resId: string, updatedRes: Resource) => {
    setResources((prev) =>
      prev.map((r) => (r.id === resId ? updatedRes : r))
    );
  };

  const handleCreateSeason = (season: Omit<CourseSeason, "id">) => {
    const id = `season-${Date.now()}`;
    setCourseSeasons((prev) => [...prev, { ...season, id }]);
    showCustomToast(`Course season "${season.name}" proposed for admin approval!`, "success");
  };

  const handleUpdateSeason = (season: CourseSeason) => {
    setCourseSeasons((prev) => prev.map((s) => (s.id === season.id ? season : s)));
    showCustomToast(`Course season "${season.name}" updated!`, "success");
  };

  const handleDeleteSeason = (seasonId: string) => {
    setCourseSeasons((prev) => prev.filter((s) => s.id !== seasonId));
    showCustomToast("Course season deleted.", "info");
  };

  const handleSaveProfile = (updated: TeacherProfile) => {
    setProfile(updated);
  };

  // Course mapping helper: Teacher -> Student
  const mapTeacherCourseIdToStudentCourseId = (teacherCourseId: string): string => {
    if (teacherCourseId === "react-adv") return "1";
    if (teacherCourseId === "swiss-typo") return "2";
    if (teacherCourseId === "ml-found") return "3";
    return "1";
  };

  // Student course sessions generator fallback
  const generateInitialSessions = (): { [courseId: string]: any[] } => {
    return {
      "1": [
        { id: "1-1", sessionNum: 1, topic: "Vite & HMR Essentials", duration: "90 Mins", date: "June 03, 2026", time: "10:00 AM – 11:30 AM", status: "Completed" },
        { id: "1-2", sessionNum: 2, topic: "State Managers & Flux", duration: "90 Mins", date: "June 10, 2026", time: "10:00 AM – 11:30 AM", status: "Completed" },
        { id: "1-3", sessionNum: 3, topic: "Component Modeling", duration: "90 Mins", date: "June 17, 2026", time: "10:00 AM – 11:30 AM", status: "Completed" },
        { id: "1-4", sessionNum: 4, topic: "Custom Hooks", duration: "90 Mins", date: "June 24, 2026", time: "10:00 AM – 11:30 AM", status: "Completed" },
        { id: "1-5", sessionNum: 5, topic: "Concurrent Rendering", duration: "90 Mins", date: "July 01, 2026", time: "10:00 AM – 11:30 AM", status: "Completed" },
        { id: "1-6", sessionNum: 6, topic: "Fiber Architecture", duration: "90 Mins", date: "July 08, 2026", time: "10:00 AM – 11:30 AM", status: "Completed" },
        { id: "1-7", sessionNum: 7, topic: "Suspense & Transitions", duration: "90 Mins", date: "July 15, 2026", time: "10:00 AM – 11:30 AM", status: "Completed" },
        { id: "1-8", sessionNum: 8, topic: "Server Components", duration: "90 Mins", date: "July 22, 2026", time: "10:00 AM – 11:30 AM", status: "Completed" },
        { id: "1-9", sessionNum: 9, topic: "Performance Tuning", duration: "90 Mins", date: "July 29, 2026", time: "10:00 AM – 11:30 AM", status: "Scheduled", meetingLink: "https://zoom.us/j/98765432101" },
        { id: "1-10", sessionNum: 10, topic: "Memory Leak Audits", duration: "90 Mins", date: "August 05, 2026", time: "10:00 AM – 11:30 AM", status: "Not Held" },
        { id: "1-11", sessionNum: 11, topic: "Testing & Mocking", duration: "90 Mins", date: "August 12, 2026", time: "10:00 AM – 11:30 AM", status: "Cancelled", cancellationReason: "Instructor attending React Global Summit. Content moved to Session 12 self-study." },
        { id: "1-12", sessionNum: 12, topic: "Production Deployment", duration: "90 Mins", date: "August 19, 2026", time: "10:00 AM – 11:30 AM", status: "Not Held" }
      ],
      "2": [
        { id: "2-1", sessionNum: 1, topic: "Swiss Typography", duration: "90 Mins", date: "May 12, 2026", time: "14:00 – 15:30", status: "Completed" },
        { id: "2-2", sessionNum: 2, topic: "Color Theory & Contrast", duration: "90 Mins", date: "May 19, 2026", time: "14:00 – 15:30", status: "Completed" },
        { id: "2-3", sessionNum: 3, topic: "Tailwind Variables", duration: "90 Mins", date: "May 26, 2026", time: "14:00 – 15:30", status: "Completed" },
        { id: "2-4", sessionNum: 4, topic: "Micro-interactions", duration: "90 Mins", date: "June 02, 2026", time: "14:00 – 15:30", status: "Completed" },
        { id: "2-5", sessionNum: 5, topic: "Bento Grid Layouts", duration: "90 Mins", date: "June 09, 2026", time: "14:00 – 15:30", status: "Completed" },
        { id: "2-6", sessionNum: 6, topic: "Dark Mode Principles", duration: "90 Mins", date: "June 16, 2026", time: "14:00 – 15:30", status: "Completed" },
        { id: "2-7", sessionNum: 7, topic: "Fluid Layouts & Spacing", duration: "90 Mins", date: "June 23, 2026", time: "14:00 – 15:30", status: "Completed" },
        { id: "2-8", sessionNum: 8, topic: "Motion Design", duration: "90 Mins", date: "June 30, 2026", time: "14:00 – 15:30", status: "Completed" },
        { id: "2-9", sessionNum: 9, topic: "Component Libraries", duration: "90 Mins", date: "July 07, 2026", time: "14:00 – 15:30", status: "Completed" },
        { id: "2-10", sessionNum: 10, topic: "System Documentation", duration: "90 Mins", date: "July 14, 2026", time: "14:00 – 15:30", status: "Completed" }
      ],
      "3": [
        { id: "3-1", sessionNum: 1, topic: "Linear Regression Foundations", duration: "120 Mins", date: "July 15, 2026", time: "14:00 – 16:00", status: "Scheduled", meetingLink: "https://zoom.us/j/12345678901" },
        { id: "3-2", sessionNum: 2, topic: "Gradient Descent Algorithms", duration: "120 Mins", date: "July 22, 2026", time: "14:00 – 16:00", status: "Not Held" },
        { id: "3-3", sessionNum: 3, topic: "Multi-layer Perceptrons", duration: "120 Mins", date: "July 29, 2026", time: "14:00 – 16:00", status: "Not Held" },
        { id: "3-4", sessionNum: 4, topic: "Neural Network Tuning", duration: "120 Mins", date: "August 05, 2026", time: "14:00 – 16:00", status: "Not Held" },
        { id: "3-5", sessionNum: 5, topic: "Fine-tuning Models", duration: "120 Mins", date: "August 12, 2026", time: "14:00 – 16:00", status: "Not Held" },
        { id: "3-6", sessionNum: 6, topic: "Prompt Engineering", duration: "120 Mins", date: "August 19, 2026", time: "14:00 – 16:00", status: "Not Held" },
        { id: "3-7", sessionNum: 7, topic: "Transformer Models", duration: "120 Mins", date: "August 26, 2026", time: "14:00 – 16:00", status: "Not Held" },
        { id: "3-8", sessionNum: 8, topic: "Attention Mechanisms", duration: "120 Mins", date: "September 02, 2026", time: "14:00 – 16:00", status: "Not Held" },
        { id: "3-9", sessionNum: 9, topic: "Convolutional Nets", duration: "120 Mins", date: "September 09, 2026", time: "14:00 – 16:00", status: "Not Held" },
        { id: "3-10", sessionNum: 10, topic: "Recurrent Architectures", duration: "120 Mins", date: "September 16, 2026", time: "14:00 – 16:00", status: "Not Held" },
        { id: "3-11", sessionNum: 11, topic: "Reinforcement Learning", duration: "120 Mins", date: "September 23, 2026", time: "14:00 – 16:00", status: "Not Held" },
        { id: "3-12", sessionNum: 12, topic: "Generative Adversarial Nets", duration: "120 Mins", date: "September 30, 2026", time: "14:00 – 16:00", status: "Not Held" },
        { id: "3-13", sessionNum: 13, topic: "Clustering & SVMs", duration: "120 Mins", date: "October 07, 2026", time: "14:00 – 16:00", status: "Not Held" },
        { id: "3-14", sessionNum: 14, topic: "PCA & Dimension Reduction", duration: "120 Mins", date: "October 14, 2026", time: "14:00 – 16:00", status: "Not Held" },
        { id: "3-15", sessionNum: 15, topic: "Final ML Capstone", duration: "120 Mins", date: "October 21, 2026", time: "14:00 – 16:00", status: "Not Held" }
      ]
    };
  };

  const findMatchingStudentSession = (studentSessions: any[], teacherTitle: string) => {
    const normalizedTeacher = teacherTitle.toLowerCase();
    let match = studentSessions.find((s: any) => 
      normalizedTeacher.includes(s.topic.toLowerCase()) || 
      s.topic.toLowerCase().includes(normalizedTeacher)
    );
    if (match) return match;

    const teacherWords = normalizedTeacher.split(/\s+/).filter((w: string) => w.length > 3);
    match = studentSessions.find((s: any) => {
      const studentWords = s.topic.toLowerCase().split(/\s+/);
      return teacherWords.some((tw: string) => studentWords.includes(tw));
    });
    if (match) return match;

    match = studentSessions.find((s: any) => s.status === "Scheduled");
    if (match) return match;

    match = studentSessions.find((s: any) => s.status === "Not Held");
    if (match) return match;

    return studentSessions[studentSessions.length - 1];
  };

  const handleStartMasterclassInitiate = (sess: Session) => {
    setSelectedSessionToStart(sess);
    setMeetingPlatform("Google Meet");
    setMeetingPlatformCustom("");
    setMeetingLink(sess.link || "");
    setMeetingLinkError("");
    setIsStartClassModalOpen(true);
  };

  const handleStartMasterclassSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSessionToStart) return;

    let isUrlValid = false;
    try {
      const url = new URL(meetingLink);
      isUrlValid = url.protocol === "http:" || url.protocol === "https:";
    } catch (_) {
      isUrlValid = false;
    }

    if (!isUrlValid) {
      setMeetingLinkError("Please enter a valid URL (starting with http:// or https://)");
      return;
    }

    setIsSavingMeeting(true);

    setTimeout(() => {
      const chosenPlatform = meetingPlatform === "Other" ? meetingPlatformCustom || "Other" : meetingPlatform;

      // 1. Update teacher sessions list
      const updatedSessions = sessions.map(s => {
        if (s.id === selectedSessionToStart.id) {
          return {
            ...s,
            link: meetingLink,
            meetingPlatform: chosenPlatform,
            status: "Scheduled" as const
          };
        }
        return s;
      });
      setSessions(updatedSessions);
      localStorage.setItem("teacher_sessions", JSON.stringify(updatedSessions));

      // 2. Synchronize to student's sessions list
      const studentCourseId = mapTeacherCourseIdToStudentCourseId(selectedSessionToStart.courseId);
      const savedStudentSessionsRaw = localStorage.getItem("student_course_sessions");
      const currentStudentCourseSessions = savedStudentSessionsRaw ? JSON.parse(savedStudentSessionsRaw) : generateInitialSessions();
      const courseSessionsList = currentStudentCourseSessions[studentCourseId] || [];

      const matchedStudentSess = findMatchingStudentSession(courseSessionsList, selectedSessionToStart.title);
      if (matchedStudentSess) {
        currentStudentCourseSessions[studentCourseId] = courseSessionsList.map((s: any) => {
          if (s.id === matchedStudentSess.id) {
            return {
              ...s,
              meetingLink: meetingLink,
              meetingPlatform: chosenPlatform,
              status: "Scheduled" as const
            };
          }
          return s;
        });
        localStorage.setItem("student_course_sessions", JSON.stringify(currentStudentCourseSessions));

        // Mark this session as active in simulated deck
        const savedSimActive = localStorage.getItem("student_sim_active_sessions") || "{}";
        const simActive = JSON.parse(savedSimActive);
        simActive[matchedStudentSess.id] = true;
        localStorage.setItem("student_sim_active_sessions", JSON.stringify(simActive));
      }

      setIsSavingMeeting(false);
      setIsStartClassModalOpen(false);
      showCustomToast("Masterclass meeting link synchronized successfully!", "success");
    }, 1000);
  };

  // Quick action controller
  const handleQuickAction = (action: string) => {
    switch (action) {
      case "create-assignment":
        setActiveTab("assignments");
        showCustomToast("Navigated to Assignments. Click 'Create Assignment' button.", "info");
        break;
      case "send-announcement":
        setActiveTab("announcements");
        showCustomToast("Navigated to Announcements to broadcast alerts.", "info");
        break;
      case "upload-resource":
        setActiveTab("resources");
        showCustomToast("Navigated to resources repository folder.", "info");
        break;
      case "create-meeting":
        setActiveTab("calendar");
        showCustomToast("Ready to schedule an office hour or test.", "info");
        break;
      case "start-class":
        // Find the first scheduled session to initiate starting a class
        const firstSched = sessions.find(s => s.status === "Scheduled");
        if (firstSched) {
          handleStartMasterclassInitiate(firstSched);
        } else {
          showCustomToast("No scheduled masterclasses available to start right now.", "warning");
        }
        break;
    }
  };

  // Compact states & helpers for Schedule, Discussions, Attendance, Announcements, Grades, Certificates, Calendar
  // 1. SCHEDULE TAB
  const [scheduleDate, setScheduleDate] = useState("2026-07-02");
  const [showAddSessionModal, setShowAddSessionModal] = useState(false);
  const [sessionTitle, setSessionTitle] = useState("");
  const [sessionTime, setSessionTime] = useState("");
  const [sessionDuration, setSessionDuration] = useState("2 hours");
  const [sessionCourseId, setSessionCourseId] = useState("");

  const handleAddSessionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (sessionTitle && sessionTime && sessionCourseId) {
      const course = courses.find((c) => c.id === sessionCourseId);
      const newS: Session = {
        id: `sess-${Date.now()}`,
        courseId: sessionCourseId,
        courseTitle: course ? course.title : "Academy Course",
        title: sessionTitle,
        date: scheduleDate,
        time: sessionTime,
        duration: sessionDuration,
        link: "https://meet.google.com/xyz-abc-123",
        status: "Scheduled",
        studentCount: course ? course.studentsCount : 20
      };
      setSessions((prev) => [...prev, newS]);
      showCustomToast("Scheduled new class session!", "success");
      setSessionTitle("");
      setSessionTime("");
      setShowAddSessionModal(false);
    }
  };

  // 2. DISCUSSIONS TAB
  const [discussionSearch, setDiscussionSearch] = useState("");
  const [discussionCourseFilter, setDiscussionCourseFilter] = useState("all");
  const [activeDiscussion, setActiveDiscussion] = useState<DiscussionThread | null>(null);
  const [discussionReply, setDiscussionReply] = useState("");

  const filteredDiscussions = useMemo(() => {
    return discussions.filter((d) => {
      const matchSearch =
        d.title.toLowerCase().includes(discussionSearch.toLowerCase()) ||
        d.studentName.toLowerCase().includes(discussionSearch.toLowerCase());
      const matchCourse = discussionCourseFilter === "all" || d.courseId === discussionCourseFilter;
      return matchSearch && matchCourse;
    });
  }, [discussions, discussionSearch, discussionCourseFilter]);

  const handleSendDiscussionReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (activeDiscussion && discussionReply) {
      setDiscussions((prev) =>
        prev.map((d) => {
          if (d.id === activeDiscussion.id) {
            const updatedReplies = [
              ...d.replies,
              {
                id: `rep-${Date.now()}`,
                sender: profile.titlePrefix ? `${profile.titlePrefix} ${profile.name}` : profile.name,
                role: "Instructor" as const,
                time: "Just now",
                text: discussionReply
              }
            ];
            const updated = {
              ...d,
              status: "Replied" as const,
              replies: updatedReplies
            };
            // Sync modal focus
            setActiveDiscussion(updated);
            return updated;
          }
          return d;
        })
      );
      showCustomToast("Reply posted to thread!", "success");
      setDiscussionReply("");
    }
  };

  const handleToggleDiscussionStatus = (id: string, nextStatus: "Closed" | "Replied") => {
    setDiscussions((prev) =>
      prev.map((d) => {
        if (d.id === id) {
          showCustomToast(`Forum thread status set to ${nextStatus}`, "info");
          const updated = { ...d, status: nextStatus };
          if (activeDiscussion && activeDiscussion.id === id) {
            setActiveDiscussion(updated);
          }
          return updated;
        }
        return d;
      })
    );
  };

  // 3. ATTENDANCE TAB
  const [attendanceCourseId, setAttendanceCourseId] = useState("react-adv");
  const [attendanceSessionId, setAttendanceSessionId] = useState("sess-4");
  const [sessionAttendance, setSessionAttendance] = useState<{
    [sessionId: string]: { [studentId: string]: "Present" | "Absent" | "Late" | "Excused" }
  }>({
    "sess-4": {
      "stu-1": "Present",
      "stu-2": "Present",
      "stu-7": "Absent"
    }
  });

  const completedSessions = useMemo(() => {
    return sessions.filter((s) => s.courseId === attendanceCourseId && s.status === "Completed");
  }, [sessions, attendanceCourseId]);

  React.useEffect(() => {
    if (completedSessions.length > 0) {
      if (!completedSessions.some((s) => s.id === attendanceSessionId)) {
        setAttendanceSessionId(completedSessions[0].id);
      }
    } else {
      setAttendanceSessionId("");
    }
  }, [attendanceCourseId, completedSessions, attendanceSessionId]);

  const attendanceStudents = useMemo(() => {
    return students.filter((s) => s.courseId === attendanceCourseId);
  }, [students, attendanceCourseId]);

  const handleMarkAttendance = (studentId: string, status: "Present" | "Absent" | "Late" | "Excused") => {
    if (!attendanceSessionId) return;
    setSessionAttendance((prev) => ({
      ...prev,
      [attendanceSessionId]: {
        ...(prev[attendanceSessionId] || {}),
        [studentId]: status
      }
    }));

    // Instantly adjust total student attendance level to show live recalculation
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id === studentId) {
          let nextAttendance = s.attendance;
          if (status === "Present") nextAttendance = Math.min(100, s.attendance + 2);
          if (status === "Absent") nextAttendance = Math.max(0, s.attendance - 5);
          return { ...s, attendance: nextAttendance };
        }
        return s;
      })
    );
    showCustomToast(`Attendance registered! Student metrics synced.`, "success");
  };

  // 4. ANNOUNCEMENTS TAB
  const [annTitle, setAnnTitle] = useState("");
  const [annCourse, setAnnCourse] = useState("");
  const [annDesc, setAnnDesc] = useState("");
  const [annToDelete, setAnnToDelete] = useState<Announcement | null>(null);

  const handleAnnouncePublish = (e: React.FormEvent) => {
    e.preventDefault();
    if (annTitle && annCourse && annDesc) {
      const course = courses.find((c) => c.id === annCourse);
      const newAnn: Announcement = {
        id: `ann-${Date.now()}`,
        title: annTitle,
        description: annDesc,
        courseId: annCourse,
        courseTitle: course ? course.title : "Academy Course",
        audience: "All Students",
        publishedAt: new Date().toISOString().split("T")[0],
        status: "Published"
      };
      setAnnouncements((prev) => [newAnn, ...prev]);
      showCustomToast("Announcement published live to dashboard!", "success");
      setAnnTitle("");
      setAnnDesc("");
    }
  };

  const handleDeleteAnnouncement = () => {
    if (annToDelete) {
      setAnnouncements((prev) => prev.filter((ann) => ann.id !== annToDelete.id));
      showCustomToast("Announcement deleted successfully!", "success");
      setAnnToDelete(null);
    }
  };

  // 5. GRADES MATRIX TAB
  const [gradesCourseFilter, setGradesCourseFilter] = useState("react-adv");
  const [gradeEditStudentId, setGradeEditStudentId] = useState<string | null>(null);
  const [gradeScoreInput, setGradeScoreInput] = useState("");

  const handleSaveGradeMatrix = (studentId: string, currentScore: number) => {
    const parsed = parseInt(gradeScoreInput);
    if (isNaN(parsed) || parsed < 0 || parsed > 100) {
      showCustomToast("Enter a valid percentage score (0 - 100)", "warning");
      return;
    }
    // Update students average grade
    setStudents((prev) =>
      prev.map((s) => (s.id === studentId ? { ...s, avgGrade: parsed } : s))
    );
    setGradeEditStudentId(null);
    showCustomToast("Grade matriculation locked!", "success");
  };

  // 6. CERTIFICATES DESK TAB
  const handleSignCertificate = (certId: string) => {
    const cert = certificates.find((c) => c.id === certId);
    if (!cert) return;

    const course = courses.find((c) => c.id === cert.courseId);
    if (!course || course.status !== "Finished") {
      showCustomToast(`Signing blocked. Course "${cert.courseTitle}" is currently Active.`, "warning");
      return;
    }

    setCertificates((prev) =>
      prev.map((c) => {
        if (c.id === certId) {
          showCustomToast(`Certificate signed & submitted for Admin Approval!`, "success");
          return {
            ...c,
            status: "Waiting for Admin Approval" as any,
            issueDate: new Date().toISOString().split("T")[0]
          };
        }
        return c;
      })
    );
  };

  const handleSimulateAdminDecision = (certId: string, decision: "Approved" | "Rejected") => {
    setCertificates((prev) =>
      prev.map((c) => {
        if (c.id === certId) {
          showCustomToast(`Admin decision simulated: ${decision}!`, "info");
          return {
            ...c,
            status: decision as any,
            issueDate: decision === "Approved" ? new Date().toISOString().split("T")[0] : undefined
          };
        }
        return c;
      })
    );
  };

  const [certificateStatusFilter, setCertificateStatusFilter] = useState("All");

  // 7. CALENDAR MASTER GRID TAB
  const [calendarYear, setCalendarYear] = useState(2026);
  const [calendarMonth, setCalendarMonth] = useState(6); // July (0-indexed)
  const [selectedCalendarDay, setSelectedCalendarDay] = useState<number | null>(null);
  const [newCalendarEventTitle, setNewCalendarEventTitle] = useState("");
  const [newCalendarEventType, setNewCalendarEventType] = useState<"Class" | "Exam" | "Deadline" | "Office Hours" | "Holiday">("Office Hours");

  const calendarDays = useMemo(() => {
    const firstDayIndex = new Date(calendarYear, calendarMonth, 1).getDay();
    const daysInMonth = new Date(calendarYear, calendarMonth + 1, 0).getDate();
    const padding = Array(firstDayIndex).fill(null);
    const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
    return [...padding, ...days];
  }, [calendarYear, calendarMonth]);

  const handlePrevMonth = () => {
    setCalendarMonth((prev) => {
      if (prev === 0) {
        setCalendarYear((y) => y - 1);
        return 11;
      }
      return prev - 1;
    });
    setSelectedCalendarDay(null);
  };

  const handleNextMonth = () => {
    setCalendarMonth((prev) => {
      if (prev === 11) {
        setCalendarYear((y) => y + 1);
        return 0;
      }
      return prev + 1;
    });
    setSelectedCalendarDay(null);
  };

  const handleGoToToday = () => {
    setCalendarYear(2026);
    setCalendarMonth(6);
    setSelectedCalendarDay(null);
    showCustomToast("Returned to Academic Baseline (July 2026)", "success");
  };

  const handleAddCalendarEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedCalendarDay && newCalendarEventTitle) {
      const mm = String(calendarMonth + 1).padStart(2, "0");
      const dd = String(selectedCalendarDay).padStart(2, "0");
      const dateString = `${calendarYear}-${mm}-${dd}`;
      const newE: CalendarEvent = {
        id: `cal-${Date.now()}`,
        title: newCalendarEventTitle,
        date: dateString,
        type: newCalendarEventType,
        time: "02:00 PM"
      };
      setCalendarEvents((prev) => [...prev, newE]);
      showCustomToast(`Event scheduled for ${dateString}!`, "success");
      setNewCalendarEventTitle("");
      setSelectedCalendarDay(null);
    }
  };

  const handleDeleteCalendarEvent = (id: string) => {
    setCalendarEvents((prev) => prev.filter((e) => e.id !== id));
    showCustomToast("Event removed from calendar.", "info");
  };

  const getActiveMode = () => {
    if (profile.theme === "system") {
      if (typeof window !== "undefined" && window.matchMedia) {
        return window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
      }
      return "dark";
    }
    return profile.theme;
  };

  return (
    <div className={`min-h-screen bg-[#030304] relative flex text-white ${getActiveMode() === "light" ? "theme-light text-slate-900" : ""}`}>
      {/* Background radial spotlight circles */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[500px] pointer-events-none blur-[180px] bg-gradient-to-tr from-indigo-500/[0.03] via-purple-500/[0.03] to-emerald-500/[0.02] rounded-full z-0" />

      {/* SIDEBAR NAVIGATION PANEL */}
      <aside className="hidden md:flex flex-col w-64 bg-[#060609]/95 backdrop-blur-md border-r border-white/[0.05] h-screen sticky top-0 shrink-0 z-20 p-5">
        {/* Instructor profile header in sidebar */}
        <div className="flex items-center justify-between p-2 rounded-2xl bg-white/[0.02] border border-white/[0.05] hover:border-white/10 transition-all duration-300 mb-5 shrink-0">
          <div className="flex items-center gap-3">
            <div className="relative group">
              <img
                src={profile.photo}
                alt={profile.name}
                className="h-11 w-11 rounded-full border border-white/10 object-cover"
              />
              <div className="absolute bottom-0.5 right-0.5 h-2.5 w-2.5 rounded-full bg-emerald-500 border border-[#060609]" />
            </div>
            <div className="space-y-0.5 text-left">
              <h4 className="font-sans text-xs font-bold text-white tracking-tight leading-tight">
                {profile.titlePrefix ? `${profile.titlePrefix} ` : ""}{profile.name}
              </h4>
              <span className="block text-[9px] text-indigo-400 font-extrabold tracking-widest uppercase">
                Instructor
              </span>
            </div>
          </div>

          <button
            onClick={onLogout}
            className="p-2 rounded-xl text-white/40 hover:text-red-400 hover:bg-white/[0.04] transition-all border border-transparent hover:border-white/[0.05] cursor-pointer"
            title="Logout Account"
          >
            <LogOut size={14} />
          </button>
        </div>

        {/* SIDEBAR MENUS (Independently scrollable) */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-1 select-none scrollbar-thin scrollbar-track-transparent scrollbar-thumb-white/10 mb-4 text-left">
          <nav className="space-y-1">
            {[
              { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
              { id: "courses", label: "My Courses", icon: BookOpen },
              { id: "students", label: "Students", icon: Users },
              { id: "schedule", label: "Schedule", icon: Clock },
              { id: "assignments", label: "Assignments", icon: CheckSquare },
              { id: "discussions", label: "Discussions", icon: MessageSquare, badge: discussions.filter((d) => d.status === "New").length },
              { id: "resources", label: "Resources", icon: FolderOpen },
              { id: "attendance", label: "Attendance", icon: ClipboardList },
              { id: "announcements", label: "Announcements", icon: Megaphone },
              { id: "grades", label: "Grades", icon: GraduationCap },
              { id: "certificates", label: "Certificates", icon: Award },
              { id: "calendar", label: "Calendar", icon: Calendar },
              { id: "analytics", label: "Analytics", icon: BarChart3 },
              { id: "settings", label: "Settings", icon: Settings }
            ].map((menu) => (
              <button
                key={menu.id}
                onClick={() => {
                  setActiveTab(menu.id);
                  setSelectedCalendarDay(null);
                  setActiveDiscussion(null);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-sans font-bold tracking-wide transition-all border cursor-pointer ${
                  activeTab === menu.id
                    ? "bg-white/[0.04] text-white border-white/5 shadow-inner"
                    : "text-white/45 hover:text-white/80 hover:bg-white/[0.01] border-transparent"
                }`}
              >
                <div className="flex items-center gap-3">
                  <menu.icon size={14} className={activeTab === menu.id ? "text-indigo-400" : ""} />
                  <span>{menu.label}</span>
                </div>
                {menu.badge && menu.badge > 0 ? (
                  <span className="px-1.5 py-0.5 rounded-full text-[9px] font-mono font-bold bg-indigo-600 text-white">
                    {menu.badge}
                  </span>
                ) : null}
              </button>
            ))}
          </nav>
        </div>

        {/* FOOTER */}
        <div className="pt-4 border-t border-white/[0.03] flex items-center justify-between text-[10px] text-white/30 font-semibold uppercase shrink-0">
          <span>Showcase Mode</span>
          <span>v1.2.0</span>
        </div>
      </aside>

      {/* MAIN VIEWPORT */}
      <main className="flex-1 min-h-screen relative overflow-hidden flex flex-col z-10">
        {/* MOBILE TOP BAR */}
        <header className="md:hidden flex items-center justify-between p-4 bg-[#060609]/90 border-b border-white/[0.05] sticky top-0 backdrop-blur-md z-30 select-none">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg border border-white/10 bg-white/[0.03] flex items-center justify-center font-serif text-lg font-bold text-white">
              R
            </div>
            <span className="font-sans text-xs font-black tracking-widest uppercase">
              LMS Academy
            </span>
          </div>

          <button
            onClick={onLogout}
            className="p-2 rounded-xl text-white/40 hover:text-white"
            title="Logout"
          >
            <LogOut size={14} />
          </button>
        </header>

        {/* PRIMARY VIEW CONTENT */}
        <div className="p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto flex-grow pb-24">
          <AnimatePresence mode="wait">
            {/* TAB 1: DASHBOARD */}
            {activeTab === "dashboard" && (
              <DashboardTab
                courses={courses}
                students={students}
                sessions={sessions}
                assignments={assignments}
                discussions={discussions}
                onNavigate={(tab) => {
                  setActiveTab(tab);
                  setSelectedCalendarDay(null);
                }}
                onQuickAction={handleQuickAction}
                profile={profile}
              />
            )}

            {/* TAB 2: MY COURSES */}
            {activeTab === "courses" && (
              <CoursesTab
                courses={courses}
                onToggleStatus={handleToggleCourseStatus}
                onNavigateToTab={(tab) => setActiveTab(tab)}
                courseSeasons={courseSeasons}
                onCreateSeason={handleCreateSeason}
                onUpdateSeason={handleUpdateSeason}
                onDeleteSeason={handleDeleteSeason}
                showCustomToast={showCustomToast}
              />
            )}

            {/* TAB 3: STUDENTS */}
            {activeTab === "students" && (
              <StudentsTab
                students={students}
                onSendMessage={handleSendMessage}
                onGradeStudent={handleGradeStudentOverride}
              />
            )}

            {/* TAB 4: SCHEDULE */}
            {activeTab === "schedule" && (
              <div className="space-y-6 animate-fade-in text-left">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.04] pb-5">
                  <div className="space-y-1">
                    <h2 className="font-sans text-xl font-bold text-white uppercase tracking-wider">
                      Academic Class Schedule
                    </h2>
                    <p className="font-sans text-xs text-white/40">
                      Coordinate daily upcoming masterclasses, track durations, and publish video links.
                    </p>
                  </div>
                  <button
                    onClick={() => setShowAddSessionModal(true)}
                    className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-sans font-extrabold text-[11px] tracking-widest uppercase transition-all shadow-[0_4px_15px_rgba(79,70,229,0.25)] cursor-pointer"
                  >
                    <Plus size={13} />
                    <span>Schedule Class</span>
                  </button>
                </div>

                {/* SESSIONS CONTAINER */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {sessions.map((sess) => (
                    <div
                      key={sess.id}
                      className="p-5 rounded-3xl bg-[#08080c]/90 border border-white/[0.05] hover:border-white/10 transition-all flex flex-col justify-between h-44"
                    >
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/10">
                            {sess.courseTitle}
                          </span>
                          <span className={`px-2 py-0.5 rounded text-[9px] font-sans font-bold uppercase border ${
                            sess.status === "Scheduled" ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : "bg-white/[0.02] border-white/10 text-white/40"
                          }`}>
                            {sess.status}
                          </span>
                        </div>
                        <h3 className="font-sans text-sm font-bold text-white mt-1 leading-snug">
                          {sess.title}
                        </h3>
                        <p className="font-sans text-xs text-white/40 font-semibold font-mono">
                          {sess.date} @ {sess.time} ({sess.duration})
                        </p>
                      </div>

                      <div className="flex items-center justify-between border-t border-white/[0.03] pt-3 mt-3">
                        <span className="text-[10px] text-white/30 font-sans font-semibold">
                          Target Segment: {sess.studentCount} students
                        </span>
                        {sess.status === "Scheduled" && (
                          <button
                            onClick={() => handleStartMasterclassInitiate(sess)}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-sans font-extrabold text-[9px] tracking-wider uppercase transition-all cursor-pointer"
                          >
                            <Play size={10} className="fill-current" />
                            <span>Start Masterclass</span>
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {/* ADD SCHEDULE SESSION MODAL */}
                <AnimatePresence>
                  {showAddSessionModal && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                      <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="bg-[#08080c] border border-white/10 rounded-3xl w-full max-w-md p-6 relative"
                      >
                        <button
                          onClick={() => setShowAddSessionModal(false)}
                          className="absolute top-4 right-4 p-1.5 rounded-lg text-white/30 hover:text-white"
                        >
                          <X size={15} />
                        </button>

                        <div className="flex items-center gap-2 border-b border-white/[0.04] pb-4 mb-5">
                          <Clock size={16} className="text-indigo-400" />
                          <h3 className="font-sans text-sm font-bold text-white uppercase tracking-wider">
                            Schedule New Masterclass
                          </h3>
                        </div>

                        <form onSubmit={handleAddSessionSubmit} className="space-y-4 text-xs">
                          <div className="space-y-1.5">
                            <label className="block text-[10px] font-bold text-white/50 uppercase">Session Title</label>
                            <input
                              type="text"
                              required
                              placeholder="e.g. Design Systems & Component Kernels"
                              value={sessionTitle}
                              onChange={(e) => setSessionTitle(e.target.value)}
                              className="w-full bg-[#030304] border border-white/10 rounded-xl px-3 py-2.5 text-xs text-white placeholder-white/20 focus:outline-none focus:border-indigo-500 transition-colors"
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1.5">
                              <label className="block text-[10px] font-bold text-white/50 uppercase">Time Slot</label>
                              <input
                                type="text"
                                required
                                placeholder="10:00 AM"
                                value={sessionTime}
                                onChange={(e) => setSessionTime(e.target.value)}
                                className="w-full bg-[#030304] border border-white/10 rounded-xl px-3 py-2.5 text-xs text-white placeholder-white/20 focus:outline-none"
                              />
                            </div>
                            <div className="space-y-1.5">
                              <label className="block text-[10px] font-bold text-white/50 uppercase">Target Course</label>
                              <select
                                required
                                value={sessionCourseId}
                                onChange={(e) => setSessionCourseId(e.target.value)}
                                className="w-full bg-[#030304] border border-white/10 rounded-xl px-3 py-2 text-xs text-white/80 focus:outline-none cursor-pointer"
                              >
                                <option value="">Choose...</option>
                                {courses.map((c) => (
                                  <option key={c.id} value={c.id}>
                                    {c.title}
                                  </option>
                                ))}
                              </select>
                            </div>
                          </div>

                          <div className="pt-3 border-t border-white/[0.04] flex items-center justify-end gap-3">
                            <button
                              type="button"
                              onClick={() => setShowAddSessionModal(false)}
                              className="px-4 py-2.5 rounded-xl border border-white/10 bg-white/[0.01] hover:bg-white/[0.04] text-xs font-bold text-white"
                            >
                              Cancel
                            </button>
                            <button
                              type="submit"
                              className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-sans font-bold text-xs"
                            >
                              Confirm Session
                            </button>
                          </div>
                        </form>
                      </motion.div>
                    </div>
                  )}
                </AnimatePresence>

                {/* START MASTERCLASS CONFIGURE MODAL */}
                <AnimatePresence>
                  {isStartClassModalOpen && selectedSessionToStart && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                      <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="bg-[#08080c] border border-white/10 rounded-3xl w-full max-w-md p-6 relative text-left"
                      >
                        <button
                          onClick={() => setIsStartClassModalOpen(false)}
                          className="absolute top-4 right-4 p-1.5 rounded-lg text-white/30 hover:text-white cursor-pointer transition-colors"
                          disabled={isSavingMeeting}
                        >
                          <X size={15} />
                        </button>

                        <div className="flex items-center gap-2 border-b border-white/[0.04] pb-4 mb-5">
                          <Play size={16} className="text-emerald-400 fill-current" />
                          <h3 className="font-sans text-sm font-black text-white uppercase tracking-wider">
                            Start Masterclass Session
                          </h3>
                        </div>

                        <div className="mb-4 p-3.5 rounded-2xl bg-white/[0.01] border border-white/[0.05] space-y-1.5 text-xs">
                          <span className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider">
                            Active Session Context
                          </span>
                          <h4 className="font-sans text-xs font-bold text-white">
                            {selectedSessionToStart.title}
                          </h4>
                          <p className="text-[10px] text-white/40 font-mono">
                            {selectedSessionToStart.courseTitle} • {selectedSessionToStart.date} @ {selectedSessionToStart.time}
                          </p>
                        </div>

                        <form onSubmit={handleStartMasterclassSubmit} className="space-y-4 text-xs">
                          <div className="space-y-1.5">
                            <label className="block text-[10px] font-bold text-white/50 uppercase tracking-wider">
                              Meeting Platform
                            </label>
                            <select
                              required
                              value={meetingPlatform}
                              onChange={(e) => setMeetingPlatform(e.target.value)}
                              className="w-full bg-[#030304] border border-white/10 rounded-xl px-3 py-2 text-xs text-white/80 focus:outline-none focus:border-indigo-500 transition-colors cursor-pointer"
                              disabled={isSavingMeeting}
                            >
                              <option value="Google Meet">Google Meet</option>
                              <option value="Zoom">Zoom</option>
                              <option value="Adobe Connect">Adobe Connect</option>
                              <option value="Microsoft Teams">Microsoft Teams</option>
                              <option value="Skype">Skype</option>
                              <option value="Other">Other</option>
                            </select>
                          </div>

                          {meetingPlatform === "Other" && (
                            <div className="space-y-1.5 animate-fade-in">
                              <label className="block text-[10px] font-bold text-white/50 uppercase tracking-wider">
                                Custom Platform Name
                              </label>
                              <input
                                type="text"
                                required
                                placeholder="e.g. Webex, Discord"
                                value={meetingPlatformCustom}
                                onChange={(e) => setMeetingPlatformCustom(e.target.value)}
                                className="w-full bg-[#030304] border border-white/10 rounded-xl px-3 py-2.5 text-xs text-white placeholder-white/20 focus:outline-none focus:border-indigo-500 transition-colors"
                                disabled={isSavingMeeting}
                              />
                            </div>
                          )}

                          <div className="space-y-1.5">
                            <label className="block text-[10px] font-bold text-white/50 uppercase tracking-wider">
                              Meeting Connection Link
                            </label>
                            <input
                              type="text"
                              required
                              placeholder="https://meet.google.com/abc-defg-hij"
                              value={meetingLink}
                              onChange={(e) => {
                                setMeetingLink(e.target.value);
                                if (meetingLinkError) setMeetingLinkError("");
                              }}
                              className={`w-full bg-[#030304] border rounded-xl px-3 py-2.5 text-xs text-white placeholder-white/20 focus:outline-none focus:border-indigo-500 transition-colors ${
                                meetingLinkError ? "border-rose-500" : "border-white/10"
                              }`}
                              disabled={isSavingMeeting}
                            />
                            {meetingLinkError && (
                              <p className="text-[10px] text-rose-400 font-sans mt-1">
                                {meetingLinkError}
                              </p>
                            )}
                          </div>

                          <div className="pt-3 border-t border-white/[0.04] flex items-center justify-end gap-3">
                            <button
                              type="button"
                              onClick={() => setIsStartClassModalOpen(false)}
                              className="px-4 py-2.5 rounded-xl border border-white/10 bg-white/[0.01] hover:bg-white/[0.04] text-xs font-bold text-white cursor-pointer transition-colors"
                              disabled={isSavingMeeting}
                            >
                              Cancel
                            </button>
                            <button
                              type="submit"
                              className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-sans font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-[0_4px_15px_rgba(16,185,129,0.25)] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                              disabled={isSavingMeeting}
                            >
                              {isSavingMeeting ? (
                                <>
                                  <div className="h-3 w-3 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                                  <span>Saving Live Setup...</span>
                                </>
                              ) : (
                                <>
                                  <Play size={11} className="fill-current" />
                                  <span>Launch Class Live</span>
                                </>
                              )}
                            </button>
                          </div>
                        </form>
                      </motion.div>
                    </div>
                  )}
                </AnimatePresence>
              </div>
            )}

            {/* TAB 5: ASSIGNMENTS */}
            {activeTab === "assignments" && (
              <AssignmentsTab
                assignments={assignments}
                courses={courses}
                sessions={sessions}
                onCreateAssignment={handleCreateAssignment}
                onGradeSubmission={handleGradeSubmission}
                showCustomToast={showCustomToast}
              />
            )}

            {/* TAB 6: DISCUSSIONS */}
            {activeTab === "discussions" && (
              <div className="space-y-6 animate-fade-in text-left">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.04] pb-5">
                  <div className="space-y-1">
                    <h2 className="font-sans text-xl font-bold text-white uppercase tracking-wider">
                      Academy Discussions forum
                    </h2>
                    <p className="font-sans text-xs text-white/40">
                      Answer student technical forum inquiries and manage thread statuses.
                    </p>
                  </div>

                  <div className="flex items-center gap-2 self-start sm:self-center">
                    <select
                      value={discussionCourseFilter}
                      onChange={(e) => setDiscussionCourseFilter(e.target.value)}
                      className="bg-[#08080c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white/80 focus:outline-none cursor-pointer"
                    >
                      <option value="all">All Courses</option>
                      {courses.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.title}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                  {/* DISCUSSION LIST */}
                  <div className="lg:col-span-5 bg-[#08080c]/90 border border-white/[0.05] rounded-3xl p-5 space-y-3">
                    <div className="flex items-center gap-2 border-b border-white/[0.04] pb-3 mb-2">
                      <MessageSquare size={15} className="text-indigo-400" />
                      <h3 className="font-sans text-xs font-bold text-white uppercase tracking-wider">
                        Thread Queue
                      </h3>
                    </div>

                    <div className="space-y-2.5">
                      {filteredDiscussions.map((disc) => (
                        <div
                          key={disc.id}
                          onClick={() => setActiveDiscussion(disc)}
                          className={`p-3.5 rounded-2xl border transition-all text-left cursor-pointer flex flex-col justify-between h-28 ${
                            activeDiscussion && activeDiscussion.id === disc.id
                              ? "bg-indigo-500/[0.03] border-indigo-500/25"
                              : "bg-white/[0.01] border-white/[0.04] hover:border-white/[0.08]"
                          }`}
                        >
                          <div className="space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="text-[9px] font-mono font-semibold text-white/45">{disc.studentName}</span>
                              <span className={`px-2 py-0.5 rounded text-[8px] font-sans font-bold uppercase border ${
                                disc.status === "New"
                                  ? "bg-rose-500/10 border-rose-500/20 text-rose-400"
                                  : disc.status === "Replied"
                                  ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                                  : "bg-white/[0.02] border-white/10 text-white/30"
                              }`}>
                                {disc.status}
                              </span>
                            </div>
                            <h4 className="font-sans text-xs font-bold text-white line-clamp-1 leading-snug">
                              {disc.title}
                            </h4>
                          </div>
                          <span className="block text-[10px] text-indigo-400 font-semibold">{disc.courseTitle}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* ACTIVE CHAT VIEW */}
                  <div className="lg:col-span-7 bg-[#08080c]/90 border border-white/[0.05] rounded-3xl p-5 min-h-[400px] flex flex-col justify-between">
                    {activeDiscussion ? (
                      <div className="space-y-4 flex flex-col justify-between h-full">
                        <div className="space-y-4">
                          <div className="flex items-center justify-between border-b border-white/[0.04] pb-3 mb-1">
                            <div className="space-y-0.5 text-left">
                              <h3 className="font-sans text-xs font-bold text-white uppercase tracking-wider">
                                Thread: {activeDiscussion.title}
                              </h3>
                              <span className="block text-[10px] text-white/35 font-mono">By: {activeDiscussion.studentName}</span>
                            </div>

                            <div className="flex items-center gap-2">
                              {activeDiscussion.status !== "Closed" ? (
                                <button
                                  onClick={() => handleToggleDiscussionStatus(activeDiscussion.id, "Closed")}
                                  className="px-2.5 py-1 rounded bg-white/[0.02] hover:bg-white/[0.06] border border-white/10 text-[9px] font-sans font-extrabold tracking-wider uppercase text-white cursor-pointer"
                                >
                                  Close Thread
                                </button>
                              ) : (
                                <button
                                  onClick={() => handleToggleDiscussionStatus(activeDiscussion.id, "Replied")}
                                  className="px-2.5 py-1 rounded bg-indigo-600 hover:bg-indigo-500 text-[9px] font-sans font-extrabold tracking-wider uppercase text-white cursor-pointer"
                                >
                                  Reopen Thread
                                </button>
                              )}
                            </div>
                          </div>

                          {/* Student Initial Post */}
                          <div className="p-3.5 rounded-2xl bg-white/[0.01] border border-white/[0.03] space-y-1.5 text-left text-xs">
                            <span className="block font-bold text-white">{activeDiscussion.studentName}</span>
                            <p className="text-white/60 leading-relaxed">{activeDiscussion.text}</p>
                          </div>

                          {/* Replies Thread Feed */}
                          {activeDiscussion.replies.length > 0 && (
                            <div className="space-y-3 pt-2">
                              {activeDiscussion.replies.map((r) => (
                                <div
                                  key={r.id}
                                  className={`p-3.5 rounded-2xl text-left text-xs space-y-1.5 ${
                                    r.role === "Instructor"
                                      ? "bg-indigo-500/[0.02] border border-indigo-500/10 ml-6"
                                      : "bg-white/[0.01] border border-white/[0.03]"
                                  }`}
                                >
                                  <div className="flex justify-between items-center text-[10px]">
                                    <span className="font-bold text-white flex items-center gap-1">
                                      {r.sender}
                                      {r.role === "Instructor" && (
                                        <span className="px-1.5 py-0.5 rounded text-[8px] font-mono font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/10">
                                          Instructor
                                        </span>
                                      )}
                                    </span>
                                    <span className="text-white/30 font-mono">{r.time}</span>
                                  </div>
                                  <p className="text-white/65 leading-relaxed">{r.text}</p>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* Reply Form */}
                        {activeDiscussion.status !== "Closed" && (
                          <form onSubmit={handleSendDiscussionReply} className="space-y-2 pt-4 border-t border-white/[0.04]">
                            <textarea
                              required
                              placeholder="Write a clear professional reply..."
                              rows={3}
                              value={discussionReply}
                              onChange={(e) => setDiscussionReply(e.target.value)}
                              className="w-full bg-[#030304] border border-white/10 hover:border-white/20 focus:border-indigo-500 rounded-xl p-3 text-xs text-white placeholder-white/20 focus:outline-none"
                            />
                            <button
                              type="submit"
                              className="w-full py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-sans font-bold text-xs cursor-pointer"
                            >
                              Post Reply Thread
                            </button>
                          </form>
                        )}
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center text-white/30 gap-1.5 py-24 select-none">
                        <MessageSquare size={24} className="text-indigo-500 animate-pulse" />
                        <span className="font-sans text-xs">Select a forum thread from the queue to start review.</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 7: RESOURCES */}
            {activeTab === "resources" && (
              <ResourcesTab
                resources={resources}
                courses={courses}
                sessions={sessions}
                onUploadResource={handleUploadResource}
                onDeleteResource={handleDeleteResource}
                onReplaceResource={handleReplaceResource}
                showCustomToast={showCustomToast}
              />
            )}

            {/* TAB 8: ATTENDANCE */}
            {activeTab === "attendance" && (
              <div className="space-y-6 animate-fade-in text-left">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.04] pb-5">
                  <div className="space-y-1">
                    <h2 className="font-sans text-xl font-bold text-white uppercase tracking-wider">
                      Course Session Attendance
                    </h2>
                    <p className="font-sans text-xs text-white/40">
                      Mark student session attendance daily and evaluate metrics dynamically.
                    </p>
                  </div>

                  <div className="flex items-center gap-2 self-start sm:self-center">
                    <div className="flex flex-col gap-1">
                      <span className="text-[9px] uppercase font-bold text-white/40 tracking-wider">Selected Course</span>
                      <select
                        value={attendanceCourseId}
                        onChange={(e) => setAttendanceCourseId(e.target.value)}
                        className="bg-[#08080c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white/80 focus:outline-none cursor-pointer min-w-[160px]"
                      >
                        {courses.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.title}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="flex flex-col gap-1">
                      <span className="text-[9px] uppercase font-bold text-white/40 tracking-wider">Completed Class Date</span>
                      <select
                        value={attendanceSessionId}
                        onChange={(e) => setAttendanceSessionId(e.target.value)}
                        disabled={completedSessions.length === 0}
                        className="bg-[#08080c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white/80 focus:outline-none cursor-pointer min-w-[160px] disabled:opacity-40"
                      >
                        {completedSessions.length === 0 ? (
                          <option value="">No Completed Classes</option>
                        ) : (
                          completedSessions.map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.date} - {s.title}
                            </option>
                          ))
                        )}
                      </select>
                    </div>
                  </div>
                </div>

                {/* ATTENDANCE WORKSPACE */}
                <div className="bg-[#08080c]/90 border border-white/[0.05] rounded-3xl overflow-hidden shadow-2xl">
                  <table className="w-full text-left border-collapse font-sans text-xs">
                    <thead>
                      <tr className="border-b border-white/[0.04] bg-white/[0.01]">
                        <th className="py-4 px-6 text-[10px] font-bold text-white/40 uppercase tracking-wider">Student Name</th>
                        <th className="py-4 px-6 text-[10px] font-bold text-white/40 uppercase tracking-wider">Average Level</th>
                        <th className="py-4 px-6 text-[10px] font-bold text-white/40 uppercase tracking-wider text-right">Mark Attendance</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/[0.03]">
                      {completedSessions.length === 0 ? (
                        <tr>
                          <td colSpan={3} className="py-16 text-center text-white/30 font-sans text-xs">
                            <div className="flex flex-col items-center justify-center gap-2 max-w-sm mx-auto">
                              <AlertTriangle className="text-amber-500" size={24} />
                              <span className="font-bold text-white/80 text-sm">Attendance Closed</span>
                              <span className="text-[11px] leading-normal text-white/40 text-center">
                                No completed sessions exist for this course yet. Attendance logs can only be created and loaded for class sessions that are marked as completed.
                              </span>
                            </div>
                          </td>
                        </tr>
                      ) : attendanceStudents.length === 0 ? (
                        <tr>
                          <td colSpan={3} className="py-12 text-center text-white/30 font-sans text-xs">
                            No students enrolled in this course.
                          </td>
                        </tr>
                      ) : (
                        attendanceStudents.map((s) => {
                          const recordsForSession = sessionAttendance[attendanceSessionId] || {};
                          const status = recordsForSession[s.id] || "Present";
                          return (
                            <tr key={s.id} className="hover:bg-white/[0.01] transition-colors">
                              <td className="py-4 px-6 font-bold text-white">{s.name}</td>
                              <td className="py-4 px-6 font-mono text-white/70">{s.attendance}% Cumulative</td>
                              <td className="py-4 px-6 text-right">
                                <div className="flex items-center justify-end gap-2.5">
                                  {(["Present", "Absent", "Late", "Excused"] as const).map((opt) => (
                                    <button
                                      key={opt}
                                      onClick={() => handleMarkAttendance(s.id, opt)}
                                      className={`px-3 py-1.5 rounded-xl text-[9px] font-sans font-extrabold uppercase tracking-wider border cursor-pointer transition-all ${
                                        status === opt
                                          ? opt === "Present"
                                            ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-400"
                                            : opt === "Absent"
                                            ? "bg-rose-500/15 border-rose-500/30 text-rose-400"
                                            : opt === "Late"
                                            ? "bg-amber-500/15 border-amber-500/30 text-amber-400"
                                            : "bg-indigo-500/15 border-indigo-500/30 text-indigo-400"
                                          : "bg-white/[0.01] border-white/5 text-white/40 hover:text-white/70"
                                      }`}
                                    >
                                      {opt}
                                    </button>
                                  ))}
                                </div>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* TAB 9: ANNOUNCEMENTS */}
            {activeTab === "announcements" && (
              <div className="space-y-6 animate-fade-in text-left">
                <div className="border-b border-white/[0.04] pb-5">
                  <h2 className="font-sans text-xl font-bold text-white uppercase tracking-wider">
                    Academy Broadcaster alerts
                  </h2>
                  <p className="font-sans text-xs text-white/40">
                    Publish warnings, masterclass cancellations, or academy celebrations to student bulletin boards.
                  </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                  {/* CREATE FORM */}
                  <div className="lg:col-span-5 bg-[#08080c]/90 border border-white/[0.05] rounded-3xl p-5 space-y-4">
                    <div className="flex items-center gap-2 border-b border-white/[0.04] pb-3">
                      <Megaphone size={15} className="text-indigo-400" />
                      <h3 className="font-sans text-xs font-bold text-white uppercase tracking-wider">
                        Publish Bulletin Alert
                      </h3>
                    </div>

                    <form onSubmit={handleAnnouncePublish} className="space-y-3.5 text-xs">
                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-white/50 uppercase">Alert Title</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Midterm Grades matrix published"
                          value={annTitle}
                          onChange={(e) => setAnnTitle(e.target.value)}
                          className="w-full bg-[#030304] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-white/50 uppercase">Scope Course Audience</label>
                        <select
                          required
                          value={annCourse}
                          onChange={(e) => setAnnCourse(e.target.value)}
                          className="w-full bg-[#030304] border border-white/10 rounded-xl px-3 py-2 text-xs text-white/80 focus:outline-none cursor-pointer"
                        >
                          <option value="">Select Target Course...</option>
                          {courses.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.title}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-white/50 uppercase">Alert Details Description</label>
                        <textarea
                          required
                          placeholder="Provide detailed information regarding the broadcast..."
                          rows={4}
                          value={annDesc}
                          onChange={(e) => setAnnDesc(e.target.value)}
                          className="w-full bg-[#030304] border border-white/10 rounded-xl p-3.5 text-xs text-white focus:outline-none font-sans"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-sans font-bold text-xs tracking-wider uppercase transition-all shadow-[0_4px_12px_rgba(79,70,229,0.2)] cursor-pointer"
                      >
                        Publish Broadcast
                      </button>
                    </form>
                  </div>

                  {/* BULLET FEED */}
                  <div className="lg:col-span-7 bg-[#08080c]/90 border border-white/[0.05] rounded-3xl p-5 space-y-4">
                    <div className="flex items-center gap-2 border-b border-white/[0.04] pb-3">
                      <ClipboardList size={15} className="text-amber-400" />
                      <h3 className="font-sans text-xs font-bold text-white uppercase tracking-wider">
                        Bulletin Alert Logs ({announcements.length})
                      </h3>
                    </div>

                    <div className="space-y-3">
                      {announcements.map((ann) => (
                        <div
                          key={ann.id}
                          className="p-4 rounded-2xl bg-white/[0.01] border border-white/[0.03] space-y-2 text-xs text-left group hover:border-white/10 transition-colors"
                        >
                          <div className="flex justify-between items-center">
                            <span className="px-2 py-0.5 rounded text-[8px] font-mono font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/10">
                              {ann.courseTitle}
                            </span>
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] text-white/30 font-mono">{ann.publishedAt}</span>
                              <button
                                onClick={() => setAnnToDelete(ann)}
                                className="p-1 text-white/30 hover:text-rose-400 rounded-lg hover:bg-rose-500/10 transition-colors cursor-pointer opacity-0 group-hover:opacity-100 focus:opacity-100"
                                title="Delete Announcement"
                              >
                                <Trash2 size={13} />
                              </button>
                            </div>
                          </div>
                          <h4 className="font-bold text-white">{ann.title}</h4>
                          <p className="text-white/50 leading-relaxed font-sans">{ann.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* DELETE CONFIRMATION MODAL */}
                <AnimatePresence>
                  {annToDelete && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                      <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="bg-[#08080c] border border-rose-500/20 rounded-3xl w-full max-w-sm p-6 relative shadow-2xl text-left"
                      >
                        <div className="flex items-center gap-2 border-b border-rose-500/10 pb-4 mb-4 text-rose-400">
                          <AlertTriangle size={16} />
                          <h3 className="font-sans text-xs font-bold uppercase tracking-wider">
                            Confirm Deletion
                          </h3>
                        </div>

                        <div className="space-y-3.5 text-xs text-white/70 leading-relaxed font-sans">
                          <p>
                            Are you sure you want to delete this bulletin announcement? It will be removed immediately from both your panel and the Student Dashboard.
                          </p>
                          <div className="p-3 bg-rose-500/5 rounded-xl border border-rose-500/10 text-white font-sans">
                            <span className="block text-[8px] uppercase tracking-wider font-bold text-rose-400">Target Broadcast</span>
                            <span className="font-bold">{annToDelete.title}</span>
                          </div>
                        </div>

                        <div className="pt-5 flex items-center justify-end gap-3 select-none">
                          <button
                            onClick={() => setAnnToDelete(null)}
                            className="px-4 py-2.5 rounded-xl border border-white/10 bg-white/[0.01] hover:bg-white/[0.04] text-xs font-bold text-white cursor-pointer"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={handleDeleteAnnouncement}
                            className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-sans font-bold text-xs shadow-lg shadow-rose-900/20 cursor-pointer"
                          >
                            Delete Announcement
                          </button>
                        </div>
                      </motion.div>
                    </div>
                  )}
                </AnimatePresence>
              </div>
            )}

            {/* TAB 10: GRADES */}
            {activeTab === "grades" && (() => {
              const selectedGradesCourse = courses.find((c) => c.id === gradesCourseFilter);
              const isGradesCourseCompleted = selectedGradesCourse?.status === "Finished";
              const gradesEnrolledStudents = students.filter((s) => s.courseId === gradesCourseFilter);

              return (
                <div className="space-y-6 animate-fade-in text-left">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.04] pb-5">
                    <div className="space-y-1">
                      <h2 className="font-sans text-xl font-bold text-white uppercase tracking-wider">
                        Gradebook Matrix Manager
                      </h2>
                      <p className="font-sans text-xs text-white/40">
                        Conduct student final GPA configurations, score assignments, and issue letter rankings.
                      </p>
                    </div>

                    <div className="flex flex-col gap-1 self-start sm:self-center">
                      <span className="text-[9px] uppercase font-bold text-white/40 tracking-wider">Filter Gradebook By Course</span>
                      <select
                        value={gradesCourseFilter}
                        onChange={(e) => {
                          setGradesCourseFilter(e.target.value);
                          setGradeEditStudentId(null);
                        }}
                        className="bg-[#08080c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white/80 focus:outline-none cursor-pointer min-w-[200px]"
                      >
                        {courses.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.title} ({c.status})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* INFORMATIONAL MESSAGE FOR ACTIVE COURSES */}
                  {!isGradesCourseCompleted ? (
                    <div className="p-4 bg-indigo-500/5 border border-indigo-500/20 rounded-2xl flex items-start gap-3">
                      <AlertTriangle className="text-indigo-400 shrink-0" size={16} />
                      <div className="space-y-0.5">
                        <span className="block text-xs font-bold text-white uppercase tracking-wide">Course is Currently Active</span>
                        <p className="text-[11px] text-white/50 leading-normal font-sans">
                          Grade entry and GPA overrides are disabled for active courses. You can only finalize or adjust grades once the course status has been toggled to <strong>Finished</strong> under the <span className="underline cursor-pointer text-indigo-400 hover:text-indigo-300" onClick={() => setActiveTab("courses")}>My Courses</span> panel.
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-2xl flex items-start gap-3 animate-pulse">
                      <CheckCircle2 className="text-emerald-400 shrink-0" size={16} />
                      <div className="space-y-0.5">
                        <span className="block text-xs font-bold text-white uppercase tracking-wide">Course Completed (Finalized)</span>
                        <p className="text-[11px] text-white/50 leading-normal font-sans">
                          Gradebook modifications are enabled for this completed course. You may enter average scores or modify student letter grades directly below.
                        </p>
                      </div>
                    </div>
                  )}

                  {/* MATRIX WORKSPACE */}
                  <div className="bg-[#08080c]/90 border border-white/[0.05] rounded-3xl overflow-hidden shadow-2xl">
                    <table className="w-full text-left border-collapse font-sans text-xs">
                      <thead>
                        <tr className="border-b border-white/[0.04] bg-white/[0.01]">
                          <th className="py-4 px-6 text-[10px] font-bold text-white/40 uppercase tracking-wider">Student Name</th>
                          <th className="py-4 px-6 text-[10px] font-bold text-white/40 uppercase tracking-wider">Course</th>
                          <th className="py-4 px-6 text-[10px] font-bold text-white/40 uppercase tracking-wider">Avg Score %</th>
                          <th className="py-4 px-6 text-[10px] font-bold text-white/40 uppercase tracking-wider">Letter Grade</th>
                          <th className="py-4 px-6 text-[10px] font-bold text-white/40 uppercase tracking-wider text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/[0.03]">
                        {gradesEnrolledStudents.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="py-12 text-center text-white/30 font-sans text-xs">
                              No students are currently enrolled in this course.
                            </td>
                          </tr>
                        ) : (
                          gradesEnrolledStudents.map((s) => {
                            const isEditing = gradeEditStudentId === s.id;
                            const letterGrade = s.avgGrade >= 90 ? "A" : s.avgGrade >= 80 ? "B" : s.avgGrade >= 70 ? "C" : s.avgGrade > 0 ? "D" : "F";
                            return (
                              <tr key={s.id} className="hover:bg-white/[0.01] transition-colors">
                                <td className="py-4 px-6 font-bold text-white">{s.name}</td>
                                <td className="py-4 px-6 text-white/50">{s.courseTitle}</td>
                                <td className="py-4 px-6">
                                  {isEditing && isGradesCourseCompleted ? (
                                    <input
                                      type="number"
                                      min={0}
                                      max={100}
                                      value={gradeScoreInput}
                                      onChange={(e) => setGradeScoreInput(e.target.value)}
                                      className="w-16 bg-[#030304] border border-indigo-500 rounded px-2 py-1 font-mono text-white text-xs focus:outline-none"
                                    />
                                  ) : (
                                    <span className="font-mono font-bold text-white/80">
                                      {s.avgGrade > 0 ? `${s.avgGrade}%` : "N/A"}
                                    </span>
                                  )}
                                </td>
                                <td className="py-4 px-6">
                                  <span className={`px-2 py-0.5 rounded font-mono font-bold text-[10px] ${
                                    letterGrade === "A"
                                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/15"
                                      : letterGrade === "B"
                                      ? "bg-indigo-500/10 text-indigo-400 border border-indigo-500/15"
                                      : "bg-white/[0.02] text-white/40 border border-white/5"
                                  }`}>
                                    {s.avgGrade > 0 ? letterGrade : "F"}
                                  </span>
                                </td>
                                <td className="py-4 px-6 text-right">
                                  {isEditing && isGradesCourseCompleted ? (
                                    <div className="flex items-center justify-end gap-1.5">
                                      <button
                                        onClick={() => handleSaveGradeMatrix(s.id, s.avgGrade)}
                                        className="p-1.5 rounded bg-emerald-600 text-white hover:bg-emerald-500 cursor-pointer"
                                        title="Save Grade Score"
                                      >
                                        <Check size={12} />
                                      </button>
                                      <button
                                        onClick={() => setGradeEditStudentId(null)}
                                        className="p-1.5 rounded bg-white/[0.04] text-white/40 hover:text-white cursor-pointer"
                                      >
                                        <X size={12} />
                                      </button>
                                    </div>
                                  ) : (
                                    <button
                                      onClick={() => {
                                        if (!isGradesCourseCompleted) {
                                          showCustomToast("Gradebook modification locked. Set Course status to Finished to unlock.", "warning");
                                          return;
                                        }
                                        setGradeEditStudentId(s.id);
                                        setGradeScoreInput(s.avgGrade > 0 ? s.avgGrade.toString() : "85");
                                      }}
                                      disabled={!isGradesCourseCompleted}
                                      className={`p-2 rounded-lg transition-all cursor-pointer ${
                                        isGradesCourseCompleted
                                          ? "text-white/30 hover:text-white hover:bg-white/[0.04]"
                                          : "text-white/10 cursor-not-allowed"
                                      }`}
                                      title={isGradesCourseCompleted ? "Enter Grade Score" : "Gradebook Locked (Active Course)"}
                                    >
                                      <Edit2 size={12} />
                                    </button>
                                  )}
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })()}

            {/* TAB 11: CERTIFICATES */}
            {activeTab === "certificates" && (() => {
              const filteredCerts = certificates.filter((c) => {
                if (certificateStatusFilter === "All") return true;
                return c.status === certificateStatusFilter;
              });

              return (
                <div className="space-y-6 animate-fade-in text-left">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.04] pb-5">
                    <div className="space-y-1">
                      <h2 className="font-sans text-xl font-bold text-white uppercase tracking-wider">
                        Certificates Verification Desk
                      </h2>
                      <p className="font-sans text-xs text-white/40">
                        Sign certificates for completed courses and simulate administrative workflow decisions.
                      </p>
                    </div>

                    <div className="flex flex-col gap-1 self-start sm:self-center">
                      <span className="text-[9px] uppercase font-bold text-white/40 tracking-wider">Filter By Status</span>
                      <select
                        value={certificateStatusFilter}
                        onChange={(e) => setCertificateStatusFilter(e.target.value)}
                        className="bg-[#08080c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white/80 focus:outline-none cursor-pointer min-w-[200px]"
                      >
                        <option value="All">All Statuses</option>
                        <option value="Draft">Draft</option>
                        <option value="Waiting for Admin Approval">Waiting for Admin Approval</option>
                        <option value="Approved">Approved</option>
                        <option value="Rejected">Rejected</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredCerts.length === 0 ? (
                      <div className="col-span-full py-16 text-center text-white/30 font-sans text-xs bg-[#08080c]/90 border border-white/[0.05] rounded-3xl">
                        No certificates match the selected status filter.
                      </div>
                    ) : (
                      filteredCerts.map((cert) => {
                        const course = courses.find((c) => c.id === cert.courseId);
                        const isCourseCompleted = course?.status === "Finished";

                        return (
                          <div
                            key={cert.id}
                            className="rounded-3xl bg-[#08080c]/90 border border-white/[0.05] p-5 flex flex-col justify-between min-h-[220px] hover:border-white/10 transition-colors"
                          >
                            <div className="space-y-3.5 text-xs">
                              <div className="flex items-center justify-between border-b border-white/[0.03] pb-2">
                                <span className="font-bold text-white text-[13px]">{cert.studentName}</span>
                                <span className={`px-2 py-0.5 rounded text-[8px] font-sans font-bold uppercase border ${
                                  cert.status === "Approved"
                                    ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                                    : cert.status === "Waiting for Admin Approval"
                                    ? "bg-amber-500/10 border-amber-500/20 text-amber-400 animate-pulse"
                                    : cert.status === "Rejected"
                                    ? "bg-rose-500/10 border-rose-500/20 text-rose-400"
                                    : "bg-white/[0.04] border-white/10 text-white/50"
                                }`}>
                                  {cert.status}
                                </span>
                              </div>

                              <div className="space-y-1.5 text-left text-white/60">
                                <p>Course: <strong className="text-white">{cert.courseTitle}</strong></p>
                                <p className="flex items-center gap-1.5">
                                  Course Status:{" "}
                                  <span className={`px-1.5 py-0.2 rounded text-[8px] uppercase font-bold ${
                                    isCourseCompleted
                                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/10"
                                      : "bg-amber-500/10 text-amber-400 border border-amber-500/10"
                                  }`}>
                                    {course?.status || "Active"}
                                  </span>
                                </p>
                                <p>Cumulative GPA: <strong className="text-white font-mono">{cert.gpa.toFixed(2)} / 4.0</strong></p>
                                {cert.issueDate && <p>Last Updated: <strong className="text-white/40 font-mono">{cert.issueDate}</strong></p>}
                              </div>
                            </div>

                            <div className="space-y-2 pt-3 border-t border-white/[0.03]">
                              {cert.status === "Draft" ? (
                                <button
                                  onClick={() => handleSignCertificate(cert.id)}
                                  disabled={!isCourseCompleted}
                                  className={`w-full py-2 rounded-xl font-sans font-bold text-xs tracking-wider uppercase transition-all cursor-pointer ${
                                    isCourseCompleted
                                      ? "bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-500/10"
                                      : "bg-white/[0.02] text-white/20 border border-white/5 cursor-not-allowed"
                                  }`}
                                  title={isCourseCompleted ? "Sign and Submit Certificate" : "Locked - Course is still Active"}
                                >
                                  {isCourseCompleted ? "Sign Certificate" : "Locked (Course Active)"}
                                </button>
                              ) : cert.status === "Waiting for Admin Approval" ? (
                                <div className="space-y-2">
                                  <div className="text-[9px] uppercase font-mono font-bold text-center text-white/40">
                                    Simulate Admin Action
                                  </div>
                                  <div className="flex gap-2">
                                    <button
                                      onClick={() => handleSimulateAdminDecision(cert.id, "Approved")}
                                      className="flex-1 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/20 font-sans font-bold text-[10px] uppercase tracking-wider transition-all cursor-pointer"
                                    >
                                      Approve
                                    </button>
                                    <button
                                      onClick={() => handleSimulateAdminDecision(cert.id, "Rejected")}
                                      className="flex-1 py-1.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-400 border border-rose-500/20 font-sans font-bold text-[10px] uppercase tracking-wider transition-all cursor-pointer"
                                    >
                                      Reject
                                    </button>
                                  </div>
                                </div>
                              ) : cert.status === "Approved" ? (
                                <button
                                  onClick={() => {
                                    showCustomToast("Compiling PDF components...", "info");
                                    setTimeout(() => showCustomToast("Certificate PDF generated & downloaded successfully!", "success"), 1000);
                                  }}
                                  className="w-full py-2 rounded-xl bg-white/[0.02] hover:bg-white/[0.06] border border-white/10 text-white font-sans font-bold text-xs tracking-wider uppercase transition-all cursor-pointer"
                                >
                                  Download Certificate PDF
                                </button>
                              ) : (
                                <button
                                  onClick={() => handleSignCertificate(cert.id)}
                                  className="w-full py-2 rounded-xl bg-rose-600/10 hover:bg-rose-600/20 border border-rose-500/20 text-rose-400 font-sans font-bold text-xs tracking-wider uppercase transition-all cursor-pointer"
                                >
                                  Re-Submit to Admin
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              );
            })()}

            {/* TAB 12: CALENDAR */}
            {activeTab === "calendar" && (
              <div className="space-y-6 animate-fade-in text-left">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.04] pb-5">
                  <div className="space-y-1">
                    <h2 className="font-sans text-xl font-bold text-white uppercase tracking-wider">
                      Master Academic Calendar
                    </h2>
                    <p className="font-sans text-xs text-white/40">
                      Audit institute session timetables, office hours, exam dates, and holidays.
                    </p>
                  </div>

                  <div className="flex items-center gap-2 bg-[#08080c]/90 border border-white/[0.05] p-1.5 rounded-2xl">
                    <button
                      onClick={handlePrevMonth}
                      className="p-1.5 rounded-xl hover:bg-white/[0.04] text-white/60 hover:text-white transition-all cursor-pointer"
                      title="Previous Month"
                    >
                      <ChevronLeft size={16} />
                    </button>
                    <span className="font-sans text-xs font-black text-indigo-400 uppercase tracking-widest px-2 select-none min-w-[120px] text-center">
                      {MONTH_NAMES[calendarMonth]} {calendarYear}
                    </span>
                    <button
                      onClick={handleNextMonth}
                      className="p-1.5 rounded-xl hover:bg-white/[0.04] text-white/60 hover:text-white transition-all cursor-pointer"
                      title="Next Month"
                    >
                      <ChevronRight size={16} />
                    </button>
                    <button
                      onClick={handleGoToToday}
                      className="px-3 py-1.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/20 text-indigo-400 font-sans font-bold text-[10px] uppercase tracking-wider transition-all cursor-pointer"
                    >
                      Today
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                  {/* CALENDAR MATRIX */}
                  <div className="lg:col-span-8 bg-[#08080c]/90 border border-white/[0.05] rounded-3xl p-5 select-none">
                    <div className="grid grid-cols-7 gap-1 border-b border-white/[0.04] pb-2 mb-3 text-center text-[10px] font-bold text-white/40 uppercase tracking-wider">
                      <span>Sun</span>
                      <span>Mon</span>
                      <span>Tue</span>
                      <span>Wed</span>
                      <span>Thu</span>
                      <span>Fri</span>
                      <span>Sat</span>
                    </div>

                    <div className="grid grid-cols-7 gap-2">
                      {calendarDays.map((day, idx) => {
                        if (day === null) {
                          return <div key={`pad-${idx}`} className="h-20 bg-white/[0.01]/10 rounded-2xl border border-transparent" />;
                        }

                        const mm = String(calendarMonth + 1).padStart(2, '0');
                        const dd = String(day).padStart(2, '0');
                        const dateString = `${calendarYear}-${mm}-${dd}`;
                        const dayEvents = calendarEvents.filter((e) => e.date === dateString);

                        return (
                          <div
                            key={`day-${day}`}
                            onClick={() => setSelectedCalendarDay(day)}
                            className={`h-20 p-2 rounded-2xl border transition-all text-left flex flex-col justify-between cursor-pointer ${
                              selectedCalendarDay === day
                                ? "bg-indigo-500/[0.03] border-indigo-500/20"
                                : "bg-[#030304]/60 border-white/[0.03] hover:border-white/[0.08]"
                            }`}
                          >
                            <span className="font-mono text-[10px] font-bold text-white/60 leading-none">{day}</span>
                            <div className="space-y-0.5">
                              {dayEvents.slice(0, 2).map((ev) => (
                                <span
                                  key={ev.id}
                                  className={`block text-[8px] font-sans font-bold px-1 py-0.5 rounded truncate ${
                                    ev.type === "Class"
                                      ? "bg-indigo-500/10 text-indigo-300 border border-indigo-500/10"
                                      : ev.type === "Exam"
                                      ? "bg-rose-500/10 text-rose-300 border border-rose-500/10"
                                      : ev.type === "Holiday"
                                      ? "bg-amber-500/10 text-amber-300 border border-amber-500/10"
                                      : "bg-emerald-500/10 text-emerald-300 border border-emerald-500/10"
                                  }`}
                                  title={`${ev.title} @ ${ev.time}`}
                                >
                                  {ev.title}
                                </span>
                              ))}
                              {dayEvents.length > 2 && (
                                <span className="block text-[7px] text-white/35 text-center font-bold">+{dayEvents.length - 2} more</span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* EVENTS LIST & ADD PANEL */}
                  <div className="lg:col-span-4 bg-[#08080c]/90 border border-white/[0.05] rounded-3xl p-5 space-y-4">
                    {selectedCalendarDay ? (
                      /* ADD EVENT FORM */
                      <form onSubmit={handleAddCalendarEvent} className="space-y-4 text-xs">
                        <div className="flex items-center gap-2 border-b border-white/[0.04] pb-3 mb-1">
                          <Plus size={15} className="text-indigo-400" />
                          <h3 className="font-sans text-xs font-bold text-white uppercase tracking-wider">
                            Schedule {MONTH_NAMES[calendarMonth]} {selectedCalendarDay} Event
                          </h3>
                        </div>

                        <div className="space-y-1.5">
                          <label className="block text-[10px] font-bold text-white/50 uppercase">Event Title</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. Office hours on Linear Algebra"
                            value={newCalendarEventTitle}
                            onChange={(e) => setNewCalendarEventTitle(e.target.value)}
                            className="w-full bg-[#030304] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-white/20 focus:outline-none"
                          />
                        </div>

                        <div className="space-y-1.5">
                          <label className="block text-[10px] font-bold text-white/50 uppercase">Event Type</label>
                          <select
                            value={newCalendarEventType}
                            onChange={(e) => setNewCalendarEventType(e.target.value as any)}
                            className="w-full bg-[#030304] border border-white/10 rounded-xl px-3 py-2 text-xs text-white/80 focus:outline-none cursor-pointer"
                          >
                            <option value="Office Hours">Office Hours</option>
                            <option value="Exam">Exam / Review</option>
                            <option value="Holiday">Academy Holiday</option>
                            <option value="Class">Virtual Masterclass</option>
                          </select>
                        </div>

                        <div className="pt-2 flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setSelectedCalendarDay(null)}
                            className="px-3.5 py-2 rounded-xl border border-white/10 text-xs font-bold text-white cursor-pointer"
                          >
                            Cancel
                          </button>
                          <button
                            type="submit"
                            className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-sans font-bold text-xs cursor-pointer"
                          >
                            Schedule
                          </button>
                        </div>
                      </form>
                    ) : (
                      /* GENERAL EVENTS LIST */
                      <div className="space-y-4 text-xs text-left">
                        <div className="flex items-center gap-2 border-b border-white/[0.04] pb-3">
                          <CalendarIcon size={14} className="text-indigo-400" />
                          <h3 className="font-sans text-xs font-bold text-white uppercase tracking-wider">
                            {MONTH_NAMES[calendarMonth]} {calendarYear} Events
                          </h3>
                        </div>

                        <div className="space-y-3.5 max-h-[350px] overflow-y-auto">
                          {(() => {
                            const mm = String(calendarMonth + 1).padStart(2, '0');
                            const prefix = `${calendarYear}-${mm}`;
                            const filteredEvents = calendarEvents.filter((ev) => ev.date.startsWith(prefix));

                            if (filteredEvents.length === 0) {
                              return (
                                <p className="text-white/30 text-xs text-center py-8">
                                  No events scheduled for this month.
                                </p>
                              );
                            }

                            return filteredEvents.map((ev) => (
                              <div
                                key={ev.id}
                                className="p-3 rounded-2xl bg-white/[0.01] border border-white/[0.03] flex items-center justify-between gap-3"
                              >
                                <div className="space-y-1 text-left">
                                  <span className={`px-1.5 py-0.5 rounded text-[8px] font-sans font-bold uppercase border ${
                                    ev.type === "Class"
                                      ? "bg-indigo-500/10 border-indigo-500/20 text-indigo-300"
                                      : ev.type === "Exam"
                                      ? "bg-rose-500/10 border-rose-500/20 text-rose-300"
                                      : ev.type === "Holiday"
                                      ? "bg-amber-500/10 border-amber-500/20 text-amber-300"
                                      : "bg-[#030304]/60 border-white/[0.03] text-white/55"
                                  }`}>
                                    {ev.type}
                                  </span>
                                  <h4 className="font-bold text-white">{ev.title}</h4>
                                  <span className="block text-[9px] text-white/30 font-mono">Date: {ev.date} @ {ev.time}</span>
                                </div>

                                <button
                                  onClick={() => handleDeleteCalendarEvent(ev.id)}
                                  className="p-1.5 rounded-lg text-white/30 hover:text-red-400 hover:bg-white/[0.04] transition-colors cursor-pointer shrink-0"
                                  title="Remove Event"
                                >
                                  <Trash2 size={12} />
                                </button>
                              </div>
                            ));
                          })()}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 13: ANALYTICS */}
            {activeTab === "analytics" && (
              <AnalyticsTab students={students} courses={courses} showCustomToast={showCustomToast} />
            )}

            {/* TAB 14: SETTINGS */}
            {activeTab === "settings" && (
              <SettingsTab profile={profile} onSaveProfile={handleSaveProfile} showCustomToast={showCustomToast} />
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* TOAST POPUP NOTIFICATION CONTAINER */}
      <div className="fixed bottom-6 right-6 z-50 space-y-2 select-none text-xs pointer-events-none">
        <AnimatePresence>
          {customToasts.map((toast) => (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.95 }}
              className={`p-4 rounded-2xl border flex items-center gap-3 w-80 shadow-[0_15px_30px_rgba(0,0,0,0.5)] backdrop-blur-md pointer-events-auto ${
                toast.type === "success"
                  ? "bg-emerald-950/90 border-emerald-500/20 text-emerald-200"
                  : toast.type === "warning"
                  ? "bg-amber-950/90 border-amber-500/20 text-amber-200"
                  : "bg-zinc-900/95 border-zinc-700/30 text-zinc-100"
              }`}
            >
              <div className="space-y-0.5 text-left">
                <p className="font-sans font-bold leading-tight">{toast.message}</p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
