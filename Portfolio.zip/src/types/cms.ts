export interface CMSGeneralSettings {
  websiteTitle: string;
  websiteDescription: string;
  academyLogo: string;
  favicon: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  defaultFont: string;
  enableDarkTheme: boolean;
  maintenanceMode: boolean;
}

export interface CMSHeroSection {
  backgroundImage: string;
  overlayOpacity: number;
  overlayColor: string;
  heroTitle: string;
  heroSubtitle: string;
  animatedTexts: string[]; // split by comma
  ctaButtonText: string;
  ctaButtonLink: string;
  typingSpeed: number;
  loopTyping: boolean;
  cursorStyle: "pipe" | "block" | "underline";
  fadeAnimation: boolean;
}

export interface CMSAboutMe {
  sectionTitle: string;
  subtitle: string;
  description: string;
  personalImage: string;
  statistics: { label: string; value: string }[];
  socialLinks: {
    twitter?: string;
    facebook?: string;
    github?: string;
    linkedin?: string;
    instagram?: string;
  };
}

export interface CMSSkill {
  id: string;
  name: string;
  percentage: number;
  icon: string;
  enabled: boolean;
  displayOrder: number;
}

export interface CMSProject {
  id: string;
  title: string;
  description: string;
  coverImage: string;
  galleryImages: string[];
  technologies: string[];
  githubLink: string;
  liveDemoLink: string;
  category: string;
  displayOrder: number;
  featured: boolean;
}

export interface CMSClass {
  id: string;
  courseImage: string;
  courseName: string;
  instructor: string;
  price: string;
  description: string;
  sessions: number;
  status: "Draft" | "Published" | "Hidden";
  displayOrder: number;
  tags?: string[];
  syllabus?: { id: string; title: string; description: string; duration: string }[];
}

export interface CMSTestimonial {
  id: string;
  studentPhoto: string;
  studentName: string;
  course: string;
  rating: number;
  review: string;
  displayOrder: number;
}

export interface CMSContactSettings {
  title: string;
  description: string;
  email: string;
  phone: string;
  address: string;
  telegram: string;
  instagram: string;
  linkedin: string;
  github: string;
  submissionRecipientEmail: string;
}

export interface CMSFooterSettings {
  logo: string;
  animatedText: string;
  copyright: string;
  footerButtonText: string;
  footerButtonLink: string;
  footerDescription: string;
  navigationLinks: { label: string; url: string; id: string }[];
  socialLinks: { platform: string; url: string; id: string }[];
}

export interface CMSSEOSettings {
  homepageTitle: string;
  metaDescription: string;
  keywords: string;
  ogTitle: string;
  ogDescription: string;
  ogImage: string;
  canonicalUrl: string;
  robotsSettings: "index, follow" | "noindex, nofollow" | "index, nofollow" | "noindex, follow";
}

export interface CMSMediaFile {
  id: string;
  name: string;
  type: "image" | "video" | "pdf" | "icon";
  url: string;
  size: string;
  uploadDate: string;
  dimensions?: string;
  usageCount: number;
  usageLocations: string[];
}

export interface CMSFullConfig {
  general: CMSGeneralSettings;
  hero: CMSHeroSection;
  about: CMSAboutMe;
  skills: CMSSkill[];
  projects: CMSProject[];
  classes: CMSClass[];
  students: CMSTestimonial[];
  contact: CMSContactSettings;
  footer: CMSFooterSettings;
  seo: CMSSEOSettings;
  media: CMSMediaFile[];
}

export interface CMSVersionHistory {
  id: string;
  timestamp: string;
  label: string;
  config: CMSFullConfig;
}
