import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Check, X, FileText, Send, Eye, MessageSquare, AlertTriangle, HelpCircle,
  Award, Trash2, Shield, FolderOpen, Calendar, BookOpen, Download, HelpCircle as HelpIcon,
  Globe, PlayCircle, PlusCircle, LayoutDashboard, CheckSquare
} from "lucide-react";
import { Exam } from "./AdminDashboard/types";
import { Assignment, Certificate, DiscussionThread, Resource } from "../types/teacher";

interface LmsTabProps {
  assignments: Assignment[];
  exams: Exam[];
  certificates: Certificate[];
  discussions: DiscussionThread[];
  resources: Resource[];
  activeSubTab?: string;
  onAddExam: (exam: Exam) => void;
  onPublishExamResults: (id: string) => void;
  onApproveCertificate: (id: string) => void;
  onRejectCertificate: (id: string, notes?: string) => void;
  onAddDiscussionReply: (threadId: string, replyContent: string) => void;
  onCloseDiscussionThread: (threadId: string) => void;
  onAddResource: (res: Resource) => void;
  onDeleteResource: (id: string) => void;
}

export default function LmsTab({
  assignments,
  exams,
  certificates,
  discussions,
  resources,
  activeSubTab,
  onAddExam,
  onPublishExamResults,
  onApproveCertificate,
  onRejectCertificate,
  onAddDiscussionReply,
  onCloseDiscussionThread,
  onAddResource,
  onDeleteResource
}: LmsTabProps) {
  const [subTab, setSubTab] = useState<"assignments" | "exams" | "certificates" | "discussions" | "resources">("assignments");

  React.useEffect(() => {
    if (activeSubTab && ["assignments", "exams", "certificates", "discussions", "resources"].includes(activeSubTab)) {
      setSubTab(activeSubTab as any);
    }
  }, [activeSubTab]);
  
  // Gold Certificate preview state
  const [previewCert, setPreviewCert] = useState<Certificate | null>(null);
  
  // Discussions states
  const [selectedThread, setSelectedThread] = useState<DiscussionThread | null>(null);
  const [replyText, setReplyText] = useState("");

  // Exam Form states
  const [showExamModal, setShowExamModal] = useState(false);
  const [newExam, setNewExam] = useState<Partial<Exam>>({
    title: "",
    courseId: "react-adv",
    courseTitle: "Advanced React & Architecture",
    dueDate: "2026-07-15",
    maxPoints: 100
  });

  // Resource Form states
  const [showResModal, setShowResModal] = useState(false);
  const [newRes, setNewRes] = useState({
    title: "",
    type: "PDF" as "PDF" | "ZIP" | "DOC" | "CODE" | "VIDEO",
    size: "1.2 MB",
    course: "Advanced React & Architecture"
  });

  const handleCreateExamSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExam.title) return;

    onAddExam({
      id: "exam-" + Date.now(),
      title: newExam.title,
      courseId: newExam.courseId || "react-adv",
      courseTitle: newExam.courseId === "swiss-typo" ? "Swiss Typography & Editorial Layout" : "Advanced React & Architecture",
      dueDate: newExam.dueDate || "2026-07-20",
      maxPoints: newExam.maxPoints || 100,
      passRate: 0,
      avgScore: 0,
      status: "Draft"
    });

    setNewExam({ title: "", courseId: "react-adv", courseTitle: "Advanced React & Architecture", dueDate: "2026-07-15", maxPoints: 100 });
    setShowExamModal(false);
  };

  const handleCreateResourceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRes.title) return;

    onAddResource({
      id: "res-" + Date.now(),
      title: newRes.title,
      courseId: "react-adv",
      courseTitle: newRes.course,
      fileType: newRes.type.toLowerCase() as any,
      fileSize: newRes.size,
      uploadedAt: new Date().toISOString().split("T")[0],
      visibility: "Visible"
    });

    setNewRes({ title: "", type: "PDF", size: "1.2 MB", course: "Advanced React & Architecture" });
    setShowResModal(false);
  };

  const handleDiscussionReplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedThread || !replyText.trim()) return;

    onAddDiscussionReply(selectedThread.id, replyText);
    
    // Refresh selected thread state
    const updated = discussions.find(d => d.id === selectedThread.id);
    if (updated) {
      setSelectedThread({ ...updated });
    }
    setReplyText("");
  };

  return (
    <div className="space-y-6">
      
      {/* Sub tabs switcher */}
      <div className="flex border-b border-white/[0.05] gap-6 text-xs">
        {[
          { id: "assignments", label: "Assignments Overview" },
          { id: "exams", label: "Exam Manager" },
          { id: "certificates", label: "Certificate Approvals" },
          { id: "discussions", label: "Moderation Forums" },
          { id: "resources", label: "Syllabus Resources" }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSubTab(tab.id as any)}
            className={`pb-3 font-extrabold tracking-wider uppercase transition-all relative ${
              subTab === tab.id 
                ? "text-indigo-400" 
                : "text-white/40 hover:text-white"
            }`}
          >
            {tab.label}
            {subTab === tab.id && (
              <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-indigo-400" />
            )}
          </button>
        ))}
      </div>

      {/* SUB-TAB: GLOBAL ASSIGNMENTS */}
      {subTab === "assignments" && (
        <div className="space-y-4 text-left">
          <div>
            <h3 className="text-sm font-black text-white uppercase tracking-wider">LMS Assignments Tracking</h3>
            <p className="text-[10px] text-white/40">Monitor homework, coding reviews, timelines, and instructor grading status.</p>
          </div>

          <div className="p-6 rounded-3xl border border-white/[0.06] bg-zinc-950/60 backdrop-blur-md overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-white/[0.05] text-white/30 uppercase tracking-widest text-[9px] font-black">
                  <th className="pb-3 font-black">Assignment Title</th>
                  <th className="pb-3 font-black">Linked Course</th>
                  <th className="pb-3 font-black">Submission Deadline</th>
                  <th className="pb-3 font-black text-center">Weight Ratio</th>
                  <th className="pb-3 font-black text-center">Submission Status</th>
                  <th className="pb-3 font-black text-center">Avg Grade</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.02]">
                {assignments.map((ass) => (
                  <tr key={ass.id} className="hover:bg-white/[0.01] transition-all">
                    <td className="py-4 font-extrabold text-white">
                      {ass.title}
                    </td>
                    <td className="py-4 text-indigo-300 font-bold">
                      {ass.courseTitle}
                    </td>
                    <td className="py-4 font-mono text-[10px] text-white/40">
                      {ass.dueDate}
                    </td>
                    <td className="py-4 text-center font-mono text-white/60">
                      20% Weight
                    </td>
                    <td className="py-4 text-center">
                      <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-mono font-black uppercase border ${
                        ass.status === "Published"
                          ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                          : "bg-rose-500/10 border-rose-500/20 text-rose-400"
                      }`}>
                        {ass.status}
                      </span>
                    </td>
                    <td className="py-4 text-center font-mono font-bold text-emerald-400">
                      84% Avg
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-TAB: EXAM MANAGER */}
      {subTab === "exams" && (
        <div className="space-y-4 text-left">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider">Academy Exam Manager</h3>
              <p className="text-[10px] text-white/40">Launch standardized midterms, custom quizzes, publish grade results, and monitor pass ratios.</p>
            </div>
            <button 
              onClick={() => setShowExamModal(true)}
              className="px-4 py-1.5 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-black text-xs font-bold transition-all flex items-center gap-1"
            >
              <PlusCircle size={13} />
              <span>Create Exam</span>
            </button>
          </div>

          <div className="p-6 rounded-3xl border border-white/[0.06] bg-zinc-950/60 backdrop-blur-md overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-white/[0.05] text-white/30 uppercase tracking-widest text-[9px] font-black">
                  <th className="pb-3 font-black">Exam Name</th>
                  <th className="pb-3 font-black">Assigned Course</th>
                  <th className="pb-3 font-black text-center">Pass Rate Ratio</th>
                  <th className="pb-3 font-black text-center">Class Avg score</th>
                  <th className="pb-3 font-black text-center">Max Points</th>
                  <th className="pb-3 font-black">Assigned Date</th>
                  <th className="pb-3 text-right font-black">Administrative Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.02]">
                {exams.map((ex) => (
                  <tr key={ex.id} className="hover:bg-white/[0.01] transition-all">
                    <td className="py-4 font-extrabold text-white">
                      {ex.title}
                    </td>
                    <td className="py-4 text-white/70">
                      {ex.courseTitle}
                    </td>
                    <td className="py-4 text-center font-mono font-extrabold text-indigo-400">
                      {ex.status === "Published" ? `${ex.passRate || 92}%` : "Not graded"}
                    </td>
                    <td className="py-4 text-center font-mono font-extrabold text-emerald-400">
                      {ex.status === "Published" ? `${ex.avgScore || 78}%` : "Not graded"}
                    </td>
                    <td className="py-4 text-center font-mono text-white/60">
                      {ex.maxPoints} pts
                    </td>
                    <td className="py-4 font-mono text-[10px] text-white/40">
                      {ex.dueDate}
                    </td>
                    <td className="py-4 text-right">
                      {ex.status === "Draft" ? (
                        <button 
                          onClick={() => onPublishExamResults(ex.id)}
                          className="px-2.5 py-1 rounded bg-emerald-500 text-black text-[9px] font-bold tracking-wider uppercase hover:bg-emerald-400"
                        >
                          Publish Results
                        </button>
                      ) : (
                        <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase">Published & Filed</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-TAB: DIGITAL CERTIFICATE APPROVALS */}
      {subTab === "certificates" && (
        <div className="space-y-4 text-left">
          <div>
            <h3 className="text-sm font-black text-white uppercase tracking-wider">Digital Certificates Approvals</h3>
            <p className="text-[10px] text-white/40">Oversee student academic graduation requests. Review gold-foil certifications with full digital audit trails.</p>
          </div>

          <div className="p-6 rounded-3xl border border-white/[0.06] bg-zinc-950/60 backdrop-blur-md overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-white/[0.05] text-white/30 uppercase tracking-widest text-[9px] font-black">
                  <th className="pb-3 font-black">Student Name</th>
                  <th className="pb-3 font-black">Earned Course Program</th>
                  <th className="pb-3 font-black text-center">Academic GPA</th>
                  <th className="pb-3 font-black">Certificate Status</th>
                  <th className="pb-3 font-black">Issue Dates</th>
                  <th className="pb-3 text-right font-black">Administrative Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.02]">
                {certificates.map((cert) => (
                  <tr key={cert.id} className="hover:bg-white/[0.01] transition-all">
                    <td className="py-4 font-extrabold text-white">
                      {cert.studentName}
                    </td>
                    <td className="py-4 text-indigo-300 font-bold">
                      {cert.courseTitle}
                    </td>
                    <td className="py-4 text-center font-mono font-bold text-white/80">
                      {cert.gpa} GPA
                    </td>
                    <td className="py-4">
                      <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-mono font-black uppercase border ${
                        cert.status === "Approved"
                          ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                          : cert.status === "Rejected"
                          ? "bg-rose-500/10 border-rose-500/20 text-rose-400"
                          : "bg-amber-500/10 border-amber-500/20 text-amber-400"
                      }`}>
                        {cert.status}
                      </span>
                    </td>
                    <td className="py-4 font-mono text-[10px] text-white/40">
                      {cert.issueDate || "Awaiting Verification"}
                    </td>
                    <td className="py-4 text-right">
                      <div className="flex justify-end items-center gap-1.5">
                        {/* Certificate visual preview button */}
                        <button 
                          onClick={() => setPreviewCert(cert)}
                          className="p-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 hover:bg-indigo-500 hover:text-black transition-all flex items-center gap-1 font-bold text-[10px]"
                        >
                          <Eye size={11} />
                          <span>Preview Frame</span>
                        </button>

                        {(cert.status === "Waiting for Admin Approval" || cert.status === "Signed by Instructor" || cert.status === "Draft") && (
                          <>
                            <button 
                              onClick={() => onApproveCertificate(cert.id)}
                              className="px-2 py-1 rounded bg-emerald-500 text-black text-[9px] font-bold uppercase hover:bg-emerald-400"
                            >
                              Approve
                            </button>
                            <button 
                              onClick={() => onRejectCertificate(cert.id)}
                              className="px-2 py-1 rounded bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[9px] font-bold uppercase hover:bg-rose-500 hover:text-black"
                            >
                              Reject
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-TAB: FORUM MODERATION */}
      {subTab === "discussions" && (
        <div className="space-y-4 text-left grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Threads list (5 cols) */}
          <div className="lg:col-span-5 p-6 rounded-3xl border border-white/[0.06] bg-zinc-950/60 backdrop-blur-md space-y-4 h-[550px] overflow-y-auto">
            <h3 className="text-xs font-black text-white uppercase tracking-wider">Active Threads</h3>
            
            <div className="space-y-2">
              {discussions.map((thread) => (
                <div 
                  key={thread.id}
                  onClick={() => setSelectedThread(thread)}
                  className={`p-4 rounded-2xl border border-white/[0.04] bg-white/[0.01] hover:bg-white/[0.02] cursor-pointer text-xs space-y-2 transition-all ${
                    selectedThread?.id === thread.id ? "border-indigo-500 bg-indigo-500/[0.02]" : ""
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className="text-[9px] font-mono uppercase bg-indigo-500/10 text-indigo-300 px-1.5 py-0.5 rounded font-bold">{thread.courseTitle}</span>
                    <span className="text-[8px] font-mono text-white/30">{thread.time}</span>
                  </div>
                  <h4 className="font-extrabold text-white truncate">{thread.title}</h4>
                  <div className="flex justify-between text-[10px] text-white/50">
                    <span>By: {thread.studentName}</span>
                    <span className="flex items-center gap-1 text-indigo-400"><MessageSquare size={11} /> {thread.replies.length} replies</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Active Reply Panel (7 cols) */}
          <div className="lg:col-span-7 p-6 rounded-3xl border border-white/[0.06] bg-zinc-950/60 backdrop-blur-md flex flex-col justify-between h-[550px]">
            {selectedThread ? (
              <div className="flex flex-col h-full justify-between">
                
                {/* Header */}
                <div className="border-b border-white/[0.05] pb-3 mb-3 flex justify-between items-center">
                  <div>
                    <h4 className="font-extrabold text-sm text-white">{selectedThread.title}</h4>
                    <p className="text-[9px] text-white/40">Filer: <span className="text-white/60">{selectedThread.studentName}</span> • Course: <span className="text-indigo-400 font-bold">{selectedThread.courseTitle}</span></p>
                  </div>
                  <button 
                    onClick={() => onCloseDiscussionThread(selectedThread.id)}
                    className="px-2 py-0.5 border border-white/10 rounded-lg text-white/40 hover:text-white text-[9px] font-bold"
                  >
                    Close Thread
                  </button>
                </div>

                {/* Messages scroll box */}
                <div className="flex-1 overflow-y-auto space-y-4 pr-2 text-xs text-left mb-4 scrollbar-thin">
                  {/* Student Question */}
                  <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/[0.04] space-y-1 max-w-[85%]">
                    <div className="flex justify-between text-[9px] font-mono text-white/30">
                      <span>{selectedThread.studentName} (Student)</span>
                      <span>{selectedThread.time}</span>
                    </div>
                    <p className="text-white/80 leading-relaxed font-sans">{selectedThread.text || "Original question regarding assignments structure."}</p>
                  </div>

                  {/* Reply timeline */}
                  {selectedThread.replies.map((rep) => (
                    <div 
                      key={rep.id}
                      className={`p-3.5 rounded-2xl max-w-[85%] space-y-1 ${
                        rep.role === "Instructor"
                          ? "bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 ml-auto"
                          : "bg-white/[0.02] border border-white/[0.04]"
                      }`}
                    >
                      <div className="flex justify-between text-[9px] font-mono text-white/30">
                        <span>{rep.sender} ({rep.role})</span>
                        <span>{rep.time}</span>
                      </div>
                      <p className="text-white/85 leading-relaxed font-sans">{rep.text}</p>
                    </div>
                  ))}
                </div>

                {/* Reply Form */}
                <form onSubmit={handleDiscussionReplySubmit} className="flex gap-2">
                  <input 
                    type="text" 
                    placeholder="Type official admin reply..."
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    className="flex-1 bg-zinc-900 border border-white/10 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                  <button 
                    type="submit"
                    className="px-4 py-2 bg-indigo-500 hover:bg-indigo-400 text-black rounded-xl font-bold transition-all flex items-center justify-center gap-1 shrink-0"
                  >
                    <Send size={12} />
                    <span>Send</span>
                  </button>
                </form>

              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center text-xs text-white/30">
                <MessageSquare size={30} className="mb-2 text-white/10" />
                <span>Select a thread from the roster to moderate, respond or lock.</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUB-TAB: GLOBAL SYLLABUS RESOURCES */}
      {subTab === "resources" && (
        <div className="space-y-4 text-left">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider">Academy Resource Repository</h3>
              <p className="text-[10px] text-white/40">Organize and upload course assets, PDF guides, repository templates, and ZIP archives.</p>
            </div>
            <button 
              onClick={() => setShowResModal(true)}
              className="px-4 py-1.5 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-black text-xs font-bold transition-all flex items-center gap-1"
            >
              <PlusCircle size={13} />
              <span>Upload Resource</span>
            </button>
          </div>

          <div className="p-6 rounded-3xl border border-white/[0.06] bg-zinc-950/60 backdrop-blur-md overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-white/[0.05] text-white/30 uppercase tracking-widest text-[9px] font-black">
                  <th className="pb-3 font-black">File Resource Name</th>
                  <th className="pb-3 font-black">Assigned Course</th>
                  <th className="pb-3 font-black">Type Format</th>
                  <th className="pb-3 font-black text-center">Size Ratio</th>
                  <th className="pb-3 font-black text-center">Downloads</th>
                  <th className="pb-3 font-black">Date Uploaded</th>
                  <th className="pb-3 text-right font-black">Administrative Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.02]">
                {resources.map((res) => (
                  <tr key={res.id} className="hover:bg-white/[0.01] transition-all">
                    <td className="py-4">
                      <div className="flex items-center gap-2">
                        <FileText size={13} className="text-indigo-400" />
                        <span className="font-extrabold text-white">{res.title}</span>
                      </div>
                    </td>
                    <td className="py-4 text-white/70">
                      {res.courseTitle}
                    </td>
                    <td className="py-4">
                      <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider ${
                        res.fileType.toUpperCase() === "PDF"
                          ? "bg-rose-500/15 text-rose-400"
                          : res.fileType.toUpperCase() === "ZIP"
                          ? "bg-amber-500/15 text-amber-400"
                          : "bg-emerald-500/15 text-emerald-400"
                      }`}>
                        {res.fileType.toUpperCase()}
                      </span>
                    </td>
                    <td className="py-4 text-center font-mono font-bold text-white/50">
                      {res.fileSize || "1.5 MB"}
                    </td>
                    <td className="py-4 text-center font-mono font-bold text-indigo-300">
                      {res.id.charCodeAt(res.id.length - 1) % 20 + 3} hits
                    </td>
                    <td className="py-4 font-mono text-[10px] text-white/40">
                      {res.uploadedAt || "2026-06-15"}
                    </td>
                    <td className="py-4 text-right">
                      <div className="flex justify-end gap-1.5">
                        <button 
                          onClick={() => {
                            alert("Downloading simulated file package: " + res.title);
                          }}
                          className="p-1 rounded bg-white/[0.02] border border-white/[0.04] text-indigo-300 hover:text-indigo-400 text-xs flex items-center gap-1 font-bold"
                          title="Simulate Download"
                        >
                          <Download size={11} />
                        </button>
                        <button 
                          onClick={() => onDeleteResource(res.id)}
                          className="p-1 rounded bg-rose-500/10 border border-rose-500/20 text-rose-400 hover:bg-rose-500 hover:text-black transition-all"
                          title="Remove Resource"
                        >
                          <Trash2 size={11} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Gold foil visual Frame Modal for certificate preview */}
      <AnimatePresence>
        {previewCert && (
          <div className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center z-50 p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="w-full max-w-2xl bg-zinc-950 border border-amber-500/30 rounded-[32px] p-8 shadow-[0_0_80px_rgba(245,158,11,0.15)] relative overflow-hidden"
            >
              {/* Outer Golden Line border */}
              <div className="absolute inset-4 border border-amber-500/20 rounded-[24px] pointer-events-none" />
              <div className="absolute inset-[18px] border border-amber-500/10 rounded-[22px] pointer-events-none" />

              <div className="text-center space-y-6 py-6 select-none">
                {/* Logo & emblem */}
                <div className="flex flex-col items-center gap-1">
                  <Award size={36} className="text-amber-500 animate-pulse" />
                  <p className="text-[9px] text-amber-500/70 font-mono tracking-widest font-black uppercase">ROOZZERO ACADEMY CERTIFICATE OF GRADUATION</p>
                </div>

                <div className="space-y-2">
                  <p className="text-[11px] text-white/50 italic">This official digital document verifies that</p>
                  <h2 className="text-2xl sm:text-3xl font-black text-white tracking-wide uppercase font-sans drop-shadow-[0_0_10px_rgba(255,255,255,0.15)]">{previewCert.studentName}</h2>
                  <p className="text-[11px] text-white/50 italic">has successfully completed all strict curriculum criteria for</p>
                </div>

                <div className="py-2.5 max-w-md mx-auto border-y border-amber-500/15">
                  <h3 className="text-md sm:text-lg font-black tracking-wider text-amber-400 uppercase">{previewCert.courseTitle}</h3>
                </div>

                <div className="grid grid-cols-3 gap-4 pt-4 text-left max-w-md mx-auto text-[9px] font-mono text-white/40">
                  <div>
                    <p className="border-b border-white/10 pb-1 font-bold">GPA RATING</p>
                    <p className="text-emerald-400 font-extrabold pt-1">{previewCert.gpa} / 4.0 GPA</p>
                  </div>
                  <div>
                    <p className="border-b border-white/10 pb-1 font-bold">VERIFICATION ID</p>
                    <p className="text-indigo-400 pt-1 font-mono">{previewCert.id}</p>
                  </div>
                  <div>
                    <p className="border-b border-white/10 pb-1 font-bold">DATE COMPLETED</p>
                    <p className="text-white/70 pt-1">{previewCert.issueDate || "PENDING AUDIT"}</p>
                  </div>
                </div>

                {/* Digital Signatures */}
                <div className="pt-8 flex justify-between items-center max-w-sm mx-auto text-[9px] font-mono text-white/30 text-center">
                  <div className="space-y-1">
                    <p className="italic text-indigo-300 font-bold font-sans">Jaden Smith</p>
                    <div className="border-t border-white/10 w-24 pt-1">DIRECTOR SIGNATURE</div>
                  </div>
                  <div className="space-y-1">
                    <p className="italic text-emerald-400 font-bold font-sans">Verified Digital Signature</p>
                    <div className="border-t border-white/10 w-24 pt-1">ROOZZERO SYSTEM AUTH</div>
                  </div>
                </div>
              </div>

              {/* Close Button */}
              <button 
                onClick={() => setPreviewCert(null)}
                className="absolute top-4 right-4 p-2 text-white/40 hover:text-white hover:bg-white/5 rounded-full"
              >
                <X size={15} />
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Slide-over Modal: Create New Exam */}
      {showExamModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-md bg-[#0d0d12] border border-white/10 rounded-3xl p-6 text-left space-y-4 text-xs">
            <h3 className="text-xs font-black text-white uppercase tracking-wider">Create Standardized Exam</h3>
            
            <form onSubmit={handleCreateExamSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-[9px] text-white/40 uppercase font-black tracking-widest">Exam Name</label>
                <input 
                  type="text" 
                  required
                  placeholder="e.g. Midterm Coding Assessment"
                  value={newExam.title}
                  onChange={(e) => setNewExam({ ...newExam, title: e.target.value })}
                  className="w-full bg-zinc-900 border border-white/10 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[9px] text-white/40 uppercase font-black tracking-widest">Max Points</label>
                  <input 
                    type="number" 
                    value={newExam.maxPoints}
                    onChange={(e) => setNewExam({ ...newExam, maxPoints: parseInt(e.target.value) || 100 })}
                    className="w-full bg-zinc-900 border border-white/10 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-indigo-500 font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[9px] text-white/40 uppercase font-black tracking-widest">Linked Course</label>
                  <select
                    value={newExam.courseId}
                    onChange={(e) => setNewExam({ ...newExam, courseId: e.target.value })}
                    className="w-full bg-zinc-900 border border-white/10 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="react-adv">Advanced React</option>
                    <option value="swiss-typo">Swiss Typography</option>
                  </select>
                </div>
              </div>

              <div className="pt-2">
                <button type="submit" className="w-full py-2 bg-indigo-500 text-black font-bold uppercase tracking-wider rounded-xl hover:bg-indigo-400">Launch Exam Draft</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Slide-over Modal: Create New Resource */}
      {showResModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-md bg-[#0d0d12] border border-white/10 rounded-3xl p-6 text-left space-y-4 text-xs">
            <h3 className="text-xs font-black text-white uppercase tracking-wider">Publish Syllabus Material</h3>
            
            <form onSubmit={handleCreateResourceSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-[9px] text-white/40 uppercase font-black tracking-widest">File Asset Name</label>
                <input 
                  type="text" 
                  required
                  placeholder="e.g. Flexbox Layout Guide Sheet"
                  value={newRes.title}
                  onChange={(e) => setNewRes({ ...newRes, title: e.target.value })}
                  className="w-full bg-zinc-900 border border-white/10 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[9px] text-white/40 uppercase font-black tracking-widest">Format Type</label>
                  <select
                    value={newRes.type}
                    onChange={(e) => setNewRes({ ...newRes, type: e.target.value as any })}
                    className="w-full bg-zinc-900 border border-white/10 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="PDF">PDF Sheet</option>
                    <option value="ZIP">ZIP Codebase</option>
                    <option value="DOC">DOC Guide</option>
                    <option value="CODE">CODE Snippet</option>
                    <option value="VIDEO">VIDEO Tutorial</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[9px] text-white/40 uppercase font-black tracking-widest">File Size</label>
                  <input 
                    type="text" 
                    value={newRes.size}
                    onChange={(e) => setNewRes({ ...newRes, size: e.target.value })}
                    className="w-full bg-zinc-900 border border-white/10 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-indigo-500 font-mono"
                  />
                </div>
              </div>

              <div className="pt-2">
                <button type="submit" className="w-full py-2 bg-indigo-500 text-black font-bold uppercase tracking-wider rounded-xl hover:bg-indigo-400">Deploy Syllabus Material</button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
