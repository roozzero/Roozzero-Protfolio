/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from "react";
import { motion, useMotionValue, useSpring } from "motion/react";
import { Sparkles, ArrowRight, Star, MapPin, Calendar as CalendarIcon, User, X, ChevronLeft, ChevronRight, Clock, Heart, Compass as CompassIcon, ChevronDown, ChevronUp, BookOpen, Award, CheckCircle2, FileDown, Github } from "lucide-react";
import Navbar from "./components/Navbar";
import StudentsSection from "./components/StudentsSection";
import ContactSection from "./components/ContactSection";
import Footer from "./components/Footer";
import LoginModal from "./components/LoginModal";
import UserDashboard from "./components/UserDashboard";
import AdminDashboard from "./components/AdminDashboard";
import TeacherDashboard from "./components/TeacherDashboard";
import BackToTop from "./components/BackToTop";

interface Preset {
  name: string;
  orb1: string;
  orb2: string;
  orb3: string;
  orb4: string;
  gridColor: string;
  lineColor: string;
}

const PRESETS: Preset[] = [
  {
    name: "Editorial Minimalist",
    orb1: "rgba(255, 255, 255, 0.05)", // Gentle warm white
    orb2: "rgba(40, 50, 120, 0.07)",  // Deep editorial navy
    orb3: "rgba(255, 255, 255, 0.02)", // Central white dust
    orb4: "rgba(10, 10, 10, 0.20)",   // Obsidian velvet shadow
    gridColor: "rgba(255, 255, 255, 0.02)",
    lineColor: "rgba(255, 255, 255, 0.06)",
  },
  {
    name: "Cosmic Aurora",
    orb1: "rgba(99, 102, 241, 0.07)", // Indigo glow
    orb2: "rgba(168, 85, 247, 0.05)", // Violet mist
    orb3: "rgba(20, 184, 166, 0.04)", // Soft cyan glow
    orb4: "rgba(245, 158, 11, 0.03)", // Subtle amber ray
    gridColor: "rgba(99, 102, 241, 0.03)",
    lineColor: "rgba(168, 85, 247, 0.07)",
  },
  {
    name: "Golden Eclipse",
    orb1: "rgba(239, 68, 68, 0.04)", // Crimson shadow
    orb2: "rgba(245, 158, 11, 0.06)", // Delicate gold
    orb3: "rgba(253, 224, 71, 0.03)", // Champagne shine
    orb4: "rgba(30, 41, 59, 0.06)",  // Slate gray
    gridColor: "rgba(245, 158, 11, 0.03)",
    lineColor: "rgba(245, 158, 11, 0.08)",
  },
  {
    name: "Obsidian Silver",
    orb1: "rgba(255, 255, 255, 0.03)", // Platinum ray
    orb2: "rgba(148, 163, 184, 0.04)", // Steel light
    orb3: "rgba(51, 65, 85, 0.05)",   // Charcoal depth
    orb4: "rgba(15, 23, 42, 0.1)",    // Obsidian blackness
    gridColor: "rgba(255, 255, 255, 0.02)",
    lineColor: "rgba(255, 255, 255, 0.08)",
  },
];

interface Ripple {
  id: number;
  x: number;
  y: number;
}

const DEFAULT_HOMEPAGE_CLASSES = [
  {
    id: "techzo",
    courseImage: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=800&auto=format&fit=crop",
    courseName: "Techzo: Creative Agency System",
    instructor: "Roozbeh",
    price: "$149",
    description: "An immersive masterclass on building highly interactive, micro-animated studio systems with smooth spring physics, responsive grid architectures, and cinematic lighting.",
    sessions: 12,
    status: "Published",
    displayOrder: 1,
    tags: ["HTML5 & CSS", "Framer Motion", "Vite"],
    syllabus: [
      { id: "s1", title: "Advanced Grid & Immersive Layout Layouts", description: "Mastering multi-column modern alignment, viewport control, and custom margins.", duration: "45 mins" },
      { id: "s2", title: "Framer Motion Micro-Animations", description: "Designing spring physics, hover interactions, page reveals, and viewport triggering.", duration: "60 mins" },
      { id: "s3", title: "Dark Theme Colors & Ambient Shadows", description: "Defining professional color palettes, blur ratios, gradients, and custom overlays.", duration: "30 mins" },
      { id: "s4", title: "Deploying High-Fidelity Apps with Vite", description: "Packaging final static web assets, bundle size checks, and hosting on lightning-fast CDNs.", duration: "40 mins" }
    ]
  },
  {
    id: "lumin",
    courseImage: "https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=800&auto=format&fit=crop",
    courseName: "Lumin Studio: Design Aesthetics",
    instructor: "Roozbeh",
    price: "$199",
    description: "A comprehensive design system course focused on crafting clean component libraries, implementing responsive styling, and deploying production-ready applications.",
    sessions: 16,
    status: "Published",
    displayOrder: 2,
    tags: ["HTML5 & Tailwind CSS", "React", "Vite"],
    syllabus: [
      { id: "s1", title: "React Design System Architecture", description: "Creating modular UI tokens, layouts, buttons, and fully dynamic state structures.", duration: "50 mins" },
      { id: "s2", title: "Responsive Styling with Tailwind CSS", description: "Using responsive flex/grids, customized font utilities, and pixel-perfect sizing.", duration: "45 mins" },
      { id: "s3", title: "Typography Reflections & Vector Styling", description: "Recreating high-end reflection aesthetics, blur mechanics, and responsive device shells.", duration: "40 mins" },
      { id: "s4", title: "Sleek Showcase & Portfolio SEO", description: "Optimizing load times, search engine configurations, meta tags, and premium client pitch decks.", duration: "35 mins" }
    ]
  }
];

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(() => localStorage.getItem("isLoggedIn") === "true");
  const [userRole, setUserRole] = useState(() => localStorage.getItem("userRole") || "user");
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isDashboardPage, setIsDashboardPage] = useState(window.location.hash === "#dashboard");
  const [isAdminPage, setIsAdminPage] = useState(window.location.hash === "#admin");

  const animatedTexts = useMemo(() => [
    "Full Stack Engineering",
    "React & Vite Optimization",
    "Cloud Computing & Deployments",
    "Elegant Design Systems"
  ], []);

  const [currentTextIndex, setCurrentTextIndex] = useState(0);
  const [currentText, setCurrentText] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    const fullText = animatedTexts[currentTextIndex];
    
    if (isDeleting) {
      timer = setTimeout(() => {
        setCurrentText(fullText.substring(0, currentText.length - 1));
      }, 50);
    } else {
      timer = setTimeout(() => {
        setCurrentText(fullText.substring(0, currentText.length + 1));
      }, 100);
    }

    if (!isDeleting && currentText === fullText) {
      timer = setTimeout(() => setIsDeleting(true), 1500);
    } else if (isDeleting && currentText === "") {
      setIsDeleting(false);
      setCurrentTextIndex((prev) => (prev + 1) % animatedTexts.length);
    }

    return () => clearTimeout(timer);
  }, [currentText, isDeleting, currentTextIndex, animatedTexts]);

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash === "#login") {
        setIsLoginModalOpen(true);
        window.location.hash = "";
      } else {
        setIsDashboardPage(hash === "#dashboard");
        setIsAdminPage(hash === "#admin");
      }
    };
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  // Redirect unauthenticated user accessing dashboard/admin back to landing page, keeping modal closed
  useEffect(() => {
    if ((isDashboardPage || isAdminPage) && !isLoggedIn) {
      setIsDashboardPage(false);
      setIsAdminPage(false);
      window.location.hash = "";
    }
  }, [isDashboardPage, isAdminPage, isLoggedIn]);

  // Redirect to corresponding dashboard if already authenticated user tries to access login when open
  useEffect(() => {
    if (isLoginModalOpen && isLoggedIn) {
      setIsLoginModalOpen(false);
      if (userRole === "admin") {
        window.location.hash = "#admin";
      } else {
        window.location.hash = "#dashboard";
      }
    }
  }, [isLoginModalOpen, isLoggedIn, userRole]);

  useEffect(() => {
    if (!isDashboardPage && !isAdminPage && window.location.hash) {
      const targetId = window.location.hash.substring(1);
      if (targetId && targetId !== "login" && targetId !== "dashboard" && targetId !== "admin") {
        setTimeout(() => {
          const element = document.getElementById(targetId);
          if (element) {
            const navbarHeight = 84;
            const elementPosition = element.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.scrollY - navbarHeight;
            window.scrollTo({
              top: offsetPosition,
              behavior: "smooth"
            });
          }
        }, 120);
      }
    }
  }, [isDashboardPage, isAdminPage]);

  const [presetIndex, setPresetIndex] = useState(0);
  const [ripples, setRipples] = useState<Ripple[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  const preset = PRESETS[presetIndex];

  // Interactive Project states for Voo's Cinema
  const [activeScreen, setActiveScreen] = useState<number>(2); // Default to centerpiece (After Earth)
  const [selectedDate, setSelectedDate] = useState<number>(5); // Default calendar date selected (July 5)
  const [selectedShowtime, setSelectedShowtime] = useState<string>("13:00"); // Selected movie showtime
  const [selectedSeats, setSelectedSeats] = useState<string[]>(["C4", "C5"]); // Selected seat IDs
  
  // Dynamic Classes state synchronized with the CMS Admin Dashboard
  const [homepageClasses, setHomepageClasses] = useState<any[]>(() => {
    const saved = localStorage.getItem("cms_current_config");
    if (saved) {
      try {
        const config = JSON.parse(saved);
        if (config && Array.isArray(config.classes)) {
          return config.classes;
        }
      } catch (e) {
        console.error("Failed to parse homepage classes", e);
      }
    }
    return DEFAULT_HOMEPAGE_CLASSES;
  });

  // Interactive Classes state
  const [openSyllabus, setOpenSyllabus] = useState<Record<string, boolean>>({});

  // Reload homepage classes whenever hash changes so that it picks up any admin dashboard edits!
  useEffect(() => {
    const handleHashChange = () => {
      const saved = localStorage.getItem("cms_current_config");
      if (saved) {
        try {
          const config = JSON.parse(saved);
          if (config && Array.isArray(config.classes)) {
            setHomepageClasses(config.classes);
          }
        } catch (e) {
          console.error(e);
        }
      }
    };
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  // Mouse tracking utilizing Framer Motion's off-main-thread spring system
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const springConfig = { damping: 45, stiffness: 120, mass: 1.2 };
  const glowX = useSpring(mouseX, springConfig);
  const glowY = useSpring(mouseY, springConfig);

  useEffect(() => {
    // Initial middle position
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      mouseX.set(rect.width / 2);
      mouseY.set(rect.height / 2);
    }

    const handleMouseMove = (e: MouseEvent) => {
      const rect = containerRef.current?.getBoundingClientRect();
      if (rect) {
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        mouseX.set(x);
        mouseY.set(y);
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        const touch = e.touches[0];
        const rect = containerRef.current?.getBoundingClientRect();
        if (rect) {
          const x = touch.clientX - rect.left;
          const y = touch.clientY - rect.top;
          mouseX.set(x);
          mouseY.set(y);
        }
      }
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("touchmove", handleTouchMove, { passive: true });
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("touchmove", handleTouchMove);
    };
  }, [mouseX, mouseY]);

  // Handle interaction to change presets and emit visual light ripples
  const handleContainerInteraction = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (rect) {
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      // Add fresh ripple
      const newRipple = {
        id: Date.now() + Math.random(),
        x,
        y,
      };
      setRipples((prev) => [...prev, newRipple]);

      // Cycle preset index
      setPresetIndex((prev) => (prev + 1) % PRESETS.length);
    }
  };

  // Generate slow, premium floating ambient dust motes
  const dustParticles = useMemo(() => {
    return Array.from({ length: 12 }).map((_, i) => ({
      id: i,
      size: Math.random() * 2 + 0.8,
      startX: `${Math.random() * 100}%`,
      startY: `${Math.random() * 100}%`,
      endX: `${Math.random() * 100}%`,
      endY: `${Math.random() * 100}%`,
      duration: Math.random() * 20 + 20, // 20s to 40s
      delay: Math.random() * -15, // staggered starts
    }));
  }, []);

  if (isDashboardPage && isLoggedIn) {
    if (userRole === "teacher") {
      return (
        <TeacherDashboard 
          onLogout={() => {
            setIsLoggedIn(false);
            localStorage.removeItem("isLoggedIn");
            localStorage.removeItem("userRole");
            window.location.hash = "#login";
          }}
          onGoHome={() => {
            window.location.hash = "#";
          }}
        />
      );
    }
    return (
      <UserDashboard 
        onLogout={() => {
          setIsLoggedIn(false);
          localStorage.removeItem("isLoggedIn");
          localStorage.removeItem("userRole");
          window.location.hash = "#login";
        }}
        onGoHome={() => {
          window.location.hash = "#";
        }}
      />
    );
  }

  if (isAdminPage && isLoggedIn && userRole === "admin") {
    return (
      <AdminDashboard 
        onLogout={() => {
          setIsLoggedIn(false);
          localStorage.removeItem("isLoggedIn");
          localStorage.removeItem("userRole");
          window.location.hash = "#login";
        }}
        onGoHome={() => {
          window.location.hash = "#";
        }}
      />
    );
  }

  return (
    <div id="ambient-canvas-wrapper" className="min-h-screen w-full bg-black overflow-x-hidden font-sans scroll-smooth flex flex-col items-center">
        {/* Premium Navigation Header */}
        <Navbar
        onPresetChange={() => setPresetIndex((prev) => (prev + 1) % PRESETS.length)}
        currentPresetName={preset.name}
        isLoggedIn={isLoggedIn}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
      />

      {/* Hero Section */}
      <section
        id="home"
        className="relative flex min-h-screen w-full items-center justify-center p-4 sm:p-6 md:p-12 pt-24 sm:pt-28 md:pt-32 overflow-hidden"
      >
        {/* Mobile-Only Hero Layout (Visible on mobile breakpoints only) */}
        <div id="hero-mobile-layout" className="flex flex-col w-full max-w-7xl md:hidden relative z-10 pt-4 pb-8">
          {/* Hero Image on Top */}
          <div 
            onClick={() => setPresetIndex((prev) => (prev + 1) % PRESETS.length)}
            className="relative w-full aspect-[4/3] rounded-2xl overflow-hidden border border-white/[0.04] bg-black cursor-pointer shadow-lg active:scale-[0.99] transition-transform duration-300 animate-fade-in"
          >
            <img
              src="/src/assets/images/ChatGPT Image Jun 28, 2026, 10_07_30 PM.png"
              alt="ROOZZERO Portrait Background"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-[center_15%] opacity-80 mix-blend-luminosity filter brightness-[0.7] contrast-[105%]"
            />
            {/* Cinematic lighting overlay to match original dark-theme premium appearance */}
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/30" />
            <div className="absolute inset-0 bg-radial-gradient(circle at 50% 50%, rgba(0,0,0,0) 20%, rgba(0,0,0,0.85) 100%)" />
          </div>

          {/* Hero Text Below Image */}
          <div className="mt-8 flex flex-col items-start text-left px-2">
            {/* Small Heading */}
            <span className="font-sans text-xs font-semibold tracking-[0.3em] text-white/50 uppercase leading-none">
              I'M
            </span>

            {/* Main Headline with typing effect */}
            <div className="flex flex-col items-start relative mt-4">
              <h1 className="font-sans text-3xl sm:text-4xl font-extrabold tracking-[0.22em] text-white uppercase leading-none z-20">
                ROOZZERO
              </h1>
              
              <div className="flex items-center gap-1.5 mt-3 min-h-[20px]">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="font-mono text-xs sm:text-sm font-bold tracking-wider text-emerald-400 uppercase">
                  {currentText}
                </span>
                <span className="font-mono text-white animate-pulse">|</span>
              </div>
            </div>
          </div>
        </div>

        {/* 16:9 Aspect Ratio Luxurious Floating Gallery Container (Hidden on mobile breakpoints) */}
        <div
          id="hero-16-9-frame"
          ref={containerRef}
          onClick={handleContainerInteraction}
          className="hidden md:block relative aspect-[16/9] w-full max-w-7xl cursor-pointer overflow-hidden rounded-2xl border border-white/[0.02] bg-black shadow-[0_0_150px_rgba(0,0,0,0.98)]"
          style={{
            "--orb-1": preset.orb1,
            "--orb-2": preset.orb2,
            "--orb-3": preset.orb3,
            "--orb-4": preset.orb4,
            "--grid-color": preset.gridColor,
            "--line-color": preset.lineColor,
            transition: "all 2000ms cubic-bezier(0.16, 1, 0.3, 1)",
          } as React.CSSProperties}
        >
         {/* Layer -1: Premium Dark Hero Background Image */}
        <div id="hero-image-background-container" className="absolute inset-0 w-full h-full pointer-events-none select-none z-0">
          <img
            src="/src/assets/images/ChatGPT Image Jun 28, 2026, 10_07_30 PM.png"
            alt="ROOZZERO Portrait Background"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-65 mix-blend-luminosity filter brightness-75 contrast-[105%]"
          />
          {/* Subtle dark linear and radial overlays to merge image edge with deep dark pure black borders and elevate left text readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/40" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/45 to-transparent" />
          <div className="absolute inset-0 bg-radial-gradient(circle at 35% 50%, rgba(0,0,0,0) 30%, rgba(0,0,0,0.95) 100%)" />
        </div>

        {/* Layer 0a: Editorial Aesthetic Subtle Depth Dark Vignette */}
        <div
          id="editorial-subtle-depth"
          className="absolute inset-0 w-full h-full pointer-events-none z-10"
          style={{
            background: "radial-gradient(circle at 50% 50%, rgba(10, 10, 10, 0) 0%, rgba(0, 0, 0, 0.8) 100%)",
          }}
        />

        {/* Layer 0b: Editorial Aesthetic Ambient Center Soft Light */}
        <div
          id="editorial-ambient-center"
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[200px] pointer-events-none blur-[60px] z-10"
          style={{
            background: "radial-gradient(ellipse, rgba(255, 255, 255, 0.02) 0%, rgba(0, 0, 0, 0) 80%)",
          }}
        />

        {/* Layer 0c: Editorial Aesthetic Horizon Line divider */}
        <div
          id="editorial-horizon-line"
          className="absolute bottom-[15%] left-0 right-0 h-[1px] pointer-events-none z-20"
          style={{
            background: "linear-gradient(90deg, transparent 0%, rgba(255, 255, 255, 0.05) 50%, transparent 100%)",
          }}
        />

        {/* Layer 0d: Editorial Aesthetic Rim Lighting */}
        <div
          id="editorial-rim-lighting"
          className="absolute inset-0 w-full h-full pointer-events-none z-30"
          style={{
            boxShadow: "inset 0 0 200px rgba(255, 255, 255, 0.015)",
          }}
        />

        {/* Layer 1: Volumetric Floating Light Source A (Ambient drift) */}
        <motion.div
          id="ambient-orb-indigo"
          className="absolute -top-1/4 -left-1/4 h-full w-full rounded-full blur-[160px] pointer-events-none"
          animate={{
            x: ["-10%", "15%", "-5%"],
            y: ["-5%", "10%", "-15%"],
            scale: [1, 1.15, 0.9],
          }}
          transition={{
            duration: 22,
            repeat: Infinity,
            repeatType: "mirror",
            ease: "easeInOut",
          }}
          style={{
            background: "var(--orb-1)",
            transition: "background 2000ms cubic-bezier(0.16, 1, 0.3, 1)",
          }}
        />

        {/* Layer 2: Volumetric Floating Light Source B (Ambient drift) */}
        <motion.div
          id="ambient-orb-violet"
          className="absolute -bottom-1/3 -right-1/4 h-full w-full rounded-full blur-[180px] pointer-events-none"
          animate={{
            x: ["10%", "-15%", "5%"],
            y: ["15%", "-10%", "-5%"],
            scale: [1.1, 0.9, 1.05],
          }}
          transition={{
            duration: 26,
            repeat: Infinity,
            repeatType: "mirror",
            ease: "easeInOut",
          }}
          style={{
            background: "var(--orb-2)",
            transition: "background 2000ms cubic-bezier(0.16, 1, 0.3, 1)",
          }}
        />

        {/* Layer 3: Volumetric Floating Light Source C (Ambient drift) */}
        <motion.div
          id="ambient-orb-teal"
          className="absolute top-1/3 left-1/3 h-[80%] w-[80%] rounded-full blur-[140px] pointer-events-none"
          animate={{
            x: ["-20%", "20%", "-10%"],
            y: ["20%", "-15%", "10%"],
          }}
          transition={{
            duration: 32,
            repeat: Infinity,
            repeatType: "mirror",
            ease: "easeInOut",
          }}
          style={{
            background: "var(--orb-3)",
            transition: "background 2000ms cubic-bezier(0.16, 1, 0.3, 1)",
          }}
        />

        {/* Layer 4: Volumetric Floating Light Source D (Ambient drift) */}
        <motion.div
          id="ambient-orb-gold"
          className="absolute top-10 right-1/4 h-[60%] w-[60%] rounded-full blur-[150px] pointer-events-none"
          animate={{
            x: ["15%", "-10%", "10%"],
            y: ["-10%", "20%", "-5%"],
            scale: [0.95, 1.1, 1],
          }}
          transition={{
            duration: 28,
            repeat: Infinity,
            repeatType: "mirror",
            ease: "easeInOut",
          }}
          style={{
            background: "var(--orb-4)",
            transition: "background 2000ms cubic-bezier(0.16, 1, 0.3, 1)",
          }}
        />

        {/* Layer 5: Interactive Soft Mouse Follower Ambient Light Beam */}
        <motion.div
          id="interactive-mouse-glow"
          className="absolute h-[450px] w-[450px] -translate-x-1/2 -translate-y-1/2 rounded-full pointer-events-none blur-[110px] mix-blend-screen opacity-55"
          style={{
            left: glowX,
            top: glowY,
            background: "radial-gradient(circle, rgba(255,255,255,0.06) 0%, rgba(255,255,255,0.01) 40%, transparent 70%)",
          }}
        />

        {/* Layer 6: Future Tech Isometric Linear Grid Plane with slow movement */}
        <div id="perspective-grid-container" className="absolute inset-x-0 bottom-0 h-[45%] overflow-hidden pointer-events-none select-none">
          <motion.div
            id="scrolling-grid"
            className="w-full h-[200%] origin-bottom"
            animate={{
              backgroundPositionY: ["0px", "100px"],
            }}
            transition={{
              duration: 30,
              repeat: Infinity,
              ease: "linear",
            }}
            style={{
              backgroundImage: "linear-gradient(to right, var(--grid-color) 1px, transparent 1px), linear-gradient(to bottom, var(--grid-color) 1px, transparent 1px)",
              backgroundSize: "50px 50px",
              transform: "perspective(260px) rotateX(74deg) translateY(-20px) scale(1.3)",
              maskImage: "linear-gradient(to top, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.1) 60%, rgba(0,0,0,0) 100%)",
              WebkitMaskImage: "linear-gradient(to top, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.1) 60%, rgba(0,0,0,0) 100%)",
              transition: "all 2000ms cubic-bezier(0.16, 1, 0.3, 1)",
            }}
          />
        </div>

        {/* Layer 7: Luxury Vector Architectural Waves */}
        <svg
          id="ambient-vector-curves"
          className="absolute inset-0 w-full h-full pointer-events-none select-none"
          viewBox="0 0 1440 810"
          fill="none"
          preserveAspectRatio="none"
        >
          <defs>
            <linearGradient id="vectorCurveGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="var(--line-color)" stopOpacity="0" />
              <stop offset="50%" stopColor="var(--line-color)" stopOpacity="0.45" />
              <stop offset="100%" stopColor="var(--line-color)" stopOpacity="0" />
            </linearGradient>
            <linearGradient id="vectorCurveGrad2" x1="100%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="var(--line-color)" stopOpacity="0" />
              <stop offset="35%" stopColor="var(--line-color)" stopOpacity="0.25" />
              <stop offset="75%" stopColor="var(--line-color)" stopOpacity="0.12" />
              <stop offset="100%" stopColor="var(--line-color)" stopOpacity="0" />
            </linearGradient>
            <filter id="softVectorGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="12" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Slow float-animated SVG Bezier group A */}
          <motion.g
            animate={{
              y: [0, -14, 0],
              rotate: [0, 0.4, 0],
            }}
            transition={{
              duration: 18,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            <path
              d="M -100 405 C 320 180, 1120 630, 1540 405"
              stroke="url(#vectorCurveGrad1)"
              strokeWidth="1.5"
              filter="url(#softVectorGlow)"
              style={{ transition: "stroke 2000ms cubic-bezier(0.16, 1, 0.3, 1)" }}
            />
          </motion.g>

          {/* Slow float-animated SVG Bezier group B */}
          <motion.g
            animate={{
              y: [0, 10, 0],
              rotate: [0, -0.3, 0],
            }}
            transition={{
              duration: 22,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            <path
              d="M -100 250 C 480 580, 960 120, 1540 580"
              stroke="url(#vectorCurveGrad2)"
              strokeWidth="1"
              strokeDasharray="5 5"
              style={{ transition: "stroke 2000ms cubic-bezier(0.16, 1, 0.3, 1)" }}
            />
          </motion.g>
        </svg>

        {/* Layer 8: Gentle drifting cosmic micro-particles (Dust Motes) */}
        <div id="ambient-particles-overlay" className="absolute inset-0 pointer-events-none overflow-hidden">
          {dustParticles.map((p) => (
            <motion.div
              key={p.id}
              className="absolute rounded-full bg-white/25 blur-[0.4px]"
              style={{
                width: p.size,
                height: p.size,
              }}
              animate={{
                x: [p.startX, p.endX, p.startX],
                y: [p.startY, p.endY, p.startY],
                opacity: [0, 0.28, 0.28, 0],
              }}
              transition={{
                duration: p.duration,
                delay: p.delay,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>

        {/* Layer 9: Interactive Click ripples of soft energy */}
        {ripples.map((ripple) => (
          <motion.div
            key={ripple.id}
            className="absolute -translate-x-1/2 -translate-y-1/2 rounded-full pointer-events-none border border-white/10"
            style={{
              left: ripple.x,
              top: ripple.y,
              background: "radial-gradient(circle, rgba(255,255,255,0.03) 0%, transparent 80%)",
            }}
            initial={{ width: 0, height: 0, opacity: 0.8, scale: 0.7 }}
            animate={{ width: 500, height: 500, opacity: 0, scale: 1.25 }}
            transition={{ duration: 2.2, ease: "easeOut" }}
            onAnimationComplete={() => {
              setRipples((prev) => prev.filter((r) => r.id !== ripple.id));
            }}
          />
        ))}

        {/* Layer 10: Film Grain texture for gorgeous cinema depth and anti-banding */}
        <svg
          id="film-grain-mask"
          className="pointer-events-none absolute inset-0 z-40 h-full w-full opacity-[0.016] mix-blend-overlay"
        >
          <filter id="noiseTurbulence">
            <feTurbulence type="fractalNoise" baseFrequency="0.75" numOctaves="3" stitchTiles="stitch" />
          </filter>
          <rect width="100%" height="100%" filter="url(#noiseTurbulence)" />
        </svg>

        {/* Layer 11: High-end border vignette shadow to seal depth boundaries */}
        <div
          id="bezel-shadow-vignette"
          className="absolute inset-0 pointer-events-none rounded-2xl shadow-[inset_0_0_60px_rgba(0,0,0,0.95)] z-20"
        />

        {/* Layer 12: Premium Editorial Typography on the bottom-left */}
        <motion.div
          id="hero-left-centered-typography"
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
          className="absolute left-8 sm:left-12 md:left-16 lg:left-24 bottom-12 sm:bottom-16 md:bottom-20 lg:bottom-24 z-30 flex flex-col items-start text-left select-all pointer-events-auto"
        >
          {/* Small Heading */}
          <span className="font-sans text-xs sm:text-sm font-semibold tracking-[0.3em] text-white/50 uppercase leading-none">
            I'M
          </span>

          {/* Main Headline with typing effect */}
          <div className="flex flex-col items-start relative mt-4">
            <h1 className="font-sans text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-[0.22em] text-white uppercase leading-none z-20">
              ROOZZERO
            </h1>
            
            <div className="flex items-center gap-1.5 mt-3 min-h-[20px]">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-mono text-xs sm:text-sm font-bold tracking-wider text-emerald-400 uppercase">
                {currentText}
              </span>
              <span className="font-mono text-white animate-pulse">|</span>
            </div>
          </div>
        </motion.div>
      </div>
      </section>

      {/* WHO'S ME SECTION */}
      <section
        id="who-s-me"
        className="w-full max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 py-10 sm:py-14 md:py-18 relative text-white scroll-mt-24"
      >
        {/* Subtle decorative background ambient glow */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[300px] pointer-events-none blur-[150px] bg-gradient-to-tr from-white/[0.01] to-white/[0.03] rounded-full z-0" />

        {/* Top Header Row: Badge & Statement & CTA (Unified Header) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start mb-12 md:mb-16 relative z-10 w-full">
          
          {/* Badge Column (Left) */}
          <div className="lg:col-span-3 flex items-center">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-white/10 bg-white/[0.03] backdrop-blur-md shadow-sm">
              <Sparkles size={11} className="text-white/80 animate-pulse" />
              <span className="font-sans text-[10px] font-semibold tracking-[0.2em] text-white/80 uppercase">
                About Me
              </span>
            </div>
          </div>

          {/* Title & Subtitle Column (Right) */}
          <div className="lg:col-span-9 space-y-4">
            <h2 className="font-sans text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-white leading-none">
              Who's Me
            </h2>
            <p className="font-sans text-base sm:text-lg text-white/60 leading-relaxed max-w-3xl">
              Think like a hacker. Build like a developer. Create like a designer.
            </p>
            
            {/* Elegant Action Buttons: CV & GitHub */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <motion.a
                href="#"
                className="inline-flex items-center justify-center w-12 h-12 rounded-full border border-white/15 bg-white/5 backdrop-blur-md text-white hover:bg-white hover:text-black hover:border-white hover:shadow-[0_0_25px_rgba(255,255,255,0.12)] active:scale-[0.98] transition-all duration-300 font-sans"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: 0.1 }}
              >
                <FileDown size={16} className="transition-transform duration-300 group-hover:translate-y-[-1px]" />
              </motion.a>
              <motion.a
                href="https://github.com/roozzero"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center w-12 h-12 rounded-full border border-white/15 bg-white/5 backdrop-blur-md text-white hover:bg-white hover:text-black hover:border-white hover:shadow-[0_0_25px_rgba(255,255,255,0.12)] active:scale-[0.98] transition-all duration-300 font-sans"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
              >
                <Github size={16} />
              </motion.a>
            </div>
          </div>
        </div>

        {/* Bottom Body Row: Image & Cards Grid wrapped in our specified container */}
        <div className="w-full p-6 sm:p-8 md:p-10 rounded-3xl border border-white/10 bg-white/[0.02] backdrop-blur-md shadow-2xl relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
          
          {/* Left Side: Large Portrait Image (3:4 aspect) */}
          <div className="lg:col-span-5 relative group">
            <div className="absolute -inset-1 rounded-2xl bg-gradient-to-tr from-white/10 to-transparent opacity-20 group-hover:opacity-40 blur-md transition duration-1000"></div>
            <div className="relative h-full min-h-[380px] sm:min-h-[480px] lg:min-h-0 overflow-hidden rounded-2xl border border-white/10 bg-neutral-900 shadow-2xl">
              <img
                src="/src/assets/images/002.png"
                alt="ROOZZERO Bio Portrait"
                className="w-full h-full object-cover contrast-[1.05] brightness-[0.9] saturate-[0.85] transition-transform duration-700 ease-out group-hover:scale-[1.03]"
              />
              {/* Cinematic lighting vignette */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent pointer-events-none" />
              <div className="absolute inset-0 bg-radial-gradient(circle at 50% 30%, transparent 20%, rgba(0,0,0,0.4) 100%) pointer-events-none" />
            </div>
          </div>

          {/* Right Side: Bento Grid of Stats Cards */}
          <div className="lg:col-span-7 grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
            
            {/* Card 1: Years Crafting */}
            <div className="rounded-2xl border border-white/[0.05] bg-gradient-to-b from-white/[0.03] to-transparent p-6 sm:p-8 flex items-center justify-between shadow-xl hover:border-white/10 hover:bg-white/[0.04] transition-all duration-300 group">
              <div className="space-y-1">
                <p className="font-sans text-[10px] font-semibold tracking-[0.15em] text-white/50 uppercase leading-relaxed">
                  Years Crafting
                </p>
                <p className="font-sans text-[10px] font-semibold tracking-[0.15em] text-white/50 uppercase leading-relaxed">
                  Digital Products
                </p>
              </div>
              <span className="font-sans text-4xl sm:text-5xl lg:text-6xl font-light tracking-tighter text-white/90 group-hover:text-white transition-colors duration-300">
                5+
              </span>
            </div>

            {/* Card 2: Client Partnerships */}
            <div className="rounded-2xl border border-white/[0.05] bg-gradient-to-b from-white/[0.03] to-transparent p-6 sm:p-8 flex items-center justify-between shadow-xl hover:border-white/10 hover:bg-white/[0.04] transition-all duration-300 group">
              <div className="space-y-1">
                <p className="font-sans text-[10px] font-semibold tracking-[0.15em] text-white/50 uppercase leading-relaxed">
                  Successful Client
                </p>
                <p className="font-sans text-[10px] font-semibold tracking-[0.15em] text-white/50 uppercase leading-relaxed">
                  Partnerships
                </p>
              </div>
              <span className="font-sans text-4xl sm:text-5xl lg:text-6xl font-light tracking-tighter text-white/90 group-hover:text-white transition-colors duration-300">
                20+
              </span>
            </div>

            {/* Card 3: Client Satisfaction Score */}
            <div className="rounded-2xl border border-white/[0.05] bg-gradient-to-b from-white/[0.03] to-transparent p-6 sm:p-8 flex flex-col justify-between min-h-[220px] shadow-xl hover:border-white/10 hover:bg-white/[0.04] transition-all duration-300 group">
              <div className="space-y-1.5">
                <p className="font-sans text-3xl sm:text-4xl font-semibold tracking-tight text-white group-hover:text-white transition-colors duration-300">
                  120+
                </p>
                <p className="font-sans text-[9px] font-semibold tracking-[0.15em] text-white/40 uppercase">
                  Client Satisfaction Score
                </p>
              </div>
              
              <div className="flex items-center justify-between mt-6">
                {/* 4.8 Rating Pill */}
                <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-amber-400/10 bg-amber-400/5 text-amber-400 font-sans text-xs font-semibold">
                  <Star size={11} fill="currentColor" />
                  <span>4.8</span>
                </div>
                
                {/* Customer Avatars overlapping list with smooth scale, hover animation, and smooth scroll */}
                <div className="flex -space-x-2.5">
                  {[
                    { id: "liloch", src: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80&fit=crop&q=80" },
                    { id: "will", src: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&fit=crop&q=80" },
                    { id: "diane", src: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&fit=crop&q=80" },
                    { id: "ikta", src: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&fit=crop&q=80" }
                  ].map((avatar) => (
                    <motion.button
                      key={avatar.id}
                      whileHover={{ scale: 1.15, zIndex: 30 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={(e) => {
                        e.preventDefault();
                        const element = document.getElementById(`testimonial-${avatar.id}`);
                        if (element) {
                          const navbarHeight = 84;
                          const elementPosition = element.getBoundingClientRect().top;
                          const offsetPosition = elementPosition + window.scrollY - navbarHeight;
                          window.scrollTo({ top: offsetPosition, behavior: "smooth" });
                        }
                      }}
                      className="relative block h-8 w-8 rounded-full ring-2 ring-black overflow-hidden bg-neutral-900 shadow-lg hover:shadow-[0_0_12px_rgba(255,255,255,0.4)] transition-all duration-300 cursor-pointer focus:outline-none"
                    >
                      <img
                        className="w-full h-full object-cover"
                        src={avatar.src}
                        alt="Client Portrait"
                      />
                    </motion.button>
                  ))}
                </div>
              </div>
            </div>

            {/* Card 4: Strategic Thinking & Clean Execution with Diagonal Stamp */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              whileHover={{ y: -6, scale: 1.02, borderColor: "rgba(255,255,255,0.15)" }}
              transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
              className="hidden md:flex rounded-2xl border border-white/[0.05] bg-gradient-to-b from-white/[0.03] to-transparent p-6 sm:p-8 flex-col justify-between min-h-[140px] sm:min-h-[220px] relative overflow-hidden shadow-xl hover:bg-white/[0.04] transition-colors duration-300 group"
            >
              
              <p className="hidden sm:block font-sans text-lg sm:text-xl font-medium tracking-tight text-white/90 leading-snug max-w-[85%]">
                Uncompromising Security meets High-Fidelity Design.
              </p>
              
              {/* Tag pills stacked/aligned */}
              <div className="flex flex-col gap-1.5 items-start mt-2 sm:mt-6 z-10">
                <span className="font-sans text-[9px] font-semibold tracking-[0.12em] text-white/60 bg-white/5 border border-white/10 rounded-md px-2.5 py-1 uppercase transition-colors duration-300 group-hover:text-white/80 group-hover:border-white/20">
                  Interface Design
                </span>
                <span className="font-sans text-[9px] font-semibold tracking-[0.12em] text-white/60 bg-white/5 border border-white/10 rounded-md px-2.5 py-1 uppercase transition-colors duration-300 group-hover:text-white/80 group-hover:border-white/20">
                  Product Strategy
                </span>
                <span className="font-sans text-[9px] font-semibold tracking-[0.12em] text-white/60 bg-white/5 border border-white/10 rounded-md px-2.5 py-1 uppercase transition-colors duration-300 group-hover:text-white/80 group-hover:border-white/20">
                  No code development
                </span>
              </div>
              
              {/* Diagonal Branding Stamp rotated dynamically */}
              <div className="absolute right-[-15px] bottom-[25px] rotate-[-12deg] z-0 transition-transform duration-500 group-hover:rotate-[-8deg] group-hover:scale-105">
                <span className="font-sans text-[9px] font-bold tracking-[0.25em] text-black bg-white border border-white/10 rounded px-4 py-2 uppercase shadow-2xl select-none">
                  Branding
                </span>
              </div>
            </motion.div>

          </div>
        </div>
        </div>
      </section>

      {/* SKILLS SECTION */}
      <section
        id="skills"
        className="w-full max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 py-10 sm:py-14 md:py-18 relative text-white scroll-mt-24"
      >
        {/* Subtle decorative background ambient glows */}
        <div className="absolute top-1/3 right-1/4 w-[500px] h-[250px] pointer-events-none blur-[140px] bg-gradient-to-tl from-white/[0.015] to-white/[0.03] rounded-full z-0" />
        <div className="absolute bottom-1/4 left-10 w-[300px] h-[300px] pointer-events-none blur-[120px] bg-white/[0.01] rounded-full z-0" />

        {/* Header Block (Unified Header) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start mb-12 md:mb-16 relative z-10 w-full">
          {/* Badge Column (Left) */}
          <div className="lg:col-span-3 flex items-center">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-white/10 bg-white/[0.03] backdrop-blur-md shadow-sm">
              <Sparkles size={11} className="text-white/80 animate-pulse" />
              <span className="font-sans text-[10px] font-semibold tracking-[0.2em] text-white/80 uppercase">
                MY SKILLS
              </span>
            </div>
          </div>

          {/* Title & Subtitle Column (Right) */}
          <div className="lg:col-span-9 space-y-4">
            <h2 className="font-sans text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-white leading-none">
              My Skills
            </h2>
            <p className="font-sans text-base sm:text-lg text-white/60 leading-relaxed max-w-3xl">
              The stack behind every project I build
            </p>
          </div>
        </div>

        {/* Bento Grid layout wrapped inside the container */}
        <div className="w-full p-6 sm:p-8 md:p-10 rounded-3xl border border-white/10 bg-white/[0.02] backdrop-blur-md shadow-2xl relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 items-stretch">
          
          {/* LEFT COLUMN: 2 Skill Items */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            
            {/* REACT: Large Elegant Card */}
            <motion.div
              whileHover={{ y: -5, scale: 1.01 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              className="relative h-[228px] w-full rounded-2xl border border-white/[0.05] bg-gradient-to-b from-white/[0.03] to-transparent flex flex-col justify-between p-8 shadow-xl group overflow-hidden"
            >
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(6,182,212,0.04)_0%,transparent_70%)] pointer-events-none transition-opacity duration-500 group-hover:opacity-100" />
              
              <div className="relative z-10 transform transition-transform duration-500 group-hover:scale-[1.02]">
                <svg width="60" height="60" viewBox="-11.5 -10.23174 23 20.46348" fill="none" xmlns="http://www.w3.org/2000/svg" className="filter drop-shadow-[0_4px_12px_rgba(6,182,212,0.25)]">
                  <circle cx="0" cy="0" r="2.05" fill="#00d8ff"/>
                  <g stroke="#00d8ff" strokeWidth="1" fill="none">
                    <ellipse rx="11" ry="4.2"/>
                    <ellipse rx="11" ry="4.2" transform="rotate(60)"/>
                    <ellipse rx="11" ry="4.2" transform="rotate(120)"/>
                  </g>
                </svg>
              </div>

              <div className="relative z-10">
                <h4 className="font-sans text-base font-semibold tracking-wide text-white">React</h4>
                <p className="font-sans text-[11px] text-white/40 mt-1 uppercase tracking-[0.1em]">Interactive UIs & Component Architectures</p>
              </div>
            </motion.div>

            {/* NEXT.JS: Large Elegant Card */}
            <motion.div
              whileHover={{ y: -5, scale: 1.01 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              className="relative h-[228px] w-full rounded-2xl border border-white/[0.05] bg-gradient-to-b from-white/[0.03] to-transparent flex flex-col justify-between p-8 shadow-xl group overflow-hidden"
            >
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.04)_0%,transparent_70%)] pointer-events-none transition-opacity duration-500 group-hover:opacity-100" />
              
              <div className="relative z-10 transform transition-transform duration-500 group-hover:scale-[1.02] flex items-center justify-center bg-zinc-950/40 border border-white/5 w-14 h-14 rounded-xl">
                <svg width="36" height="36" viewBox="0 0 180 180" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <mask id="mask_next" maskUnits="userSpaceOnUse" x="0" y="0" width="180" height="180">
                    <circle cx="90" cy="90" r="90" fill="black" />
                  </mask>
                  <g mask="url(#mask_next)">
                    <circle cx="90" cy="90" r="90" fill="black" />
                    <path d="M149.508 157.52L69.142 54H54V126H68.303V74.4552L138.318 162.776C142.33 161.218 146.082 159.452 149.508 157.52Z" fill="url(#paint0_linear)" />
                    <path d="M115 54H129V126H115V54Z" fill="url(#paint1_linear)" />
                  </g>
                  <defs>
                    <linearGradient id="paint0_linear" x1="109" y1="116.5" x2="144.5" y2="160.5" gradientUnits="userSpaceOnUse">
                      <stop stopColor="white" />
                      <stop offset="1" stopColor="white" stopOpacity="0" />
                    </linearGradient>
                    <linearGradient id="paint1_linear" x1="121" y1="54" x2="121" y2="126" gradientUnits="userSpaceOnUse">
                      <stop stopColor="white" />
                      <stop offset="1" stopColor="white" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                </svg>
              </div>

              <div className="relative z-10">
                <h4 className="font-sans text-base font-semibold tracking-wide text-white">Next.js</h4>
                <p className="font-sans text-[11px] text-white/40 mt-1 uppercase tracking-[0.1em]">Full-Stack Framework & Server-Side Rendering</p>
              </div>
            </motion.div>

          </div>

          {/* RIGHT COLUMN: 6 Skill Items */}
          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-6">
            
            {/* Node.js */}
            <motion.div
              whileHover={{ y: -4, scale: 1.01 }}
              className="h-[144px] rounded-2xl border border-white/[0.05] bg-gradient-to-b from-white/[0.02] to-transparent p-6 flex flex-col justify-between shadow-lg relative overflow-hidden group"
            >
              <div className="absolute inset-0 bg-emerald-500/[0.01] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              
              <div className="h-10 w-10 rounded-xl bg-white/[0.02] border border-white/5 flex items-center justify-center">
                <svg width="24" height="24" viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg" className="transform transition-transform duration-300 group-hover:scale-105">
                  <path d="M128 0L24 60v120l104 60 104-60V60L128 0zm78 163.5l-78 45-78-45V85.5l78-45 78 45v78z" fill="#339933"/>
                </svg>
              </div>
              
              <div>
                <h5 className="font-sans text-sm font-semibold text-white/90">Node.js</h5>
                <p className="font-sans text-[10px] text-white/40 uppercase tracking-[0.05em] mt-0.5">Scalable Server Runtimes</p>
              </div>
            </motion.div>

            {/* OWASP */}
            <motion.div
              whileHover={{ y: -4, scale: 1.01 }}
              className="h-[144px] rounded-2xl border border-red-500/[0.05] bg-gradient-to-b from-red-500/[0.02] to-transparent p-6 flex flex-col justify-between shadow-lg relative overflow-hidden group"
            >
              <div className="absolute inset-0 bg-red-500/[0.01] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              
              <div className="h-10 w-10 rounded-xl bg-white/[0.02] border border-white/5 flex items-center justify-center">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-red-400 transform transition-transform duration-300 group-hover:scale-105">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                  <path d="M12 8v4" />
                  <path d="M12 16h.01" />
                </svg>
              </div>
              
              <div>
                <h5 className="font-sans text-sm font-semibold text-white/90">OWASP</h5>
                <p className="font-sans text-[10px] text-white/40 uppercase tracking-[0.05em] mt-0.5">Secure Application Practices</p>
              </div>
            </motion.div>

            {/* JavaScript */}
            <motion.div
              whileHover={{ y: -4, scale: 1.01 }}
              className="h-[144px] rounded-2xl border border-yellow-500/[0.05] bg-gradient-to-b from-yellow-500/[0.02] to-transparent p-6 flex flex-col justify-between shadow-lg relative overflow-hidden group"
            >
              <div className="absolute inset-0 bg-yellow-500/[0.01] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              
              <div className="h-10 w-10 rounded-xl bg-white/[0.02] border border-white/5 flex items-center justify-center">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="transform transition-transform duration-300 group-hover:scale-105">
                  <rect width="24" height="24" rx="4" fill="#F7DF1E" />
                  <text x="14" y="20" fill="black" fontFamily="sans-serif" fontSize="11" fontWeight="bold">JS</text>
                </svg>
              </div>
              
              <div>
                <h5 className="font-sans text-sm font-semibold text-white/90">JavaScript</h5>
                <p className="font-sans text-[10px] text-white/40 uppercase tracking-[0.05em] mt-0.5">Dynamic Scripting Engine</p>
              </div>
            </motion.div>

            {/* Tailwind CSS */}
            <motion.div
              whileHover={{ y: -4, scale: 1.01 }}
              className="h-[144px] rounded-2xl border border-cyan-500/[0.05] bg-gradient-to-b from-cyan-500/[0.02] to-transparent p-6 flex flex-col justify-between shadow-lg relative overflow-hidden group"
            >
              <div className="absolute inset-0 bg-cyan-500/[0.01] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              
              <div className="h-10 w-10 rounded-xl bg-white/[0.02] border border-white/5 flex items-center justify-center">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="transform transition-transform duration-300 group-hover:scale-105">
                  <path d="M12 6.095c-1.334 0-2.333.667-3 2 1.333-2 2.667-2.333 4-1 .762.762 1.543 1.543 2.5 2.5 1.556 1.555 3.321 2.333 5.3 2.333 1.333 0 2.333-.667 3-2-1.333 2-2.667 2.333-4 1-.762-.762-1.543-1.543-2.5-2.5-1.556-1.556-3.321-2.333-5.3-2.333zm-6 6c-1.334 0-2.333.667-3 2 1.333-2 2.667-2.333 4-1 .762.762 1.543 1.543 2.5 2.5 1.556 1.555 3.321 2.333 5.3 2.333 1.333 0 2.333-.667 3-2-1.333 2-2.667 2.333-4 1-.762-.762-1.543-1.543-2.5-2.5-1.556-1.556-3.321-2.333-5.3-2.333z" fill="#38BDF8"/>
                </svg>
              </div>
              
              <div>
                <h5 className="font-sans text-sm font-semibold text-white/90">Tailwind CSS</h5>
                <p className="font-sans text-[10px] text-white/40 uppercase tracking-[0.05em] mt-0.5">Utility-First Styling</p>
              </div>
            </motion.div>

            {/* TypeScript */}
            <motion.div
              whileHover={{ y: -4, scale: 1.01 }}
              className="h-[144px] rounded-2xl border border-blue-500/[0.05] bg-gradient-to-b from-blue-500/[0.02] to-transparent p-6 flex flex-col justify-between shadow-lg relative overflow-hidden group"
            >
              <div className="absolute inset-0 bg-blue-500/[0.01] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              
              <div className="h-10 w-10 rounded-xl bg-white/[0.02] border border-white/5 flex items-center justify-center">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="transform transition-transform duration-300 group-hover:scale-105">
                  <rect width="24" height="24" rx="4" fill="#3178C6" />
                  <text x="14" y="20" fill="white" fontFamily="sans-serif" fontSize="11" fontWeight="bold">TS</text>
                </svg>
              </div>
              
              <div>
                <h5 className="font-sans text-sm font-semibold text-white/90">TypeScript</h5>
                <p className="font-sans text-[10px] text-white/40 uppercase tracking-[0.05em] mt-0.5">Static Type Systems</p>
              </div>
            </motion.div>

            {/* Hunting */}
            <motion.div
              whileHover={{ y: -4, scale: 1.01 }}
              className="h-[144px] rounded-2xl border border-white/[0.05] bg-gradient-to-b from-white/[0.02] to-transparent p-6 flex flex-col justify-between shadow-lg relative overflow-hidden group"
            >
              <div className="absolute inset-0 bg-white/[0.01] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              
              <div className="h-10 w-10 rounded-xl bg-white/[0.02] border border-white/5 flex items-center justify-center">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-white transform transition-transform duration-300 group-hover:scale-105">
                  <circle cx="12" cy="12" r="10" />
                  <path d="M22 12h-4" />
                  <path d="M6 12H2" />
                  <path d="M12 6V2" />
                  <path d="M12 22v-4" />
                </svg>
              </div>
              
              <div>
                <h5 className="font-sans text-sm font-semibold text-white/90">Hunting</h5>
                <p className="font-sans text-[10px] text-white/40 uppercase tracking-[0.05em] mt-0.5">Active Threat Investigation</p>
              </div>
            </motion.div>

          </div>

        </div>
        </div>
      </section>

      {/* PROJECTS SECTION */}
      <section
        id="projects"
        className="w-full max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 py-10 sm:py-14 md:py-18 relative text-white scroll-mt-24 border-t border-white/[0.04] overflow-hidden"
      >
        {/* Subtle decorative background ambient glow */}
        <div className="absolute top-1/3 left-1/4 -translate-x-1/2 w-[500px] h-[300px] pointer-events-none blur-[150px] bg-gradient-to-tr from-[#FF1A6B]/[0.01] to-[#FF1A6B]/[0.04] rounded-full z-0" />
        <div className="absolute bottom-1/4 right-1/4 translate-x-1/2 w-[400px] h-[250px] pointer-events-none blur-[120px] bg-gradient-to-tr from-cyan-500/[0.01] to-[#FF3366]/[0.03] rounded-full z-0" />

        {/* Header Block (Unified Header) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start mb-12 md:mb-16 relative z-10 w-full">
          {/* Badge Column (Left) */}
          <div className="lg:col-span-3 flex items-center">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-white/10 bg-white/[0.03] backdrop-blur-md shadow-sm">
              <Sparkles size={11} className="text-white/80 animate-pulse" />
              <span className="font-sans text-[10px] font-semibold tracking-[0.2em] text-white/80 uppercase">
                MY PROJECTS
              </span>
            </div>
          </div>

          {/* Title & Subtitle Column (Right) */}
          <div className="lg:col-span-9 flex flex-col md:flex-row justify-between items-start md:items-end gap-6 w-full">
            <div className="space-y-4">
              <h2 className="font-sans text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-white leading-none">
                Main Works
              </h2>
              <p className="font-sans text-base sm:text-lg text-white/60 leading-relaxed max-w-3xl">
                What I'm proud of: A selection of featured engineering and design projects.
              </p>
            </div>
            
            {/* Elegant Screen Switcher Tabs */}
            <div className="hidden sm:flex flex-wrap gap-1.5 p-1 bg-white/[0.02] border border-white/[0.05] rounded-xl self-start md:self-auto shrink-0">
              {[
                { id: 1, label: "Date & Time" },
                { id: 2, label: "In Cinema" },
                { id: 3, label: "Details" },
                { id: 4, label: "Seat Selection" }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveScreen(tab.id)}
                  className={`px-3.5 py-1.5 rounded-lg text-[10px] font-sans tracking-widest transition-all duration-300 uppercase ${
                    activeScreen === tab.id
                      ? "bg-[#FF1A6B] text-white shadow-[0_4px_12px_rgba(255,26,107,0.3)] font-bold"
                      : "text-white/40 hover:text-white/80 hover:bg-white/[0.01]"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Projects Content wrapped in our specified container */}
        <div className="w-full p-6 sm:p-8 md:p-10 rounded-3xl border border-white/10 bg-white/[0.02] backdrop-blur-md shadow-2xl relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">

          {/* LEFT COLUMN: Voo's Cinema Brand description & metrics */}
          <div className="lg:col-span-4 space-y-8 lg:sticky lg:top-28">
            <div className="flex items-center gap-1.5 select-none">
              <span className="font-sans text-2xl font-black tracking-tight text-white uppercase">V</span>
              {/* Logo 'o' 1 */}
              <div className="w-5 h-5 rounded-full bg-[#FF1A6B] flex items-center justify-center shadow-md shadow-[#FF1A6B]/20">
                <div className="w-2.5 h-2.5 rounded-full bg-white flex items-center justify-center">
                  <div className="w-0 h-0 border-t-[2.2px] border-t-transparent border-b-[2.2px] border-b-transparent border-l-[4px] border-l-[#FF1A6B] ml-[0.5px]" />
                </div>
              </div>
              {/* Logo 'o' 2 */}
              <div className="w-5 h-5 rounded-full bg-[#FF1A6B] flex items-center justify-center shadow-md shadow-[#FF1A6B]/20">
                <div className="w-2.5 h-2.5 rounded-full bg-white flex items-center justify-center">
                  <div className="w-0 h-0 border-t-[2.2px] border-t-transparent border-b-[2.2px] border-b-transparent border-l-[4px] border-l-[#FF1A6B] ml-[0.5px]" />
                </div>
              </div>
              <span className="font-sans text-2xl font-black tracking-tight text-white uppercase">'s Cinema</span>
            </div>

            <div className="space-y-4">
              <h3 className="font-sans text-2xl sm:text-3xl font-semibold tracking-tight text-white/95">
                Voo's Cinema
              </h3>
              <p className="font-sans text-sm sm:text-base text-white/50 leading-relaxed">
                Ultimate american mobile ticketing app for a seamless movie experience at offline cinemas. All in one place.
              </p>
            </div>

            <div className="border-t border-dashed border-white/10 pt-6">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="font-sans text-[10px] text-white/30 uppercase tracking-widest mb-1">Region</p>
                  <p className="font-sans text-sm font-semibold text-white/90">USA</p>
                </div>
                <div>
                  <p className="font-sans text-[10px] text-white/30 uppercase tracking-widest mb-1">Framework</p>
                  <p className="font-sans text-sm font-semibold text-white/90">React</p>
                </div>
                <div>
                  <p className="font-sans text-[10px] text-white/30 uppercase tracking-widest mb-1">Release Year</p>
                  <p className="font-sans text-sm font-semibold text-white/90">2025</p>
                </div>
              </div>
            </div>

            <div className="pt-2">
              <motion.button
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
                className="inline-flex items-center gap-2 px-4 py-2 font-sans text-[10px] font-medium tracking-[0.18em] uppercase transition-all duration-300 rounded-lg border border-white/10 bg-white/[0.02] text-white/80 hover:text-white hover:bg-white/[0.06] hover:border-white/20 shadow-md group"
              >
                <span>View Demo</span>
                <ArrowRight size={12} className="text-[#FF1A6B] transition-transform duration-300 group-hover:translate-x-1" />
              </motion.button>
            </div>
          </div>

          {/* RIGHT COLUMN: Interactive Mobile Mockup Stack */}
          <div className="lg:col-span-8 w-full flex flex-col items-center">
            
            {/* The 3D Mockup Arena */}
            <div className="relative w-full max-w-[650px] h-[520px] sm:h-[550px] flex items-center justify-center overflow-visible select-none mt-4 md:mt-8">
              
              {/* SCREEN 1: Date & Time Picker */}
              <motion.div
                animate={{
                  x: activeScreen === 1 ? 0 : activeScreen === 2 ? -150 : activeScreen === 3 ? -260 : -330,
                  y: activeScreen === 1 ? 0 : activeScreen === 2 ? 10 : activeScreen === 3 ? 20 : 30,
                  scale: activeScreen === 1 ? 1.03 : activeScreen === 2 ? 0.91 : activeScreen === 3 ? 0.85 : 0.80,
                  rotate: activeScreen === 1 ? 0 : activeScreen === 2 ? -3 : activeScreen === 3 ? -6 : -9,
                  opacity: activeScreen === 1 ? 1 : activeScreen === 2 ? 0.85 : activeScreen === 3 ? 0.55 : 0.25,
                  zIndex: activeScreen === 1 ? 30 : activeScreen === 2 ? 20 : activeScreen === 3 ? 10 : 0,
                }}
                transition={{ type: "spring", stiffness: 100, damping: 18 }}
                onClick={() => setActiveScreen(1)}
                className="absolute w-[240px] h-[480px] rounded-[32px] border border-white/[0.08] bg-[#09090C] p-2.5 shadow-[0_20px_50px_rgba(0,0,0,0.8)] cursor-pointer select-none overflow-hidden"
              >
                {/* Phone Notch/Island */}
                <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-20 h-4 bg-black rounded-full z-40 border border-white/5 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-white/10 ml-auto mr-3" />
                </div>

                {/* Screen Content Wrapper */}
                <div className="w-full h-full rounded-[24px] bg-black overflow-hidden flex flex-col p-3 pt-5 relative">
                  
                  {/* Status Bar */}
                  <div className="flex justify-between items-center text-[9px] text-white/50 px-1 mb-2">
                    <span>9:41</span>
                    <div className="flex items-center gap-1">
                      <span className="w-2.5 h-1.5 border border-white/30 rounded-[2px] flex items-center p-[0.5px]">
                        <span className="w-full h-full bg-white/60 rounded-[1px]" />
                      </span>
                    </div>
                  </div>

                  {/* Navigation Bar inside App */}
                  <div className="flex justify-between items-center border-b border-white/[0.05] pb-2 mb-3">
                    <div className="flex items-center gap-1.5">
                      <div className="w-4 h-4 rounded-full bg-[#FF1A6B] flex items-center justify-center scale-90">
                        <div className="w-2 h-2 rounded-full bg-white flex items-center justify-center">
                          <div className="w-0 h-0 border-t-[1.5px] border-t-transparent border-b-[1.5px] border-b-transparent border-l-[2.5px] border-l-[#FF1A6B] ml-[0.3px]" />
                        </div>
                      </div>
                      <div className="flex items-center text-[9px] text-white/80 font-medium">
                        <MapPin size={8} className="text-[#FF1A6B] mr-0.5" />
                        <span className="truncate max-w-[85px]">San Francisco</span>
                      </div>
                    </div>
                    {/* Burger Menu inside Mockup */}
                    <div className="flex flex-col gap-0.5 w-3.5 items-end cursor-pointer">
                      <span className="w-full h-[1px] bg-white/60" />
                      <span className="w-2/3 h-[1px] bg-white/60" />
                      <span className="w-full h-[1px] bg-white/60" />
                    </div>
                  </div>

                  {/* Title and Reset */}
                  <div className="flex justify-between items-center mb-3">
                    <h4 className="text-[11px] font-bold text-white tracking-wide uppercase">Date & Time</h4>
                    <button 
                      onClick={(e) => { e.stopPropagation(); setSelectedDate(5); }}
                      className="text-[9px] text-white/40 hover:text-white/80 cursor-pointer flex items-center gap-0.5"
                    >
                      Reset <X size={7} />
                    </button>
                  </div>

                  {/* Timeline Slider Mock */}
                  <div className="bg-white/[0.02] border border-white/[0.04] p-2 rounded-xl mb-3">
                    <div className="flex justify-between text-[8px] text-white/30 mb-1">
                      <span>9AM</span>
                      <span className="text-[#FF1A6B] font-medium">12:30 PM</span>
                      <span>11PM</span>
                    </div>
                    <div className="relative w-full h-1 bg-white/10 rounded-full my-1.5">
                      <div className="absolute left-0 right-[40%] h-full bg-[#FF1A6B]" />
                      <div className="absolute left-[60%] -translate-y-1/2 w-2 h-2 rounded-full bg-white shadow-md border border-[#FF1A6B] top-1/2 cursor-pointer" />
                    </div>
                  </div>

                  {/* Month Header */}
                  <div className="flex justify-between items-center mb-2 px-1">
                    <span className="text-[10px] font-bold text-white/90">July 2024</span>
                    <div className="flex items-center gap-1">
                      <ChevronLeft size={10} className="text-white/40 cursor-pointer" />
                      <ChevronRight size={10} className="text-white/40 cursor-pointer" />
                    </div>
                  </div>

                  {/* Calendar Weekdays */}
                  <div className="grid grid-cols-7 gap-1 text-center text-[7px] text-white/30 font-bold mb-1">
                    <span>SUN</span>
                    <span>MON</span>
                    <span>TUE</span>
                    <span>WED</span>
                    <span>THU</span>
                    <span>FRI</span>
                    <span>SAT</span>
                  </div>

                  {/* Calendar Days */}
                  <div className="grid grid-cols-7 gap-1 text-center text-[8px] flex-1">
                    {/* Days placeholder to start on correct day (Monday) */}
                    <span />
                    {Array.from({ length: 31 }).map((_, i) => {
                      const dayNum = i + 1;
                      const isSelected = selectedDate === dayNum;
                      return (
                        <button
                          key={dayNum}
                          onClick={(e) => { e.stopPropagation(); setSelectedDate(dayNum); }}
                          className={`w-5 h-5 mx-auto rounded-full flex items-center justify-center transition-all ${
                            isSelected
                              ? "bg-[#FF1A6B] text-white font-bold shadow-[0_0_8px_rgba(255,26,107,0.5)] scale-110"
                              : "text-white/70 hover:bg-white/5 hover:text-white"
                          }`}
                        >
                          {dayNum}
                        </button>
                      );
                    })}
                  </div>

                  {/* Bottom Action Footer */}
                  <div className="flex items-center gap-2 mt-auto pt-2 border-t border-white/[0.05]">
                    <button className="w-6 h-6 rounded-lg bg-white/[0.04] border border-white/5 flex items-center justify-center text-white/60 hover:bg-white/10 cursor-pointer">
                      <X size={10} />
                    </button>
                    <button 
                      onClick={(e) => { e.stopPropagation(); setActiveScreen(2); }}
                      className="flex-1 h-6 rounded-lg bg-[#FF1A6B] text-white text-[9px] font-bold tracking-wider uppercase flex items-center justify-center shadow-lg hover:shadow-[#FF1A6B]/20 cursor-pointer"
                    >
                      Filter results
                    </button>
                  </div>

                </div>
              </motion.div>


              {/* SCREEN 2: "In Cinema" Main centerpiece */}
              <motion.div
                animate={{
                  x: activeScreen === 2 ? 0 : activeScreen === 1 ? 150 : activeScreen === 3 ? -150 : -250,
                  y: activeScreen === 2 ? 0 : activeScreen === 1 ? 10 : activeScreen === 3 ? 10 : 20,
                  scale: activeScreen === 2 ? 1.05 : activeScreen === 1 ? 0.91 : activeScreen === 3 ? 0.91 : 0.85,
                  rotate: activeScreen === 2 ? 0 : activeScreen === 1 ? 3 : activeScreen === 3 ? -3 : -6,
                  opacity: activeScreen === 2 ? 1 : activeScreen === 1 ? 0.85 : activeScreen === 3 ? 0.85 : 0.55,
                  zIndex: activeScreen === 2 ? 30 : activeScreen === 1 ? 20 : activeScreen === 3 ? 20 : 10,
                }}
                transition={{ type: "spring", stiffness: 100, damping: 18 }}
                onClick={() => setActiveScreen(2)}
                className="absolute w-[240px] h-[480px] rounded-[32px] border border-white/[0.12] bg-[#0A0A0E] p-2.5 shadow-[0_25px_60px_rgba(0,0,0,0.85)] cursor-pointer select-none overflow-hidden group/device"
              >
                {/* Interactive glow border matching the current preset/branding */}
                <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/[0.03] via-transparent to-[#FF1A6B]/[0.05] opacity-50 group-hover/device:opacity-100 transition-opacity duration-700 pointer-events-none" />

                {/* Phone Notch/Island */}
                <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-20 h-4 bg-black rounded-full z-40 border border-white/5 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-white/10 ml-auto mr-3" />
                </div>

                {/* Screen Content */}
                <div className="w-full h-full rounded-[24px] bg-black overflow-hidden flex flex-col p-3 pt-5 relative">
                  
                  {/* Status Bar */}
                  <div className="flex justify-between items-center text-[9px] text-white/50 px-1 mb-2">
                    <span>9:41</span>
                    <div className="flex items-center gap-1">
                      <span className="w-2.5 h-1.5 border border-white/30 rounded-[2px] flex items-center p-[0.5px]">
                        <span className="w-full h-full bg-white/60 rounded-[1px]" />
                      </span>
                    </div>
                  </div>

                  {/* Navigation Bar inside App */}
                  <div className="flex justify-between items-center border-b border-white/[0.05] pb-2 mb-3">
                    <div className="flex items-center gap-1.5">
                      <div className="w-4 h-4 rounded-full bg-[#FF1A6B] flex items-center justify-center scale-90">
                        <div className="w-2 h-2 rounded-full bg-white flex items-center justify-center">
                          <div className="w-0 h-0 border-t-[1.5px] border-t-transparent border-b-[1.5px] border-b-transparent border-l-[2.5px] border-l-[#FF1A6B] ml-[0.3px]" />
                        </div>
                      </div>
                      <div className="flex items-center text-[9px] text-white/80 font-medium">
                        <MapPin size={8} className="text-[#FF1A6B] mr-0.5" />
                        <span className="truncate max-w-[85px]">San Francisco</span>
                      </div>
                    </div>
                    <div className="flex flex-col gap-0.5 w-3.5 items-end">
                      <span className="w-full h-[1px] bg-white/60" />
                      <span className="w-2/3 h-[1px] bg-white/60" />
                      <span className="w-full h-[1px] bg-white/60" />
                    </div>
                  </div>

                  {/* Heading Tabs */}
                  <div className="flex items-baseline gap-2 mb-2.5">
                    <h4 className="text-[12px] font-black text-white tracking-wide">In cinema</h4>
                    <span className="text-[9px] font-medium text-white/40">Soon</span>
                  </div>

                  {/* Movie Poster Card (After Earth) */}
                  <div className="relative flex-1 rounded-2xl overflow-hidden border border-white/[0.06] bg-gradient-to-b from-[#090C16] to-[#020204] flex flex-col items-center justify-between p-3.5 shadow-inner">
                    {/* Poster design - starry space nebula */}
                    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,102,255,0.18)_0%,transparent_60%)] pointer-events-none" />
                    <div className="absolute bottom-1/4 w-[120px] h-[120px] rounded-full bg-[#FF1A6B]/[0.03] blur-[25px] pointer-events-none" />
                    
                    {/* Tagline */}
                    <div className="text-center mt-2 relative z-10">
                      <p className="text-[5.5px] text-white/40 uppercase tracking-[0.2em] font-sans">1000 YEARS AGO</p>
                      <p className="text-[5.5px] text-white/40 uppercase tracking-[0.2em] font-sans">WE LEFT FOR A REASON</p>
                    </div>

                    {/* Title Block */}
                    <div className="text-center my-4 relative z-10 w-full">
                      <p className="text-[5px] text-white/30 uppercase tracking-widest font-sans mb-1">JADEN SMITH  •  WILL SMITH</p>
                      <h3 className="text-[16px] font-black tracking-[0.22em] text-white uppercase font-sans drop-shadow-[0_0_10px_rgba(255,255,255,0.35)] leading-none my-1">
                        AFTER
                      </h3>
                      <h3 className="text-[16px] font-black tracking-[0.22em] text-white uppercase font-sans drop-shadow-[0_0_10px_rgba(255,255,255,0.35)] leading-none mb-1">
                        EARTH
                      </h3>
                      <p className="text-[5px] text-[#FF1A6B]/70 uppercase tracking-widest font-bold">SUMMER 2013</p>
                    </div>

                    {/* Poster Bottom Card Label */}
                    <div className="w-full bg-black/40 backdrop-blur-md border border-white/[0.04] p-1.5 rounded-xl flex justify-between items-center relative z-10">
                      <div className="text-left">
                        <p className="text-[8px] font-bold text-white leading-tight">After Earth</p>
                        <p className="text-[6.5px] text-white/40">Ends: 15 Oct</p>
                      </div>
                      <div className="flex gap-1">
                        <span className="text-[5.5px] font-bold tracking-wide text-white/70 bg-white/[0.08] px-1 py-0.5 rounded border border-white/[0.04]">IMAX</span>
                        <span className="text-[5.5px] font-bold tracking-wide text-white/70 bg-[#FF1A6B]/10 border border-[#FF1A6B]/20 px-1 py-0.5 rounded">CINETECH</span>
                      </div>
                    </div>
                  </div>

                  {/* Bottom Dock Menu Bar */}
                  <div className="flex justify-around items-center pt-2.5 mt-2.5 border-t border-white/[0.05] text-white/30 text-[10px]">
                    <CompassIcon size={12} className="text-[#FF1A6B] cursor-pointer" />
                    <CalendarIcon size={11} className="hover:text-white/80 cursor-pointer" onClick={(e) => { e.stopPropagation(); setActiveScreen(1); }} />
                    <User size={11} className="hover:text-white/80 cursor-pointer" />
                  </div>

                </div>
              </motion.div>


              {/* SCREEN 3: Movie Details View */}
              <motion.div
                animate={{
                  x: activeScreen === 3 ? 0 : activeScreen === 1 ? 250 : activeScreen === 2 ? 150 : -150,
                  y: activeScreen === 3 ? 0 : activeScreen === 1 ? 20 : activeScreen === 2 ? 10 : 10,
                  scale: activeScreen === 3 ? 1.03 : activeScreen === 1 ? 0.85 : activeScreen === 2 ? 0.91 : 0.91,
                  rotate: activeScreen === 3 ? 0 : activeScreen === 1 ? 6 : activeScreen === 2 ? 3 : -3,
                  opacity: activeScreen === 3 ? 1 : activeScreen === 1 ? 0.55 : activeScreen === 2 ? 0.85 : 0.85,
                  zIndex: activeScreen === 3 ? 30 : activeScreen === 1 ? 10 : activeScreen === 2 ? 20 : 20,
                }}
                transition={{ type: "spring", stiffness: 100, damping: 18 }}
                onClick={() => setActiveScreen(3)}
                className="absolute w-[240px] h-[480px] rounded-[32px] border border-white/[0.08] bg-[#09090C] p-2.5 shadow-[0_20px_50px_rgba(0,0,0,0.8)] cursor-pointer select-none overflow-hidden"
              >
                {/* Phone Notch/Island */}
                <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-20 h-4 bg-black rounded-full z-40 border border-white/5 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-white/10 ml-auto mr-3" />
                </div>

                {/* Screen Content */}
                <div className="w-full h-full rounded-[24px] bg-black overflow-hidden flex flex-col p-3 pt-5 relative">
                  
                  {/* Status Bar */}
                  <div className="flex justify-between items-center text-[9px] text-white/50 px-1 mb-2">
                    <span>9:41</span>
                    <div className="flex items-center gap-1">
                      <span className="w-2.5 h-1.5 border border-white/30 rounded-[2px] flex items-center p-[0.5px]">
                        <span className="w-full h-full bg-white/60 rounded-[1px]" />
                      </span>
                    </div>
                  </div>

                  {/* Navigation Bar inside App */}
                  <div className="flex justify-between items-center border-b border-white/[0.05] pb-2 mb-3">
                    <div className="flex items-center gap-1.5">
                      <div className="w-4 h-4 rounded-full bg-[#FF1A6B] flex items-center justify-center scale-90">
                        <div className="w-2 h-2 rounded-full bg-white flex items-center justify-center">
                          <div className="w-0 h-0 border-t-[1.5px] border-t-transparent border-b-[1.5px] border-b-transparent border-l-[2.5px] border-l-[#FF1A6B] ml-[0.3px]" />
                        </div>
                      </div>
                      <div className="flex items-center text-[9px] text-white/80 font-medium">
                        <MapPin size={8} className="text-[#FF1A6B] mr-0.5" />
                        <span className="truncate max-w-[85px]">San Francisco</span>
                      </div>
                    </div>
                    <div className="flex flex-col gap-0.5 w-3.5 items-end">
                      <span className="w-full h-[1px] bg-white/60" />
                      <span className="w-2/3 h-[1px] bg-white/60" />
                      <span className="w-full h-[1px] bg-white/60" />
                    </div>
                  </div>

                  {/* Header Row */}
                  <div className="mb-2">
                    <h4 className="text-[11px] font-bold text-white tracking-wide truncate">Movie Longname</h4>
                    <p className="text-[7px] text-white/40 uppercase">Ends: 09 Sep</p>
                  </div>

                  {/* Hero Movie Scene Card with custom SVG play */}
                  <div className="relative h-[90px] w-full rounded-xl overflow-hidden bg-gradient-to-tr from-[#14151B] via-[#2A1821] to-[#0A0B0E] border border-white/5 flex items-center justify-center mb-2.5 group/play shadow-inner">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,26,107,0.14),transparent_70%)] pointer-events-none" />
                    <div className="relative z-10 w-8 h-8 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center shadow-lg">
                      <svg width="8" height="10" viewBox="0 0 10 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="ml-[1px]">
                        <path d="M1 1.5L8.5 6L1 10.5V1.5Z" fill="white" />
                      </svg>
                    </div>
                    <div className="absolute bottom-1.5 left-2 text-[6px] text-white/30 tracking-wider">TRAILER PLAYBACK</div>
                  </div>

                  {/* Movie Meta Statistics row */}
                  <div className="grid grid-cols-4 gap-1 text-center bg-white/[0.02] border border-white/[0.04] p-1.5 rounded-lg mb-2.5 text-[7.5px]">
                    <div>
                      <p className="text-white/30">Country</p>
                      <p className="text-white font-bold">USA</p>
                    </div>
                    <div>
                      <p className="text-white/30">Year</p>
                      <p className="text-white font-bold">2024</p>
                    </div>
                    <div>
                      <p className="text-white/30">Duration</p>
                      <p className="text-white font-bold">98m</p>
                    </div>
                    <div>
                      <p className="text-[#FF1A6B] font-bold flex items-center justify-center gap-0.5">
                        <Star size={6} fill="#FF1A6B" /> 8.2
                      </p>
                      <p className="text-white/30">IMDb</p>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-[8px] text-white/50 leading-relaxed mb-3 line-clamp-3">
                    Many years after the reign of Caesar, a young ape goes on a journey that will lead him to question everything he's been taught about...
                  </p>

                  {/* Showtime Selection */}
                  <div className="space-y-2 mb-3">
                    {/* Today row */}
                    <div className="flex items-center gap-1.5">
                      <span className="text-[7.5px] text-white/40 uppercase w-7">Today:</span>
                      <div className="flex gap-1 flex-1">
                        {["9:30", "13:00", "17:30"].map((time) => {
                          const isSelected = selectedShowtime === time;
                          return (
                            <button
                              key={time}
                              onClick={(e) => { e.stopPropagation(); setSelectedShowtime(time); }}
                              className={`flex-1 text-[7.5px] py-1 rounded-md text-center border transition-all ${
                                isSelected
                                  ? "bg-[#FF1A6B]/15 border-[#FF1A6B] text-[#FF1A6B] font-bold"
                                  : "border-white/5 bg-white/[0.02] text-white/60 hover:border-white/20"
                              }`}
                            >
                              {time}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Tomorrow row */}
                    <div className="flex items-center gap-1.5">
                      <span className="text-[7.5px] text-white/40 uppercase w-7">Tomorrow:</span>
                      <div className="flex gap-1 flex-1">
                        {["11:30", "16:00", "20:30"].map((time) => {
                          const isSelected = selectedShowtime === time;
                          return (
                            <button
                              key={time}
                              onClick={(e) => { e.stopPropagation(); setSelectedShowtime(time); }}
                              className={`flex-1 text-[7.5px] py-1 rounded-md text-center border transition-all ${
                                isSelected
                                  ? "bg-[#FF1A6B]/15 border-[#FF1A6B] text-[#FF1A6B] font-bold"
                                  : "border-white/5 bg-white/[0.02] text-white/60 hover:border-white/20"
                              }`}
                            >
                              {time}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-[6.5px] text-white/30">Wed, 25 Oct</span>
                    </div>
                  </div>

                  {/* Bottom Action Footer */}
                  <div className="flex items-center gap-2 mt-auto pt-2 border-t border-white/[0.05]">
                    <button className="w-6 h-6 rounded-lg bg-white/[0.04] border border-white/5 flex items-center justify-center text-white/60 hover:bg-white/10">
                      <X size={10} />
                    </button>
                    <button 
                      onClick={(e) => { e.stopPropagation(); setActiveScreen(4); }}
                      className="flex-1 h-6 rounded-lg bg-[#FF1A6B] text-white text-[9px] font-bold tracking-wider uppercase flex items-center justify-center shadow-lg hover:shadow-[#FF1A6B]/20 cursor-pointer"
                    >
                      Select show
                    </button>
                  </div>

                </div>
              </motion.div>


              {/* SCREEN 4: Seating Selection (Interactive Arena) */}
              <motion.div
                animate={{
                  x: activeScreen === 4 ? 0 : activeScreen === 1 ? 330 : activeScreen === 2 ? 260 : activeScreen === 3 ? 150 : 0,
                  y: activeScreen === 4 ? 0 : activeScreen === 1 ? 30 : activeScreen === 2 ? 20 : activeScreen === 3 ? 10 : 0,
                  scale: activeScreen === 4 ? 1.03 : activeScreen === 1 ? 0.80 : activeScreen === 2 ? 0.85 : activeScreen === 3 ? 0.91 : 0.91,
                  rotate: activeScreen === 4 ? 0 : activeScreen === 1 ? 9 : activeScreen === 2 ? 6 : activeScreen === 3 ? 3 : -3,
                  opacity: activeScreen === 4 ? 1 : activeScreen === 1 ? 0.25 : activeScreen === 2 ? 0.55 : activeScreen === 3 ? 0.85 : 0.85,
                  zIndex: activeScreen === 4 ? 30 : activeScreen === 1 ? 0 : activeScreen === 2 ? 10 : activeScreen === 3 ? 20 : 20,
                }}
                transition={{ type: "spring", stiffness: 100, damping: 18 }}
                onClick={() => setActiveScreen(4)}
                className="absolute w-[240px] h-[480px] rounded-[32px] border border-white/[0.08] bg-[#09090C] p-2.5 shadow-[0_20px_50px_rgba(0,0,0,0.8)] cursor-pointer select-none overflow-hidden"
              >
                {/* Phone Notch/Island */}
                <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-20 h-4 bg-black rounded-full z-40 border border-white/5 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-white/10 ml-auto mr-3" />
                </div>

                {/* Screen Content */}
                <div className="w-full h-full rounded-[24px] bg-black overflow-hidden flex flex-col p-3 pt-5 relative">
                  
                  {/* Status Bar */}
                  <div className="flex justify-between items-center text-[9px] text-white/50 px-1 mb-2">
                    <span>9:41</span>
                    <div className="flex items-center gap-1">
                      <span className="w-2.5 h-1.5 border border-white/30 rounded-[2px] flex items-center p-[0.5px]">
                        <span className="w-full h-full bg-white/60 rounded-[1px]" />
                      </span>
                    </div>
                  </div>

                  {/* Navigation Bar inside App */}
                  <div className="flex justify-between items-center border-b border-white/[0.05] pb-2 mb-3">
                    <div className="flex items-center gap-1.5">
                      <div className="w-4 h-4 rounded-full bg-[#FF1A6B] flex items-center justify-center scale-90">
                        <div className="w-2 h-2 rounded-full bg-white flex items-center justify-center">
                          <div className="w-0 h-0 border-t-[1.5px] border-t-transparent border-b-[1.5px] border-b-transparent border-l-[2.5px] border-l-[#FF1A6B] ml-[0.3px]" />
                        </div>
                      </div>
                      <div className="flex items-center text-[9px] text-white/80 font-medium">
                        <MapPin size={8} className="text-[#FF1A6B] mr-0.5" />
                        <span className="truncate max-w-[85px]">San Francisco</span>
                      </div>
                    </div>
                    <div className="flex flex-col gap-0.5 w-3.5 items-end">
                      <span className="w-full h-[1px] bg-white/60" />
                      <span className="w-2/3 h-[1px] bg-white/60" />
                      <span className="w-full h-[1px] bg-white/60" />
                    </div>
                  </div>

                  {/* Title & Date */}
                  <div className="mb-2">
                    <h4 className="text-[11px] font-bold text-white tracking-wide truncate">Movie Longname</h4>
                    <p className="text-[6.5px] text-[#FF1A6B] font-semibold">Today: Wed, September 29</p>
                  </div>

                  {/* Main Seating Layout Grid (with real interactive toggle buttons) */}
                  <div className="flex flex-col items-center flex-1 py-1">
                    
                    {/* Simulated Curved Cinema Screen */}
                    <div className="w-4/5 h-2.5 border-t-[1.5px] border-[#FF1A6B]/30 rounded-[50%] flex items-center justify-center relative mb-4">
                      <div className="absolute top-0 w-3/4 h-[4px] bg-gradient-to-b from-[#FF1A6B]/15 to-transparent blur-[1px]" />
                      <span className="text-[5px] text-[#FF1A6B]/40 uppercase tracking-widest font-black absolute top-1.5 scale-90">SCREEN</span>
                    </div>

                    {/* Grid rows A-E, Cols 1-8 */}
                    <div className="space-y-[3.5px] mb-3 w-full max-w-[190px]">
                      {["A", "B", "C", "D", "E"].map((rowLabel) => {
                        return (
                          <div key={rowLabel} className="flex items-center justify-center gap-[3px]">
                            <span className="text-[6px] text-white/20 w-2 font-bold text-right mr-1">{rowLabel}</span>
                            {Array.from({ length: 8 }).map((_, colIndex) => {
                              const seatId = `${rowLabel}${colIndex + 1}`;
                              // Fixed hardcoded booked list
                              const isBooked = ["A3", "A4", "B2", "B6", "D4", "D5", "E1", "E8"].includes(seatId);
                              const isSelected = selectedSeats.includes(seatId);

                              const handleSeatClick = (e: React.MouseEvent) => {
                                e.stopPropagation();
                                if (isBooked) return;
                                if (isSelected) {
                                  setSelectedSeats((prev) => prev.filter((id) => id !== seatId));
                                } else {
                                  setSelectedSeats((prev) => [...prev, seatId]);
                                }
                              };

                              return (
                                <button
                                  key={seatId}
                                  onClick={handleSeatClick}
                                  disabled={isBooked}
                                  className={`w-[15px] h-[13px] rounded-[3px] text-[4.5px] flex items-center justify-center transition-all ${
                                    isBooked
                                      ? "bg-white/[0.04] text-white/5 border border-white/5 cursor-not-allowed"
                                      : isSelected
                                      ? "bg-[#FF1A6B] border border-[#FF1A6B] text-white font-bold shadow-[0_0_6px_rgba(255,26,107,0.5)] scale-105"
                                      : "border border-white/15 bg-white/[0.02] text-white/40 hover:border-white/40 cursor-pointer"
                                  }`}
                                  title={seatId}
                                >
                                  {colIndex + 1}
                                </button>
                              );
                            })}
                            <span className="text-[6px] text-white/20 w-2 font-bold text-left ml-1">{rowLabel}</span>
                          </div>
                        );
                      })}
                    </div>

                    {/* Legend indicators */}
                    <div className="flex justify-center gap-3 text-[6.5px] text-white/40 mb-3 border-t border-b border-white/[0.03] py-1.5 w-full">
                      <div className="flex items-center gap-1">
                        <span className="w-2 h-2 rounded-[2px] border border-white/15 bg-white/[0.02]" />
                        <span>Available</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="w-2 h-2 rounded-[2px] bg-white/[0.04] border border-white/5" />
                        <span>Booked</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="w-2 h-2 rounded-[2px] bg-[#FF1A6B]" />
                        <span>Selected</span>
                      </div>
                    </div>

                    {/* Dyn Ticket Count details */}
                    <div className="text-center">
                      <p className="text-[7.5px] font-medium text-white/70">
                        {selectedSeats.length > 0 ? (
                          <>
                            <span className="text-[#FF1A6B] font-bold">{selectedSeats.length}</span> tickets selected • <span className="text-white font-bold">${(selectedSeats.length * 12.5).toFixed(2)}</span>
                          </>
                        ) : (
                          "Select your theater seats"
                        )}
                      </p>
                    </div>

                  </div>

                  {/* Bottom Action Footer */}
                  <div className="flex items-center gap-2 mt-auto pt-2 border-t border-white/[0.05]">
                    <button 
                      onClick={(e) => { e.stopPropagation(); setSelectedSeats([]); }}
                      className="w-6 h-6 rounded-lg bg-white/[0.04] border border-white/5 flex items-center justify-center text-white/60 hover:bg-white/10 cursor-pointer"
                    >
                      <X size={10} />
                    </button>
                    <button 
                      onClick={(e) => { e.stopPropagation(); }}
                      disabled={selectedSeats.length === 0}
                      className={`flex-1 h-6 rounded-lg text-white text-[9px] font-bold tracking-wider uppercase flex items-center justify-center shadow-lg transition-all ${
                        selectedSeats.length === 0
                          ? "bg-white/[0.03] text-white/30 border border-white/5 cursor-not-allowed shadow-none"
                          : "bg-[#FF1A6B] hover:shadow-[#FF1A6B]/20 cursor-pointer"
                      }`}
                    >
                      Confirm Seats
                    </button>
                  </div>

                </div>
              </motion.div>

            </div>

            {/* Carousel Navigation dots for Mobile viewports */}
            <div className="flex gap-2.5 mt-8 lg:hidden">
              {[1, 2, 3, 4].map((id) => (
                <button
                  key={id}
                  onClick={() => setActiveScreen(id)}
                  className={`w-2.5 h-2.5 rounded-full transition-all ${
                    activeScreen === id ? "bg-[#FF1A6B] w-6" : "bg-white/20 hover:bg-white/40"
                  }`}
                  aria-label={`Go to screen mockup ${id}`}
                />
              ))}
            </div>

          </div>

        </div>
        </div>
      </section>

      {/* CLASSES SECTION */}
      <section
        id="classes"
        className="w-full max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 py-10 sm:py-14 md:py-18 relative text-white scroll-mt-24 border-t border-white/[0.04] overflow-hidden"
      >
        {/* Decorative background glows */}
        <div className="absolute top-1/4 right-1/4 translate-x-1/2 w-[450px] h-[300px] pointer-events-none blur-[150px] bg-gradient-to-tr from-[#10b981]/[0.02] to-[#10b981]/[0.04] rounded-full z-0" />
        <div className="absolute bottom-1/3 left-1/3 -translate-x-1/2 w-[350px] h-[220px] pointer-events-none blur-[120px] bg-gradient-to-tr from-[#FF1A6B]/[0.01] to-cyan-500/[0.02] rounded-full z-0" />

        {/* Header Block (Unified Header) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start mb-12 md:mb-16 relative z-10 w-full">
          {/* Badge Column (Left) */}
          <div className="lg:col-span-3 flex items-center">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-white/10 bg-white/[0.03] backdrop-blur-md shadow-sm">
              <Sparkles size={11} className="text-white/80 animate-pulse" />
              <span className="font-sans text-[10px] font-semibold tracking-[0.2em] text-white/80 uppercase">
                Academy
              </span>
            </div>
          </div>

          {/* Title & Subtitle Column (Right) */}
          <div className="lg:col-span-9 space-y-4">
            <h2 className="font-sans text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-white leading-none">
              Latest Classes
            </h2>
            <p className="font-sans text-base sm:text-lg text-white/60 leading-relaxed max-w-3xl">
              Explore our dynamic curriculum, interactive resources, and live lecture schedules.
            </p>
          </div>
        </div>

        {/* Classes Content wrapped in our specified container */}
        <div className="w-full p-6 sm:p-8 md:p-10 rounded-3xl border border-white/10 bg-white/[0.02] backdrop-blur-md shadow-2xl relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">

            {homepageClasses
              .filter((cls) => cls.status === "Published")
              .map((cls) => {
                const syllabusItems = cls.syllabus || [];
                const tagsList = Array.isArray(cls.tags) ? cls.tags : [];
                const isOpen = !!openSyllabus[cls.id];

                return (
                  <div
                    key={cls.id}
                    className="flex flex-col bg-zinc-950/40 border border-white/[0.04] rounded-3xl p-5 lg:p-6 hover:border-white/[0.08] transition-all duration-500 hover:shadow-[0_20px_50px_rgba(0,0,0,0.5)] group h-full justify-between"
                  >
                    <div>
                      {/* Premium Course Header Info */}
                      <div className="flex justify-between items-center mb-4">
                        <div className="flex items-center gap-2">
                          <span className="flex h-2 w-2 rounded-full bg-[#10b981] animate-pulse" />
                          <span className="text-[10px] tracking-widest text-[#10b981] uppercase font-bold">
                            {cls.id === "techzo" ? "LIVE Masterclass" : cls.id === "lumin" ? "Featured Class" : "Special Class"}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-white/40 uppercase tracking-widest">Price:</span>
                          <span className="text-sm font-black text-white px-2.5 py-0.5 bg-white/[0.05] border border-white/10 rounded-full flex items-center gap-1">
                            <span className="text-[#10b981] font-bold text-xs">$</span>
                            {cls.price ? cls.price.replace("$", "") : "199"}
                          </span>
                        </div>
                      </div>

                      {/* Course visual template mockup area */}
                      {cls.id === "techzo" ? (
                        <div className="relative aspect-[16/10] w-full rounded-2xl bg-[#08080c] border border-white/[0.06] overflow-hidden p-4 flex flex-col justify-between shadow-inner mb-5 shrink-0">
                          {/* Techzo Background stars & grid */}
                          <div className="absolute inset-0 bg-[radial-gradient(#ffffff03_1px,transparent_1px)] [background-size:16px_16px] opacity-70 pointer-events-none" />
                          <div className="absolute top-0 right-0 w-[180px] h-[180px] rounded-full bg-[#FF1A6B]/[0.02] blur-[40px] pointer-events-none" />

                          {/* Techzo Inner Top bar */}
                          <div className="flex justify-between items-center text-[7px] text-white/30 tracking-widest relative z-10 border-b border-white/[0.03] pb-2">
                            <span>LIGHT VERSION AVAILABLE</span>
                            <div className="flex items-center gap-2">
                              <span>MENU</span>
                              <span className="w-2.5 h-[1.5px] bg-white/40" />
                            </div>
                          </div>

                          {/* Techzo Center Stage */}
                          <div className="my-auto text-center relative z-10 py-2">
                            {/* Glowing floating wireframe sphere */}
                            <div className="relative w-16 h-16 mx-auto mb-2 flex items-center justify-center">
                              <div className="absolute inset-0 rounded-full border border-[#FF1A6B]/20 animate-[spin_8s_linear_infinite] [border-style:dashed]" />
                              <div className="absolute w-12 h-12 rounded-full border border-cyan-500/30 animate-[spin_12s_linear_infinite]" />
                              <div className="absolute w-8 h-8 rounded-full bg-gradient-to-tr from-[#FF1A6B]/20 via-transparent to-cyan-500/20 blur-[6px]" />
                              <div className="w-5 h-5 rounded-full border-[1.5px] border-white/40 flex items-center justify-center">
                                <div className="w-2 h-2 rounded-full bg-[#FF1A6B]/80" />
                              </div>
                            </div>

                            <h3 className="font-sans text-xl sm:text-2xl font-black tracking-[0.2em] text-white uppercase leading-none drop-shadow-[0_0_15px_rgba(255,255,255,0.15)]">
                              TECHZO
                            </h3>
                            <p className="text-[6px] tracking-[0.4em] text-white/40 uppercase mt-1 font-mono">CREATIVE STUDIO</p>
                          </div>

                          {/* Techzo Bottom cards overlay */}
                          <div className="flex justify-between items-end gap-2 relative z-10">
                            {/* Left overlay: About Techzo with placeholder avatar */}
                            <div className="bg-white/[0.02] border border-white/[0.05] p-1.5 rounded-lg text-left max-w-[45%]">
                              <p className="text-[5px] text-white/30 uppercase tracking-widest">ABOUT TECHZO</p>
                              <p className="text-[6.5px] text-white/70 font-semibold mt-0.5 truncate">Innovative Design</p>
                              <div className="flex items-center gap-1 mt-1">
                                <div className="w-3.5 h-3.5 rounded-full bg-zinc-800 border border-white/10 flex items-center justify-center">
                                  <User size={8} className="text-white/40" />
                                </div>
                                <span className="text-[4.5px] text-white/40">Est. 2024</span>
                              </div>
                            </div>

                            {/* Right overlay: Services list */}
                            <div className="bg-white/[0.02] border border-white/[0.05] p-1.5 rounded-lg text-left max-w-[48%]">
                              <p className="text-[5px] text-[#10b981] font-bold tracking-widest uppercase">TOP-NOTCH SERVICES</p>
                              <div className="space-y-[2px] mt-1 text-[4.5px] text-white/50">
                                <p className="flex items-center gap-0.5"><span className="text-[#10b981]">•</span> BRANDING & IDENTITY</p>
                                <p className="flex items-center gap-0.5"><span className="text-[#10b981]">•</span> MOBILE & WEB UX</p>
                                <p className="flex items-center gap-0.5"><span className="text-[#10b981]">•</span> FULL-STACK DEPLOYMENT</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      ) : cls.id === "lumin" ? (
                        <div className="relative aspect-[16/10] w-full rounded-2xl bg-gradient-to-tr from-cyan-950/20 via-[#0a0a10] to-[#040406] border border-white/[0.06] overflow-hidden p-4 flex items-center justify-center shadow-inner mb-5 shrink-0">
                          {/* Beautiful blue nebula radial backdrop */}
                          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(6,182,212,0.12)_0%,transparent_60%)] pointer-events-none" />
                          <div className="absolute -bottom-10 w-[220px] h-[100px] rounded-full bg-cyan-500/[0.05] blur-[40px] pointer-events-none" />

                          {/* MacBook Air Device Wrapper */}
                          <div className="w-[85%] max-w-[340px] relative z-10 flex flex-col items-center">
                            
                            {/* Laptop Display frame */}
                            <div className="w-full aspect-[16/10] bg-[#0d0d14] rounded-t-lg border-t border-l border-r border-white/20 p-1 shadow-2xl relative overflow-hidden flex flex-col justify-between">
                              
                              {/* Screen reflection effect */}
                              <div className="absolute inset-0 bg-gradient-to-tr from-white/[0.01] via-white/[0.05] to-transparent pointer-events-none" />
                              
                              {/* In-Screen navigation header */}
                              <div className="flex justify-between items-center text-[5px] text-white/30 tracking-widest border-b border-white/[0.03] pb-1 w-full">
                                <span className="font-bold text-[6px] text-white/80">Lumin Studio.</span>
                                <div className="flex items-center gap-1 text-[4px] text-white/40">
                                  <span>HOME</span>
                                  <span>ABOUT</span>
                                  <span>WORK</span>
                                  <span>SERVICES</span>
                                  <span>CONTACT</span>
                                </div>
                              </div>

                              {/* Inside Screen Center */}
                              <div className="my-auto text-center relative py-1 flex flex-col items-center">
                                <h4 className="font-sans text-[15px] font-black tracking-tight text-white leading-none">
                                  LUMIN STUDIO
                                </h4>
                                {/* Reflection of heading */}
                                <h4 className="font-sans text-[15px] font-black tracking-tight text-white/5 leading-none select-none scale-y-[-0.3] translate-y-[-1px] blur-[0.5px]">
                                  LUMIN STUDIO
                                </h4>
                                
                                <p className="text-[3.5px] text-white/40 max-w-[70%] mt-1 leading-relaxed">
                                  Lumin Studio is a dynamic agency committed to outstanding experiences.
                                </p>
                              </div>

                              {/* Display bottom bezel */}
                              <div className="w-full bg-black flex justify-center items-center py-0.5 mt-auto border-t border-white/[0.04]">
                                <span className="text-[3px] font-medium text-white/30 tracking-wider">Macbook Air</span>
                              </div>

                            </div>

                            {/* Keyboard chassis base */}
                            <div className="w-[110%] h-2 bg-gradient-to-b from-[#1c1c28] to-[#0a0a0f] rounded-b-md border-t border-white/30 shadow-lg relative flex justify-center">
                              {/* Screen trackpad notch */}
                              <div className="w-8 h-[1px] bg-black/40" />
                            </div>

                            {/* Mobile mockup glowing on the side */}
                            <div className="absolute right-0 bottom-3 w-[50px] aspect-[1/2] rounded-lg border border-white/15 bg-black p-[2px] shadow-[0_10px_20px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col">
                              <div className="w-full h-full rounded-[6px] bg-gradient-to-tr from-cyan-900 to-[#FF1A6B]/20 p-1 flex flex-col justify-between">
                                <div className="text-[3px] text-white/30">PRO 15</div>
                                <div className="text-[4px] font-black text-white text-center">LUMIN</div>
                                <div className="text-[3px] text-white/20 mt-auto text-right">Mockup</div>
                              </div>
                            </div>

                          </div>
                        </div>
                      ) : (
                        /* GORGEOUS DYNAMIC BANNER VIEW FOR NEW CUSTOM COURSES */
                        <div className="relative aspect-[16/10] w-full rounded-2xl border border-white/[0.06] overflow-hidden shadow-inner mb-5 shrink-0 bg-zinc-900 flex items-center justify-center group/custom">
                          <img
                            src={cls.courseImage}
                            className="absolute inset-0 h-full w-full object-cover group-hover/custom:scale-105 transition-transform duration-700 ease-out"
                            alt=""
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-black/10" />
                          
                          {/* Top Tag & Stats Overlay */}
                          <div className="absolute top-3 left-3 right-3 flex justify-between items-center">
                            <span className="px-2.5 py-0.5 bg-black/60 border border-white/10 text-white/90 rounded-full font-mono text-[9px] tracking-wide font-black uppercase">
                              {cls.sessions || 12} Sessions
                            </span>
                            <span className="px-2 py-0.5 bg-indigo-600/90 text-white rounded-md text-[8px] font-bold tracking-widest uppercase">
                              Mastery
                            </span>
                          </div>

                          {/* Instructor name overlay */}
                          <div className="absolute bottom-3 left-3 flex items-center gap-1.5">
                            <div className="w-5 h-5 rounded-full bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center">
                              <User size={10} className="text-white/70" />
                            </div>
                            <span className="text-[9px] text-white/80 font-black tracking-wide uppercase">Instructor: {cls.instructor || "Roozbeh"}</span>
                          </div>
                        </div>
                      )}

                      {/* Title & Description */}
                      <div className="space-y-2 text-left mb-6">
                        <h3 className="font-sans text-xl sm:text-2xl font-bold tracking-tight text-white group-hover:text-[#10b981] transition-colors duration-300">
                          {cls.courseName}
                        </h3>
                        <p className="font-sans text-sm text-white/50 leading-relaxed min-h-[48px] text-justify">
                          {cls.description}
                        </p>
                      </div>

                      {/* Tech Badges / Tags */}
                      <div className="flex flex-wrap gap-2 mb-6 border-b border-white/[0.04] pb-5">
                        {tagsList.slice(0, 3).map((tag: string) => (
                          <span
                            key={tag}
                            className="px-3 py-1 rounded-full bg-emerald-500/[0.03] border border-emerald-500/20 text-emerald-400 font-mono text-[10px] tracking-wide"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* EXPANDABLE SYLLABUS SECTION */}
                    <div className="bg-white/[0.01] border border-white/[0.03] rounded-2xl overflow-hidden transition-all duration-300">
                      <button
                        onClick={() => setOpenSyllabus((prev) => ({ ...prev, [cls.id]: !prev[cls.id] }))}
                        className="w-full flex items-center justify-between p-4 text-left text-sm font-semibold hover:bg-white/[0.02] transition-colors"
                      >
                        <div className="flex items-center gap-1.5 xs:gap-2 sm:gap-2.5 text-white/80 min-w-0 flex-nowrap">
                          <BookOpen size={15} className="text-[#10b981] shrink-0" />
                          <span className="tracking-wide text-[10px] xs:text-xs sm:text-sm whitespace-nowrap truncate">Explore Course Syllabus</span>
                          <span className="text-[8px] xs:text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 xs:px-2 py-0.5 rounded-full font-bold uppercase shrink-0 whitespace-nowrap">
                            {syllabusItems.length} Modules
                          </span>
                        </div>
                        {isOpen ? (
                          <ChevronUp size={16} className="text-white/60 shrink-0" />
                        ) : (
                          <ChevronDown size={16} className="text-white/60 shrink-0" />
                        )}
                      </button>

                      <motion.div
                        initial={false}
                        animate={{ height: isOpen ? "auto" : 0 }}
                        transition={{ duration: 0.3, ease: "easeInOut" }}
                        className="overflow-hidden bg-black/20"
                      >
                        <div className="p-4 border-t border-white/[0.03] space-y-4 text-left text-xs text-white/60">
                          
                          {syllabusItems.map((syl: any, sIdx: number) => (
                            <div key={syl.id || sIdx} className={`flex items-start gap-3 ${sIdx > 0 ? "border-t border-white/[0.02] pt-3" : ""}`}>
                              <div className="w-5 h-5 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-[10px] font-bold text-emerald-400 mt-0.5 shrink-0">
                                {sIdx + 1}
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="font-semibold text-white/95 text-[12px] truncate">{syl.title}</p>
                                <p className="text-[11px] text-white/40 mt-0.5 leading-relaxed">{syl.description}</p>
                              </div>
                              <span className="text-[10px] font-mono text-white/30 shrink-0">{syl.duration}</span>
                            </div>
                          ))}

                          {/* CTA Button inside expander */}
                          <div className="pt-3 border-t border-white/[0.02]">
                            <button className="w-full py-2.5 rounded-xl bg-emerald-500 text-black font-sans font-bold text-xs uppercase tracking-widest hover:bg-emerald-400 transition-colors flex items-center justify-center gap-1.5 shadow-[0_4px_15px_rgba(16,185,129,0.25)]">
                              <Award size={13} />
                              Enroll In Course
                            </button>
                          </div>

                        </div>
                      </motion.div>
                    </div>

                  </div>
                );
              })}

          </div>

        </div>
      </section>

      {/* MY STUDENTS SECTION */}
      <StudentsSection 
        isLoggedIn={isLoggedIn} 
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
      />

      {/* CONTACT ME SECTION */}
      <ContactSection />

      {/* FOOTER SECTION */}
      <Footer />

      {/* BACK TO TOP BUTTON */}
      <BackToTop />

      {/* PREMIUM CENTRAL LOGIN MODAL OVERLAY */}
      <LoginModal 
        isOpen={isLoginModalOpen} 
        onClose={() => setIsLoginModalOpen(false)}
        onLoginSuccess={(role) => {
          setIsLoggedIn(true);
          setUserRole(role);
          localStorage.setItem("isLoggedIn", "true");
          localStorage.setItem("userRole", role);
          // Redirect is handled gracefully with loading simulation
          setTimeout(() => {
            setIsLoginModalOpen(false);
            if (role === "admin") {
              window.location.hash = "#admin";
            } else {
              window.location.hash = "#dashboard";
            }
          }, 1500);
        }}
      />
    </div>
  );
}

