import React from "react";
import { motion } from "motion/react";
import { 
  Sparkles, Clock, CheckCircle2, AlertTriangle, ChevronRight, X, Check,
  BookOpen, Users, GraduationCap, Award, MessageSquare, ClipboardList, Megaphone,
  BarChart3, Settings, ShieldCheck, Activity, Bell, FileText, Calendar
} from "lucide-react";
import { AdminUser, CourseRequest, Enrollment } from "./types";
import { Course, Student, Session, Assignment, Certificate } from "../../types/teacher";

interface OverviewTabProps {
  students: Student[];
  sessions: Session[];
  courses: Course[];
  assignments: Assignment[];
  certificates: Certificate[];
  requests: CourseRequest[];
  seasons: any[];
  users: AdminUser[];
  onQuickAction: (tabId: string) => void;
  onApproveRequest: (id: string) => void;
  onRejectRequest: (id: string, notes?: string) => void;
  onApproveCertificate: (id: string) => void;
  onRejectCertificate: (id: string, notes?: string) => void;
  onUpdateSessionStatus: (id: string, status: "Scheduled" | "Completed" | "Cancelled") => void;
}

export default function OverviewTab({
  students,
  sessions,
  courses,
  assignments,
  certificates,
  requests,
  seasons,
  users,
  onQuickAction,
  onApproveRequest,
  onRejectRequest,
  onApproveCertificate,
  onRejectCertificate,
  onUpdateSessionStatus
}: OverviewTabProps) {

  // Filter pending approvals
  const pendingRequests = requests.filter(r => r.status === "Pending");
  const pendingCerts = certificates.filter(c => c.status === "Waiting for Admin Approval" || c.status === "Signed by Instructor");
  const activeSeasons = seasons.filter(s => s.status === "Active");
  const todayDate = "2026-07-02"; // Simulated current date
  const todaySessions = sessions.filter(s => s.date === todayDate);

  // Stats calculation
  const stats = [
    { label: "Total Students", value: students.length, change: "+14% growth", color: "text-emerald-400", bg: "from-emerald-500/10 to-transparent" },
    { label: "Active Courses", value: courses.length, change: "All systems active", color: "text-indigo-400", bg: "from-indigo-500/10 to-transparent" },
    { label: "Pending Requests", value: pendingRequests.length, change: "Requires attention", color: "text-amber-400", bg: "from-amber-500/10 to-transparent" },
    { label: "Active Seasons", value: activeSeasons.length, change: "Ongoing batches", color: "text-cyan-400", bg: "from-cyan-500/10 to-transparent" },
    { label: "Pending Certificates", value: pendingCerts.length, change: "Needs review", color: "text-rose-400", bg: "from-rose-500/10 to-transparent" },
    { label: "Today's Classes", value: todaySessions.length, change: "Live links ready", color: "text-amber-400", bg: "from-amber-500/10 to-transparent" }
  ];

  return (
    <div className="space-y-8">
      {/* 1. Stat cards grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {stats.map((stat, idx) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: idx * 0.05 }}
            className={`p-4 rounded-2xl border border-white/[0.04] bg-gradient-to-br ${stat.bg} space-y-1 relative overflow-hidden group hover:border-white/[0.08] transition-all duration-300`}
          >
            <span className="text-[9px] text-white/40 uppercase tracking-widest font-black block">{stat.label}</span>
            <p className={`text-2xl sm:text-3xl font-black tracking-tight ${stat.color}`}>{stat.value}</p>
            <span className="text-[8px] font-mono text-white/30 block">{stat.change}</span>
          </motion.div>
        ))}
      </div>

      {/* 2. Widgets Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Widget: Today's Schedule (7 cols on lg) */}
        <div className="lg:col-span-7 p-6 rounded-3xl border border-white/[0.06] bg-zinc-950/60 backdrop-blur-md space-y-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Calendar size={15} className="text-indigo-400" />
              <h3 className="text-xs font-black text-white uppercase tracking-wider">Today's Classes & Meetings</h3>
            </div>
            <span className="text-[9px] font-mono text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-2 py-0.5 rounded-full font-bold">
              {todayDate}
            </span>
          </div>

          <div className="space-y-3">
            {todaySessions.length === 0 ? (
              <div className="text-center py-8 text-xs text-white/40">
                No classes scheduled for today.
              </div>
            ) : (
              todaySessions.map((session) => (
                <div 
                  key={session.id} 
                  className="p-4 rounded-2xl border border-white/[0.04] bg-white/[0.01] hover:bg-white/[0.02] transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1 text-left">
                    <p className="text-[10px] font-mono text-white/30 tracking-wider uppercase">{session.courseTitle}</p>
                    <p className="text-xs font-bold text-white leading-tight">{session.title}</p>
                    <div className="flex items-center gap-3 text-[10px] text-white/50">
                      <span className="flex items-center gap-1"><Clock size={11} /> {session.time} ({session.duration})</span>
                      <span className="flex items-center gap-1"><Users size={11} /> {session.studentCount} Students</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase border ${
                      session.status === "Scheduled" 
                        ? "bg-amber-500/10 border-amber-500/20 text-amber-400"
                        : session.status === "Completed"
                        ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                        : "bg-rose-500/10 border-rose-500/20 text-rose-400"
                    }`}>
                      {session.status}
                    </span>

                    {session.status === "Scheduled" && (
                      <div className="flex gap-1">
                        <button 
                          onClick={() => onUpdateSessionStatus(session.id, "Completed")}
                          className="p-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 hover:bg-emerald-500 hover:text-black transition-all"
                          title="Complete Session"
                        >
                          <Check size={11} />
                        </button>
                        <button 
                          onClick={() => onUpdateSessionStatus(session.id, "Cancelled")}
                          className="p-1.5 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400 hover:bg-rose-500 hover:text-black transition-all"
                          title="Cancel Session"
                        >
                          <X size={11} />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Widget: Quick Actions Shortcuts (5 cols on lg) */}
        <div className="lg:col-span-5 p-6 rounded-3xl border border-white/[0.06] bg-zinc-950/60 backdrop-blur-md space-y-4 text-left">
          <div className="flex items-center gap-2">
            <Sparkles size={15} className="text-amber-400" />
            <h3 className="text-xs font-black text-white uppercase tracking-wider">LMS Control Center</h3>
          </div>

          <div className="grid grid-cols-1 gap-2">
            {[
              { label: "Create Announcements", action: () => onQuickAction("announcements"), icon: Megaphone, color: "text-[#10b981]" },
              { label: "Add New Instructor", action: () => onQuickAction("users"), icon: GraduationCap, color: "text-indigo-400" },
              { label: "Create New Course", action: () => onQuickAction("courses"), icon: BookOpen, color: "text-cyan-400" },
              { label: "Review Pending Certificates", action: () => onQuickAction("certificates"), icon: Award, color: "text-rose-400" },
              { label: "View Reports & Performance", action: () => onQuickAction("reports"), icon: BarChart3, color: "text-amber-400" },
              { label: "Audit Security Settings", action: () => onQuickAction("systemSettings"), icon: Settings, color: "text-white/60" }
            ].map((item) => {
              const IconComp = item.icon;
              return (
                <button
                  key={item.label}
                  onClick={item.action}
                  className="p-3 w-full rounded-2xl border border-white/[0.04] bg-white/[0.01] hover:bg-white/[0.03] transition-all text-xs font-bold text-white/90 flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3">
                    <IconComp size={13} className={`${item.color} group-hover:scale-110 transition-transform`} />
                    <span>{item.label}</span>
                  </div>
                  <ChevronRight size={12} className="text-white/30 group-hover:translate-x-0.5 transition-transform" />
                </button>
              );
            })}
          </div>
        </div>

      </div>

      {/* 3. Pending Approvals & Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Pending Approvals unified feed (7 cols on lg) */}
        <div className="lg:col-span-7 p-6 rounded-3xl border border-white/[0.06] bg-zinc-950/60 backdrop-blur-md space-y-4 text-left">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <ShieldCheck size={15} className="text-rose-400" />
              <h3 className="text-xs font-black text-white uppercase tracking-wider">Pending Approvals Feed</h3>
            </div>
            <span className="text-[9px] font-mono text-white/40">
              {pendingRequests.length + pendingCerts.length} waiting
            </span>
          </div>

          <div className="space-y-3">
            {pendingRequests.length === 0 && pendingCerts.length === 0 ? (
              <div className="text-center py-10 text-xs text-white/40">
                All requests cleared! No pending approvals.
              </div>
            ) : (
              <>
                {/* Render Pending Course requests */}
                {pendingRequests.map((req) => (
                  <div 
                    key={req.id} 
                    className="p-4 rounded-2xl border border-white/[0.04] bg-amber-500/[0.01] hover:bg-amber-500/[0.02] border-l-2 border-l-amber-500 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-mono uppercase bg-amber-500/10 text-amber-400 px-1.5 py-0.5 rounded font-bold">{req.type}</span>
                        <span className="text-[8px] font-mono text-white/30">{req.date}</span>
                      </div>
                      <p className="text-xs font-bold text-white leading-tight">{req.title}</p>
                      <p className="text-[10px] text-white/50 leading-relaxed max-w-md">{req.details}</p>
                      <p className="text-[9px] font-bold text-white/40">Requested by: <span className="text-white/70">{req.teacherName}</span></p>
                    </div>

                    <div className="flex items-center gap-1.5 self-end sm:self-auto">
                      <button 
                        onClick={() => onApproveRequest(req.id)}
                        className="px-2.5 py-1 rounded-xl bg-emerald-500 text-black text-[10px] font-bold tracking-wider uppercase hover:bg-emerald-400 transition-all"
                      >
                        Approve
                      </button>
                      <button 
                        onClick={() => onRejectRequest(req.id)}
                        className="px-2.5 py-1 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[10px] font-bold tracking-wider uppercase hover:bg-rose-500 hover:text-black transition-all"
                      >
                        Reject
                      </button>
                    </div>
                  </div>
                ))}

                {/* Render Pending Certificates requests */}
                {pendingCerts.map((cert) => (
                  <div 
                    key={cert.id} 
                    className="p-4 rounded-2xl border border-white/[0.04] bg-indigo-500/[0.01] hover:bg-indigo-500/[0.02] border-l-2 border-l-indigo-400 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-mono uppercase bg-indigo-500/10 text-indigo-400 px-1.5 py-0.5 rounded font-bold">Certificate Approval</span>
                        <span className="text-[9px] font-bold text-indigo-300">GPA: {cert.gpa}</span>
                      </div>
                      <p className="text-xs font-bold text-white leading-tight">Student: {cert.studentName}</p>
                      <p className="text-[10px] text-white/50">Course: {cert.courseTitle}</p>
                      <p className="text-[9px] font-bold text-white/30">Status: <span className="text-amber-400">{cert.status}</span></p>
                    </div>

                    <div className="flex items-center gap-1.5 self-end sm:self-auto">
                      <button 
                        onClick={() => onApproveCertificate(cert.id)}
                        className="px-2.5 py-1 rounded-xl bg-[#10b981] text-black text-[10px] font-bold tracking-wider uppercase hover:bg-emerald-400 transition-all"
                      >
                        Approve
                      </button>
                      <button 
                        onClick={() => onRejectCertificate(cert.id)}
                        className="px-2.5 py-1 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[10px] font-bold tracking-wider uppercase hover:bg-rose-500 hover:text-black transition-all"
                      >
                        Reject
                      </button>
                    </div>
                  </div>
                ))}
              </>
            )}
          </div>
        </div>

        {/* Recent Activity Logs widget (5 cols on lg) */}
        <div className="lg:col-span-5 p-6 rounded-3xl border border-white/[0.06] bg-zinc-950/60 backdrop-blur-md space-y-4 text-left">
          <div className="flex items-center gap-2">
            <Activity size={15} className="text-emerald-400" />
            <h3 className="text-xs font-black text-white uppercase tracking-wider">System Activities timeline</h3>
          </div>

          <div className="space-y-4 relative before:absolute before:left-2 before:top-2 before:bottom-2 before:w-[1px] before:bg-white/[0.05] pl-6 text-xs">
            {[
              { time: "09:42 AM", title: "Certificate approved", details: "Cody Fisher - React & Architecture", icon: Award, color: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" },
              { time: "08:15 AM", title: "New enrollment batch", details: "Sarah Vance posted Summer Core 2026", icon: BookOpen, color: "bg-indigo-500/20 text-indigo-400 border-indigo-500/30" },
              { time: "Yesterday", title: "Announcements posted", details: "Target: All Active Students", icon: Megaphone, color: "bg-cyan-500/20 text-cyan-400 border-cyan-500/30" },
              { time: "2 days ago", title: "System security backup", details: "Cloud Storage backup status: Success", icon: ShieldCheck, color: "bg-purple-500/20 text-purple-400 border-purple-500/30" }
            ].map((act, i) => {
              const LogIcon = act.icon;
              return (
                <div key={i} className="relative space-y-0.5">
                  <span className={`absolute -left-7 top-0.5 h-3.5 w-3.5 rounded-full border flex items-center justify-center p-[2px] ${act.color} bg-zinc-950 z-10`}>
                    <LogIcon size={8} />
                  </span>
                  <div className="flex justify-between items-center">
                    <p className="font-bold text-white">{act.title}</p>
                    <span className="text-[8px] font-mono text-white/30">{act.time}</span>
                  </div>
                  <p className="text-[10px] text-white/50">{act.details}</p>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
}
