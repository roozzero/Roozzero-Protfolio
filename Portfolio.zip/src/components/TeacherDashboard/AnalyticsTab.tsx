import React, { useState, useMemo } from "react";
import { motion } from "motion/react";
import {
  BarChart3,
  TrendingUp,
  Download,
  Filter,
  Users,
  Award,
  Clock,
  Sparkles,
  ChevronDown
} from "lucide-react";
import { Student, Course } from "../../types/teacher";

interface AnalyticsTabProps {
  students: Student[];
  courses: Course[];
  showCustomToast: (msg: string, type?: "info" | "success" | "warning") => void;
}

export default function AnalyticsTab({
  students,
  courses,
  showCustomToast
}: AnalyticsTabProps) {
  const [selectedCourseId, setSelectedCourseId] = useState("all");

  const filteredStudents = useMemo(() => {
    if (selectedCourseId === "all") return students;
    return students.filter((s) => s.courseId === selectedCourseId);
  }, [students, selectedCourseId]);

  // Compute stats
  const metrics = useMemo(() => {
    if (filteredStudents.length === 0) {
      return { avgGrade: 0, avgAttendance: 0, activeCount: 0 };
    }
    const gradesSum = filteredStudents.reduce((acc, s) => acc + (s.avgGrade || 0), 0);
    const attSum = filteredStudents.reduce((acc, s) => acc + (s.attendance || 0), 0);
    const active = filteredStudents.filter((s) => s.status === "Active").length;

    return {
      avgGrade: Math.round(gradesSum / filteredStudents.length),
      avgAttendance: Math.round(attSum / filteredStudents.length),
      activeCount: active
    };
  }, [filteredStudents]);

  const handleExport = () => {
    showCustomToast("Compiling academic analytics metrics...", "info");
    setTimeout(() => {
      showCustomToast("Downloaded CSV report successfully!", "success");
    }, 1200);
  };

  return (
    <div className="space-y-6 animate-fade-in text-left">
      {/* SECTION HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.04] pb-5">
        <div className="space-y-1">
          <h2 className="font-sans text-xl font-bold text-white uppercase tracking-wider">
            Academic Performance Analytics
          </h2>
          <p className="font-sans text-xs text-white/40">
            Audit average class grades, session attendance levels, and course completion indexes.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-center">
          <select
            value={selectedCourseId}
            onChange={(e) => setSelectedCourseId(e.target.value)}
            className="bg-[#08080c] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white/80 hover:text-white focus:outline-none cursor-pointer"
          >
            <option value="all">All Courses Combined</option>
            {courses.map((c) => (
              <option key={c.id} value={c.id}>
                {c.title}
              </option>
            ))}
          </select>

          <button
            onClick={handleExport}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/[0.02] hover:bg-white/[0.06] border border-white/10 hover:border-white/15 text-xs font-bold text-white transition-all cursor-pointer hover:scale-[1.02]"
          >
            <Download size={12} className="text-indigo-400" />
            <span>Export Report</span>
          </button>
        </div>
      </div>

      {/* THREE VALUE CARDS ROW */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-[#08080c]/90 border border-white/[0.04] flex items-center gap-4">
          <div className="p-3.5 rounded-xl bg-indigo-500/10 text-indigo-400 shrink-0">
            <Users size={16} />
          </div>
          <div className="space-y-0.5">
            <span className="block text-[10px] text-white/40 uppercase font-sans">Active Target Segment</span>
            <span className="block text-xl font-mono font-bold text-white">{metrics.activeCount} Students</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#08080c]/90 border border-white/[0.04] flex items-center gap-4">
          <div className="p-3.5 rounded-xl bg-emerald-500/10 text-emerald-400 shrink-0">
            <Award size={16} />
          </div>
          <div className="space-y-0.5">
            <span className="block text-[10px] text-white/40 uppercase font-sans">Aggregate Score Average</span>
            <span className="block text-xl font-mono font-bold text-emerald-400">{metrics.avgGrade}%</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#08080c]/90 border border-white/[0.04] flex items-center gap-4">
          <div className="p-3.5 rounded-xl bg-cyan-500/10 text-cyan-400 shrink-0">
            <Clock size={16} />
          </div>
          <div className="space-y-0.5">
            <span className="block text-[10px] text-white/40 uppercase font-sans">Daily Class Attendance</span>
            <span className="block text-xl font-mono font-bold text-cyan-400">{metrics.avgAttendance}%</span>
          </div>
        </div>
      </div>

      {/* SVG GRAPH PANEL GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* GRAPH 1: GRADE DISTRIBUTION (SVG BAR CHART) */}
        <div className="bg-[#08080c]/90 border border-white/[0.05] rounded-3xl p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-white/[0.04] pb-3">
            <BarChart3 size={15} className="text-indigo-400" />
            <h3 className="font-sans text-xs font-bold text-white uppercase tracking-wider">
              Grade Distribution Curve (SVG Matrix)
            </h3>
          </div>

          <div className="h-64 flex items-end justify-between px-6 pb-2 pt-6 bg-[#030304]/60 border border-white/[0.03] rounded-2xl relative select-none">
            {/* Background Grid Lines */}
            <div className="absolute inset-0 flex flex-col justify-between py-6 px-4 pointer-events-none opacity-15">
              <div className="border-b border-white/40 w-full" />
              <div className="border-b border-white/40 w-full" />
              <div className="border-b border-white/40 w-full" />
              <div className="border-b border-white/40 w-full" />
            </div>

            {/* Individual Bars */}
            {filteredStudents.length === 0 ? (
              <div className="absolute inset-0 flex items-center justify-center text-white/30 text-xs">
                No active student metrics.
              </div>
            ) : (
              filteredStudents.map((s, idx) => (
                <div key={s.id} className="flex flex-col items-center gap-2.5 w-1/8 relative group z-10">
                  {/* Tooltip on Hover */}
                  <div className="absolute -top-12 bg-indigo-600 border border-indigo-400 rounded-lg px-2 py-1 text-[9px] font-mono font-semibold text-white pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300 shadow-md">
                    {s.avgGrade > 0 ? `${s.avgGrade}%` : "N/A"}
                  </div>
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: `${s.avgGrade ? Math.max(s.avgGrade * 1.6, 20) : 10}px` }}
                    transition={{ duration: 0.6, delay: idx * 0.05 }}
                    className={`w-4 sm:w-6 rounded-t-lg bg-gradient-to-t ${s.avgGrade >= 90 ? "from-indigo-600 to-indigo-400" : s.avgGrade >= 80 ? "from-purple-600 to-purple-400" : "from-zinc-700 to-zinc-500"} cursor-pointer hover:brightness-110 transition-all`}
                  />
                  <span className="block font-mono text-[9px] text-white/40 max-w-full truncate text-center uppercase tracking-wide">
                    {s.name.split(" ")[0]}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* GRAPH 2: PROGRESS ENGAGEMENT (SVG AREA LINE GRAPH) */}
        <div className="bg-[#08080c]/90 border border-white/[0.05] rounded-3xl p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-white/[0.04] pb-3">
            <TrendingUp size={15} className="text-emerald-400" />
            <h3 className="font-sans text-xs font-bold text-white uppercase tracking-wider">
              Student Attendance Levels (SVG Graph)
            </h3>
          </div>

          <div className="h-64 flex items-end justify-between px-6 pb-2 pt-6 bg-[#030304]/60 border border-white/[0.03] rounded-2xl relative select-none">
            {/* Background Grid Lines */}
            <div className="absolute inset-0 flex flex-col justify-between py-6 px-4 pointer-events-none opacity-15">
              <div className="border-b border-white/40 w-full" />
              <div className="border-b border-white/40 w-full" />
              <div className="border-b border-white/40 w-full" />
              <div className="border-b border-white/40 w-full" />
            </div>

            {/* Individual Bars for Attendance */}
            {filteredStudents.length === 0 ? (
              <div className="absolute inset-0 flex items-center justify-center text-white/30 text-xs">
                No active student metrics.
              </div>
            ) : (
              filteredStudents.map((s, idx) => (
                <div key={s.id} className="flex flex-col items-center gap-2.5 w-1/8 relative group z-10">
                  <div className="absolute -top-12 bg-emerald-600 border border-emerald-400 rounded-lg px-2 py-1 text-[9px] font-mono font-semibold text-white pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300 shadow-md">
                    {s.attendance}%
                  </div>
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: `${s.attendance ? Math.max(s.attendance * 1.6, 20) : 10}px` }}
                    transition={{ duration: 0.6, delay: idx * 0.05 }}
                    className={`w-4 sm:w-6 rounded-t-lg bg-gradient-to-t ${s.attendance >= 90 ? "from-emerald-600 to-emerald-400" : s.attendance >= 80 ? "from-cyan-600 to-cyan-400" : "from-zinc-700 to-zinc-500"} cursor-pointer hover:brightness-110 transition-all`}
                  />
                  <span className="block font-mono text-[9px] text-white/40 max-w-full truncate text-center uppercase tracking-wide">
                    {s.name.split(" ")[0]}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
