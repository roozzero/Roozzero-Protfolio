import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Shield, Users, Image as ImageIcon, Activity, Search, Filter, 
  Download, Upload, Trash2, Eye, Calendar, ArrowUpRight, 
  X, Check, AlertCircle, FileSpreadsheet, FileText, Smartphone, Laptop, Lock, ShieldAlert
} from "lucide-react";
import { AdminUser } from "./types";
import { Student } from "../../types/teacher";

interface SecurityTabProps {
  users: AdminUser[];
  students: Student[];
  showCustomToast: (msg: string, type?: "info" | "success" | "warning") => void;
}

interface LoginLog {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  role: string;
  loginTime: string;
  logoutTime: string;
  duration: string;
  ipAddress: string;
  device: string;
  browser: string;
  os: string;
  status: "Success" | "Failed - Bad Password" | "Failed - Locked" | "Success - MFA Completed";
}

export default function SecurityTab({ users, students, showCustomToast }: SecurityTabProps) {
  const [activeSubTab, setActiveSubTab] = useState<"directory" | "photos" | "login_activity">("directory");
  
  // Search & Filters state
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");

  // Photos gallery state
  const [selectedPhotoUser, setSelectedPhotoUser] = useState<AdminUser | null>(null);
  const [userPhotos, setUserPhotos] = useState<{ [userId: string]: string }>({
    "usr-1": "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=300&auto=format&fit=crop", // Jaden Smith
    "usr-2": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=300&auto=format&fit=crop", // Cody Fisher
    "usr-3": "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=300&auto=format&fit=crop"  // Sarah Vance
  });

  // Login logs state
  const [loginLogs, setLoginLogs] = useState<LoginLog[]>([
    { id: "log-1", userId: "usr-1", userName: "Jaden Smith", userEmail: "admin@roozzero.dev", role: "super-admin", loginTime: "2026-07-04 09:12:05", logoutTime: "Active Session", duration: "Active", ipAddress: "82.102.14.9", device: "MacBook Pro", browser: "Chrome", os: "macOS", status: "Success - MFA Completed" },
    { id: "log-2", userId: "usr-3", userName: "Sarah Vance", userEmail: "teacher@academy.local", role: "teacher", loginTime: "2026-07-04 08:30:15", logoutTime: "Active Session", duration: "Active", ipAddress: "192.168.1.15", device: "ThinkPad X1", browser: "Firefox", os: "Windows 11", status: "Success" },
    { id: "log-3", userId: "usr-2", userName: "Cody Fisher", userEmail: "cody.f@academy.local", role: "student", loginTime: "2026-07-04 07:15:22", logoutTime: "2026-07-04 08:45:00", duration: "1h 30m", ipAddress: "185.120.45.102", device: "iPhone 15", browser: "Safari Mobile", os: "iOS", status: "Success" },
    { id: "log-4", userId: "usr-2", userName: "Cody Fisher", userEmail: "cody.f@academy.local", role: "student", loginTime: "2026-07-04 07:11:05", logoutTime: "—", duration: "—", ipAddress: "185.120.45.102", device: "iPhone 15", browser: "Safari Mobile", os: "iOS", status: "Failed - Bad Password" },
    { id: "log-5", userId: "usr-1", userName: "Jaden Smith", userEmail: "admin@roozzero.dev", role: "super-admin", loginTime: "2026-07-03 14:02:11", logoutTime: "2026-07-03 18:30:00", duration: "4h 27m", ipAddress: "82.102.14.9", device: "MacBook Pro", browser: "Chrome", os: "macOS", status: "Success - MFA Completed" },
    { id: "log-6", userId: "usr-3", userName: "Sarah Vance", userEmail: "teacher@academy.local", role: "teacher", loginTime: "2026-07-03 10:15:00", logoutTime: "2026-07-03 12:45:10", duration: "2h 30m", ipAddress: "192.168.1.15", device: "ThinkPad X1", browser: "Firefox", os: "Windows 11", status: "Success" },
    { id: "log-7", userId: "usr-2", userName: "Cody Fisher", userEmail: "cody.f@academy.local", role: "student", loginTime: "2026-07-02 18:22:15", logoutTime: "2026-07-02 21:05:40", duration: "2h 43m", ipAddress: "185.120.45.102", device: "iPad Air", browser: "Safari Mobile", os: "iOS", status: "Success" },
    { id: "log-8", userId: "usr-9", userName: "Unknown Hacker", userEmail: "hack@attacker.org", role: "anonymous", loginTime: "2026-07-02 03:14:15", logoutTime: "—", duration: "—", ipAddress: "45.12.8.200", device: "Kali Linux", browser: "Curl Client", os: "Linux", status: "Failed - Locked" }
  ]);

  // Logs filters state
  const [logSearchQuery, setLogSearchQuery] = useState("");
  const [logRoleFilter, setLogRoleFilter] = useState("all");
  const [logStatusFilter, setLogStatusFilter] = useState("all");
  const [exportProgress, setExportProgress] = useState<string | null>(null);

  // Sorting
  const [logSortKey, setLogSortKey] = useState<"loginTime" | "ipAddress" | "status">("loginTime");
  const [logSortOrder, setLogSortOrder] = useState<"asc" | "desc">("desc");

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // Enhance users directory mapping handles/avatars
  const mappedUsers = useMemo(() => {
    return users.map(u => {
      // Create usernames matching their emails
      const username = u.email.split("@")[0].replace(".", "_") + "_staff";
      const photo = userPhotos[u.id] || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(u.name)}`;
      return {
        ...u,
        username,
        photo
      };
    });
  }, [users, userPhotos]);

  // Filtered Users Directory
  const filteredUsers = useMemo(() => {
    return mappedUsers.filter(u => {
      const matchSearch = u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          u.username.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchRole = roleFilter === "all" || u.role === roleFilter;
      const matchStatus = statusFilter === "all" || u.status.toLowerCase() === statusFilter.toLowerCase();
      
      return matchSearch && matchRole && matchStatus;
    });
  }, [mappedUsers, searchQuery, roleFilter, statusFilter]);

  // Filtered & Sorted Logs
  const filteredAndSortedLogs = useMemo(() => {
    let result = loginLogs.filter(log => {
      const matchSearch = log.userName.toLowerCase().includes(logSearchQuery.toLowerCase()) || 
                          log.userEmail.toLowerCase().includes(logSearchQuery.toLowerCase()) ||
                          log.ipAddress.includes(logSearchQuery);
      
      let matchRole = true;
      if (logRoleFilter !== "all") {
        matchRole = log.role === logRoleFilter;
      }

      let matchStatus = true;
      if (logStatusFilter !== "all") {
        if (logStatusFilter === "success") {
          matchStatus = log.status.startsWith("Success");
        } else {
          matchStatus = log.status.startsWith("Failed");
        }
      }

      return matchSearch && matchRole && matchStatus;
    });

    // Sort
    result.sort((a, b) => {
      let valA = a[logSortKey];
      let valB = b[logSortKey];
      if (valA < valB) return logSortOrder === "asc" ? -1 : 1;
      if (valA > valB) return logSortOrder === "asc" ? 1 : -1;
      return 0;
    });

    return result;
  }, [loginLogs, logSearchQuery, logRoleFilter, logStatusFilter, logSortKey, logSortOrder]);

  // Paginated Logs
  const paginatedLogs = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredAndSortedLogs.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredAndSortedLogs, currentPage]);

  const totalPages = Math.ceil(filteredAndSortedLogs.length / itemsPerPage) || 1;

  // Toggle sort direction or sort key
  const handleSort = (key: "loginTime" | "ipAddress" | "status") => {
    if (logSortKey === key) {
      setLogSortOrder(prev => prev === "asc" ? "desc" : "asc");
    } else {
      setLogSortKey(key);
      setLogSortOrder("desc");
    }
  };

  // Replace photo handler
  const handleReplacePhoto = (userId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        if (uploadEvent.target?.result) {
          const base64 = uploadEvent.target.result as string;
          setUserPhotos(prev => ({
            ...prev,
            [userId]: base64
          }));
          showCustomToast("User profile photo updated successfully!", "success");
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Remove photo handler
  const handleRemovePhoto = (userId: string) => {
    setUserPhotos(prev => {
      const copy = { ...prev };
      delete copy[userId];
      return copy;
    });
    showCustomToast("Profile image removed. Set to default placeholder.", "info");
  };

  // Download photo simulation
  const handleDownloadPhoto = (userName: string, photoUrl: string) => {
    // Generate a simple simulation link download
    const anchor = document.createElement("a");
    anchor.href = photoUrl;
    anchor.download = `${userName.replace(/\s+/g, "_").toLowerCase()}_profile.jpg`;
    document.body.appendChild(anchor);
    showCustomToast(`Initiated download for ${userName}'s profile avatar.`, "success");
    anchor.click();
    anchor.remove();
  };

  // Simulate Logging Exports
  const handleExportLogs = (format: string) => {
    setExportProgress("Compiling security logs data & applying hash signatures...");
    setTimeout(() => {
      setExportProgress("Formatting as " + format + " sheet structures...");
      setTimeout(() => {
        setExportProgress(null);
        showCustomToast(`Export successful! Security logs generated as admin_login_logs.${format.toLowerCase()}`, "success");
      }, 800);
    }, 1200);
  };

  return (
    <div className="space-y-6 text-left font-sans animate-fade-in">
      
      {/* SECTION HEADER */}
      <div className="space-y-1.5 text-left border-b border-white/[0.04] pb-5">
        <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-widest block font-mono">LMS Cryptographic Security Hub</span>
        <h2 className="font-sans text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
          <Shield className="text-emerald-400" size={24} />
          <span>Security & Auditing Monitor</span>
        </h2>
        <p className="text-xs text-white/40 max-w-2xl leading-relaxed">
          Monitor directory accesses, manage user profiles and photo files, audit real-time authentication logs, and manage GDPR security compliance records.
        </p>
      </div>

      {/* Sub-tab Navigation */}
      <div className="sticky top-0 z-20 backdrop-blur-md bg-[#030304]/80 py-3 border-b border-white/[0.04] flex items-center gap-1.5 select-none overflow-x-auto scrollbar-none">
        {[
          { id: "directory", label: "User Directory Access", icon: Users },
          { id: "photos", label: "Profile Photo Audit", icon: ImageIcon },
          { id: "login_activity", label: "Login Activity Monitor", icon: Activity }
        ].map((tab) => {
          const isActive = activeSubTab === tab.id;
          const TabIcon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveSubTab(tab.id as any);
              }}
              className="relative px-4 py-2.5 rounded-xl text-xs font-bold tracking-wide transition-all shrink-0 cursor-pointer flex items-center gap-2"
              style={{ WebkitTapHighlightColor: "transparent" }}
            >
              {isActive && (
                <motion.div
                  layoutId="activeSecuritySubIndicator"
                  className="absolute inset-0 bg-emerald-600 rounded-xl shadow-lg shadow-emerald-600/20"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                />
              )}
              <TabIcon size={14} className={`relative z-10 ${isActive ? "text-white" : "text-white/40"}`} />
              <span className={`relative z-10 transition-colors duration-200 ${isActive ? "text-white" : "text-white/40 hover:text-white/80"}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeSubTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.15 }}
          className="space-y-6"
        >
          
          {/* TAB 1: USER DIRECTORY */}
          {activeSubTab === "directory" && (
            <div className="space-y-4">
              {/* Directory Filter Panel */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#08080c] p-4 border border-white/[0.04] rounded-3xl">
                <div className="flex-1 flex flex-wrap gap-3 items-center">
                  <div className="relative w-64">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30"><Search size={14} /></span>
                    <input 
                      type="text" 
                      placeholder="Search users, emails, usernames..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-[#030304] border border-white/10 rounded-xl py-2 pl-10 pr-3 text-xs text-white placeholder-white/30 focus:outline-none focus:border-emerald-500 transition-colors"
                    />
                  </div>

                  <select 
                    value={roleFilter}
                    onChange={(e) => setRoleFilter(e.target.value)}
                    className="bg-[#030304] border border-white/10 rounded-xl py-2 px-3 text-xs text-white/80 focus:outline-none cursor-pointer"
                  >
                    <option value="all">All Roles</option>
                    <option value="super-admin">Super Admin</option>
                    <option value="teacher">Instructors</option>
                    <option value="student">Students</option>
                  </select>

                  <select 
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="bg-[#030304] border border-white/10 rounded-xl py-2 px-3 text-xs text-white/80 focus:outline-none cursor-pointer"
                  >
                    <option value="all">All Statuses</option>
                    <option value="active">Active</option>
                    <option value="suspended">Suspended</option>
                    <option value="pending">Pending</option>
                  </select>
                </div>

                <div className="text-[10px] font-semibold text-white/30 tracking-wider uppercase">
                  DIRECTORY METRICS: <span className="text-emerald-400 font-bold">{filteredUsers.length} Users Found</span>
                </div>
              </div>

              {/* Directory Records Table */}
              <div className="bg-[#08080c] border border-white/[0.05] rounded-3xl overflow-hidden shadow-2xl">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-white/[0.02] border-b border-white/[0.04] text-[9px] font-mono text-white/40 uppercase tracking-widest">
                        <th className="p-4 pl-6">Profile Photo</th>
                        <th className="p-4">Full Name</th>
                        <th className="p-4">Username</th>
                        <th className="p-4">Email</th>
                        <th className="p-4">Assigned Role</th>
                        <th className="p-4">Account Status</th>
                        <th className="p-4 pr-6">Last Session Login</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/[0.03]">
                      {filteredUsers.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="text-center py-12 text-white/30">
                            No directory records matched your search filters.
                          </td>
                        </tr>
                      ) : (
                        filteredUsers.map((user) => (
                          <tr key={user.id} className="hover:bg-white/[0.01] transition-colors">
                            <td className="p-4 pl-6">
                              <img 
                                src={user.photo} 
                                alt={user.name} 
                                className="h-9 w-9 rounded-full object-cover border border-white/10 shadow-lg"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(user.name)}`;
                                }}
                              />
                            </td>
                            <td className="p-4 font-bold text-white tracking-wide">
                              {user.name}
                            </td>
                            <td className="p-4 font-mono text-[10px] text-indigo-300">
                              @{user.username}
                            </td>
                            <td className="p-4 text-white/60 font-medium">
                              {user.email}
                            </td>
                            <td className="p-4">
                              <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-extrabold uppercase border ${
                                user.role === "super-admin" 
                                  ? "bg-rose-500/10 border-rose-500/20 text-rose-300"
                                  : user.role === "teacher"
                                  ? "bg-indigo-500/10 border-indigo-500/20 text-indigo-300"
                                  : "bg-emerald-500/10 border-emerald-500/20 text-emerald-300"
                              }`}>
                                {user.role === "super-admin" ? "super admin" : user.role}
                              </span>
                            </td>
                            <td className="p-4">
                              <div className="flex items-center gap-1.5">
                                <span className={`h-1.5 w-1.5 rounded-full ${
                                  user.status === "Active" 
                                    ? "bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.5)]" 
                                    : user.status === "Suspended"
                                    ? "bg-rose-400"
                                    : "bg-amber-400"
                                }`} />
                                <span className="font-semibold text-white/70">{user.status}</span>
                              </div>
                            </td>
                            <td className="p-4 pr-6 text-white/40 font-semibold font-mono text-[10px]">
                              {user.lastLogin}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: PROFILE PHOTOS GALLERY */}
          {activeSubTab === "photos" && (
            <div className="space-y-4">
              <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl flex gap-3 text-emerald-400 max-w-3xl">
                <ShieldAlert size={16} className="shrink-0 mt-0.5" />
                <div className="text-[11px] leading-relaxed">
                  <span className="font-extrabold uppercase text-[9px] tracking-wider block mb-0.5">Faculty Image Policy Review</span>
                  <p>Administrators have the authority to view, download, replace, and purge profile avatars to comply with terms of service. Fallback initials are deployed on removal.</p>
                </div>
              </div>

              {/* Photo Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
                {mappedUsers.map((user) => (
                  <div 
                    key={user.id}
                    className="p-5 rounded-3xl bg-[#08080c] border border-white/[0.04] hover:border-white/10 transition-all flex flex-col justify-between h-56 relative group overflow-hidden"
                  >
                    <div className="space-y-4">
                      {/* Avatar and Info */}
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <img 
                            src={user.photo} 
                            alt={user.name} 
                            className="h-12 w-12 rounded-full object-cover border border-white/10"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(user.name)}`;
                            }}
                          />
                          <div className={`absolute bottom-0.5 right-0.5 h-2.5 w-2.5 rounded-full border border-[#08080c] ${
                            user.status === "Active" ? "bg-emerald-500" : "bg-rose-500"
                          }`} />
                        </div>
                        <div className="space-y-0.5 text-left">
                          <h4 className="font-sans text-xs font-bold text-white tracking-tight leading-tight">
                            {user.name}
                          </h4>
                          <span className="block text-[9px] font-mono text-indigo-400 font-extrabold uppercase tracking-widest">
                            {user.role}
                          </span>
                        </div>
                      </div>

                      {/* Details */}
                      <div className="space-y-1 text-[11px] text-white/40">
                        <div className="flex justify-between">
                          <span>User ID:</span>
                          <span className="font-mono text-[9px] text-white/60">{user.id}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Registration Date:</span>
                          <span className="font-mono text-[9px] text-white/60">{user.joinedDate}</span>
                        </div>
                      </div>
                    </div>

                    {/* Actions Row */}
                    <div className="flex items-center justify-end gap-1.5 border-t border-white/[0.03] pt-3 mt-3">
                      <button 
                        onClick={() => setSelectedPhotoUser(user)}
                        className="p-2 rounded-lg bg-white/[0.02] border border-white/[0.05] hover:border-white/10 text-white/60 hover:text-white transition-all cursor-pointer"
                        title="View Full Resolution Image"
                      >
                        <Eye size={12} />
                      </button>

                      <button 
                        onClick={() => handleDownloadPhoto(user.name, user.photo)}
                        className="p-2 rounded-lg bg-white/[0.02] border border-white/[0.05] hover:border-emerald-500/20 text-white/60 hover:text-emerald-400 transition-all cursor-pointer"
                        title="Download Asset"
                      >
                        <Download size={12} />
                      </button>

                      <label 
                        className="p-2 rounded-lg bg-white/[0.02] border border-white/[0.05] hover:border-indigo-500/20 text-white/60 hover:text-indigo-400 transition-all cursor-pointer flex items-center justify-center"
                        title="Replace Asset"
                      >
                        <Upload size={12} />
                        <input 
                          type="file" 
                          className="hidden" 
                          accept="image/*" 
                          onChange={(e) => handleReplacePhoto(user.id, e)}
                        />
                      </label>

                      {userPhotos[user.id] && (
                        <button 
                          onClick={() => handleRemovePhoto(user.id)}
                          className="p-2 rounded-lg bg-white/[0.02] border border-white/[0.05] hover:border-rose-500/20 text-white/60 hover:text-rose-400 transition-all cursor-pointer"
                          title="Purge Avatar File"
                        >
                          <Trash2 size={12} />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: LOGIN ACTIVITY */}
          {activeSubTab === "login_activity" && (
            <div className="space-y-4 animate-fade-in text-xs">
              
              {/* Export overlay */}
              {exportProgress && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center p-4">
                  <div className="w-full max-w-sm p-6 bg-[#08080c] border border-white/10 rounded-3xl text-center space-y-4 shadow-2xl">
                    <div className="h-2 w-full bg-white/[0.03] rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: "0%" }}
                        animate={{ width: "100%" }}
                        transition={{ duration: 1.8, ease: "easeInOut" }}
                        className="h-full bg-emerald-500 rounded-full"
                      />
                    </div>
                    <p className="font-mono text-[10px] text-emerald-400 tracking-wide uppercase leading-relaxed animate-pulse">{exportProgress}</p>
                  </div>
                </div>
              )}

              {/* Filtering logs toolbar */}
              <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4 bg-[#08080c] p-4 border border-white/[0.04] rounded-3xl">
                <div className="flex-1 flex flex-wrap gap-2.5 items-center">
                  <div className="relative w-64">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30"><Search size={14} /></span>
                    <input 
                      type="text" 
                      placeholder="Search users or IP addresses..."
                      value={logSearchQuery}
                      onChange={(e) => { setLogSearchQuery(e.target.value); setCurrentPage(1); }}
                      className="w-full bg-[#030304] border border-white/10 rounded-xl py-2 pl-10 pr-3 text-xs text-white placeholder-white/30 focus:outline-none focus:border-emerald-500 transition-colors"
                    />
                  </div>

                  <select 
                    value={logRoleFilter}
                    onChange={(e) => { setLogRoleFilter(e.target.value); setCurrentPage(1); }}
                    className="bg-[#030304] border border-white/10 rounded-xl py-2 px-3 text-xs text-white/80 focus:outline-none cursor-pointer"
                  >
                    <option value="all">All Roles</option>
                    <option value="super-admin">Super Admins</option>
                    <option value="teacher">Instructors</option>
                    <option value="student">Students</option>
                    <option value="anonymous">Anonymous</option>
                  </select>

                  <select 
                    value={logStatusFilter}
                    onChange={(e) => { setLogStatusFilter(e.target.value); setCurrentPage(1); }}
                    className="bg-[#030304] border border-white/10 rounded-xl py-2 px-3 text-xs text-white/80 focus:outline-none cursor-pointer"
                  >
                    <option value="all">All Statuses</option>
                    <option value="success">Success Statuses</option>
                    <option value="failed">Failed Statuses</option>
                  </select>
                </div>

                {/* Export Options */}
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => handleExportLogs("Excel")}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/10 bg-white/[0.01] hover:bg-white/[0.04] hover:text-white transition-all text-[10px] font-sans font-bold uppercase tracking-wider cursor-pointer"
                  >
                    <FileSpreadsheet size={12} className="text-emerald-400" />
                    <span>Excel</span>
                  </button>
                  <button 
                    onClick={() => handleExportLogs("PDF")}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/10 bg-white/[0.01] hover:bg-white/[0.04] hover:text-white transition-all text-[10px] font-sans font-bold uppercase tracking-wider cursor-pointer"
                  >
                    <FileText size={12} className="text-rose-400" />
                    <span>PDF</span>
                  </button>
                  <button 
                    onClick={() => handleExportLogs("CSV")}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/10 bg-white/[0.01] hover:bg-white/[0.04] hover:text-white transition-all text-[10px] font-sans font-bold uppercase tracking-wider cursor-pointer"
                  >
                    <FileText size={12} className="text-cyan-400" />
                    <span>CSV</span>
                  </button>
                </div>
              </div>

              {/* Log Records Table */}
              <div className="bg-[#08080c] border border-white/[0.05] rounded-3xl overflow-hidden shadow-2xl">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-white/[0.02] border-b border-white/[0.04] text-[9px] font-mono text-white/40 uppercase tracking-widest cursor-pointer select-none">
                        <th className="p-4 pl-6" onClick={() => handleSort("loginTime")}>
                          User Identity
                        </th>
                        <th className="p-4" onClick={() => handleSort("loginTime")}>
                          Login Date/Time {logSortKey === "loginTime" && (logSortOrder === "asc" ? "▲" : "▼")}
                        </th>
                        <th className="p-4">Logout Date/Time</th>
                        <th className="p-4">Session Duration</th>
                        <th className="p-4" onClick={() => handleSort("ipAddress")}>
                          IP Address {logSortKey === "ipAddress" && (logSortOrder === "asc" ? "▲" : "▼")}
                        </th>
                        <th className="p-4">Client Agent / Device Details</th>
                        <th className="p-4 pr-6" onClick={() => handleSort("status")}>
                          Login Status {logSortKey === "status" && (logSortOrder === "asc" ? "▲" : "▼")}
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/[0.03]">
                      {paginatedLogs.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="text-center py-12 text-white/30">
                            No log activity matched your filtering parameters.
                          </td>
                        </tr>
                      ) : (
                        paginatedLogs.map((log) => (
                          <tr key={log.id} className="hover:bg-white/[0.01] transition-colors">
                            <td className="p-4 pl-6 space-y-0.5">
                              <p className="font-bold text-white leading-none">{log.userName}</p>
                              <span className="font-mono text-[9px] text-white/40 block leading-none">{log.userEmail}</span>
                            </td>
                            <td className="p-4 font-semibold font-mono text-[10px]">
                              {log.loginTime}
                            </td>
                            <td className="p-4 font-semibold font-mono text-[10px] text-white/60">
                              {log.logoutTime}
                            </td>
                            <td className="p-4 text-white/50 font-semibold font-mono text-[10px]">
                              {log.duration}
                            </td>
                            <td className="p-4 text-indigo-300 font-mono text-[10px]">
                              {log.ipAddress}
                            </td>
                            <td className="p-4 flex items-center gap-2 text-white/60">
                              {log.device.toLowerCase().includes("mac") || log.device.toLowerCase().includes("think") ? (
                                <Laptop size={13} className="text-white/30" />
                              ) : (
                                <Smartphone size={13} className="text-white/30" />
                              )}
                              <span className="font-medium">{log.device} • {log.os} • {log.browser}</span>
                            </td>
                            <td className="p-4 pr-6">
                              <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold border ${
                                log.status.startsWith("Success")
                                  ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                                  : "bg-rose-500/10 border-rose-500/20 text-rose-400"
                              }`}>
                                {log.status}
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Pagination Controls */}
                <div className="flex items-center justify-between p-4 bg-white/[0.01] border-t border-white/[0.04]">
                  <span className="text-[10px] font-semibold text-white/40 uppercase tracking-wider">
                    Page {currentPage} of {totalPages} ({filteredAndSortedLogs.length} logs total)
                  </span>
                  
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                      className="px-3 py-1.5 rounded-lg border border-white/10 text-[10px] font-bold text-white/50 hover:text-white disabled:opacity-30 disabled:pointer-events-none transition-all cursor-pointer"
                    >
                      Previous
                    </button>
                    <button
                      onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages}
                      className="px-3 py-1.5 rounded-lg border border-white/10 text-[10px] font-bold text-white/50 hover:text-white disabled:opacity-30 disabled:pointer-events-none transition-all cursor-pointer"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

        </motion.div>
      </AnimatePresence>

      {/* FULL-RESOLUTION VIEW MODAL FOR PORTAL PHOTOS */}
      <AnimatePresence>
        {selectedPhotoUser && (
          <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#08080c] border border-white/10 rounded-3xl w-full max-w-md p-6 relative shadow-2xl text-center space-y-5"
            >
              <button 
                onClick={() => setSelectedPhotoUser(null)}
                className="absolute top-4 right-4 p-1.5 rounded-lg text-white/30 hover:text-white hover:bg-white/[0.05] transition-colors"
              >
                <X size={15} />
              </button>

              <div className="flex items-center gap-2 border-b border-white/[0.04] pb-4 mb-2 text-left">
                <ImageIcon size={15} className="text-emerald-400" />
                <h3 className="font-sans text-xs font-bold text-white uppercase tracking-wider">
                  Full Image Inspector
                </h3>
              </div>

              <div className="relative aspect-square w-64 mx-auto rounded-3xl overflow-hidden border border-white/10">
                <img 
                  src={userPhotos[selectedPhotoUser.id] || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(selectedPhotoUser.name)}`} 
                  alt={selectedPhotoUser.name}
                  className="h-full w-full object-cover"
                />
              </div>

              <div className="space-y-1.5">
                <h4 className="font-sans text-sm font-bold text-white">{selectedPhotoUser.name}</h4>
                <p className="font-mono text-[9px] text-white/40 uppercase tracking-widest">{selectedPhotoUser.role} • {selectedPhotoUser.email}</p>
              </div>

              <div className="pt-4 border-t border-white/[0.04] flex items-center justify-end gap-2 text-xs">
                <button 
                  onClick={() => setSelectedPhotoUser(null)}
                  className="px-4 py-2.5 rounded-xl border border-white/10 hover:bg-white/[0.02] text-xs font-bold text-white cursor-pointer"
                >
                  Close Inspector
                </button>
                <button 
                  onClick={() => {
                    handleDownloadPhoto(selectedPhotoUser.name, userPhotos[selectedPhotoUser.id] || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(selectedPhotoUser.name)}`);
                    setSelectedPhotoUser(null);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-sans font-bold text-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Download size={13} />
                  <span>Download file</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
