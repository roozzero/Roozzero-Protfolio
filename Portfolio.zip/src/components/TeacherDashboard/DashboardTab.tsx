import React from "react";
import { motion } from "motion/react";
import {
  BookOpen,
  Users,
  Clock,
  CheckSquare,
  MessageSquare,
  Award,
  Calendar,
  Sparkles,
  FileText,
  UserPlus,
  Play,
  Megaphone,
  FolderPlus,
  ChevronRight,
  Github,
  Twitter,
  Instagram,
  Linkedin,
  Send,
  User
} from "lucide-react";
import { Course, Student, Session, Assignment, DiscussionThread, TeacherProfile } from "../../types/teacher";

interface DashboardTabProps {
  courses: Course[];
  students: Student[];
  sessions: Session[];
  assignments: Assignment[];
  discussions: DiscussionThread[];
  onNavigate: (tab: string) => void;
  onQuickAction: (action: string) => void;
  profile: TeacherProfile;
}

export default function DashboardTab({
  courses,
  students,
  sessions,
  assignments,
  discussions,
  onNavigate,
  onQuickAction,
  profile
}: DashboardTabProps) {
  // Compute Stats
  const activeCoursesCount = courses.filter((c) => c.status === "Active").length;
  const totalStudentsCount = students.filter((s) => s.status === "Active").length;
  const upcomingClassesCount = sessions.filter((s) => s.status === "Scheduled").length;
  const pendingAssignmentsCount = assignments.reduce((acc, asg) => {
    return acc + asg.submissions.filter((sub) => sub.status === "Submitted").length;
  }, 0);
  const unansweredDiscussionsCount = discussions.filter((d) => d.status === "New" || d.status === "Under Review").length;
  const certificatesIssuedCount = 12; // Static high-fidelity stat

  const stats = [
    { title: "Active Courses", value: activeCoursesCount, icon: BookOpen, color: "text-indigo-400", bg: "bg-indigo-500/10", border: "border-indigo-500/20" },
    { title: "Total Students", value: totalStudentsCount, icon: Users, color: "text-emerald-400", bg: "bg-emerald-500/10", border: "border-emerald-500/20" },
    { title: "Upcoming Classes", value: upcomingClassesCount, icon: Clock, color: "text-cyan-400", bg: "bg-cyan-500/10", border: "border-cyan-500/20" },
    { title: "Review Submissions", value: pendingAssignmentsCount, icon: CheckSquare, color: "text-amber-400", bg: "bg-amber-500/10", border: "border-amber-500/20" },
    { title: "Unanswered Forums", value: unansweredDiscussionsCount, icon: MessageSquare, color: "text-rose-400", bg: "bg-rose-500/10", border: "border-rose-500/20" },
    { title: "Certificates Issued", value: certificatesIssuedCount, icon: Award, color: "text-purple-400", bg: "bg-purple-500/10", border: "border-purple-500/20" }
  ];

  const todaySessions = sessions.filter((s) => s.date === "2026-07-02" && s.status === "Scheduled");

  const recentActivities = [
    { type: "submission", text: "Courtney Henry submitted assignment 'Custom Reactive State Orchestrator'", time: "2 hours ago", link: "assignments" },
    { type: "student", text: "Eleanor Pena joined 'Swiss Typography & Editorial Layout'", time: "4 hours ago", link: "students" },
    { type: "discussion", text: "Jane Cooper created a new discussion: 'Underfitting on SGD with large learning rate'", time: "1 day ago", link: "discussions" },
    { type: "completion", text: "Cody Fisher completed Advanced React & Architecture", time: "Yesterday", link: "certificates" }
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      {/* HEADER HERO */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-indigo-950/40 via-[#08080c]/90 to-[#030304]/10 border border-white/[0.05] relative overflow-hidden">
        <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-40 pointer-events-none blur-[100px] bg-indigo-500/[0.03] rounded-full z-0" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <h1 className="font-sans text-2xl sm:text-3xl font-black text-white tracking-tight">
              LMS Teacher Workspace
            </h1>
            <p className="font-sans text-xs sm:text-sm text-white/40 tracking-wide">
              Manage courses, evaluate submissions, track student engagement, and coordinate scheduled masterclasses.
            </p>
          </div>
          <div className="flex items-center gap-2 px-4 py-2.5 rounded-full border border-white/[0.06] bg-white/[0.02] text-xs font-semibold text-white/70">
            <Sparkles size={13} className="text-emerald-400 animate-pulse" />
            <span>Academic Session: Summer 2026</span>
          </div>
        </div>
      </div>

      {/* STATISTICS GRID */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {stats.map((stat, idx) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: idx * 0.05 }}
            className={`p-4 rounded-2xl bg-[#08080c]/90 border ${stat.border} hover:border-white/10 transition-all duration-300 flex flex-col justify-between h-32 relative group cursor-pointer`}
            onClick={() => {
              if (stat.title.includes("Courses")) onNavigate("courses");
              if (stat.title.includes("Students")) onNavigate("students");
              if (stat.title.includes("Upcoming")) onNavigate("schedule");
              if (stat.title.includes("Review")) onNavigate("assignments");
              if (stat.title.includes("Forums")) onNavigate("discussions");
              if (stat.title.includes("Certificates")) onNavigate("certificates");
            }}
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] sm:text-xs text-white/40 font-semibold tracking-wider font-sans uppercase">
                {stat.title}
              </span>
              <div className={`p-2 rounded-xl ${stat.bg} ${stat.color} transition-all duration-300 group-hover:scale-110`}>
                <stat.icon size={15} />
              </div>
            </div>
            <div className="font-mono text-2xl sm:text-3xl font-bold text-white tracking-tight mt-2">
              {stat.value}
            </div>
          </motion.div>
        ))}
      </div>

      {/* DASHBOARD MIDDLE SECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* TODAY'S SCHEDULE */}
        <div className="lg:col-span-7 bg-[#08080c]/90 border border-white/[0.05] rounded-3xl p-6 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-white/[0.04] pb-4">
              <div className="flex items-center gap-2">
                <Clock size={16} className="text-indigo-400" />
                <h3 className="font-sans text-sm font-bold text-white uppercase tracking-wider">
                  Today's Scheduled Masterclasses
                </h3>
              </div>
              <button
                onClick={() => onNavigate("schedule")}
                className="text-[10px] font-extrabold text-indigo-400 hover:text-indigo-300 uppercase tracking-widest flex items-center gap-1 transition-all"
              >
                <span>Full Schedule</span>
                <ChevronRight size={10} />
              </button>
            </div>

            {todaySessions.length === 0 ? (
              <div className="py-12 text-center text-white/30 font-sans text-xs">
                No classes scheduled for today.
              </div>
            ) : (
              <div className="space-y-4">
                {todaySessions.map((sess) => (
                  <div
                    key={sess.id}
                    className="p-4 rounded-2xl bg-white/[0.01] border border-white/[0.03] hover:border-white/[0.08] transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="space-y-1.5 text-left">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/10">
                          {sess.time}
                        </span>
                        <span className="text-[10px] text-white/30 font-sans font-semibold">
                          ({sess.duration})
                        </span>
                      </div>
                      <h4 className="font-sans text-xs sm:text-sm font-bold text-white">
                        {sess.title}
                      </h4>
                      <p className="font-sans text-[11px] text-white/40">
                        {sess.courseTitle}
                      </p>
                    </div>
                    <button
                      onClick={() => onQuickAction("start-class")}
                      className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-sans font-extrabold text-[10px] tracking-widest uppercase transition-all shadow-[0_4px_12px_rgba(16,185,129,0.15)] hover:scale-[1.02] cursor-pointer"
                    >
                      <Play size={10} className="fill-current" />
                      <span>Start Class</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* QUICK ACTIONS PANEL */}
        <div className="lg:col-span-5 bg-[#08080c]/90 border border-white/[0.05] rounded-3xl p-6 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center gap-2 border-b border-white/[0.04] pb-4">
              <Sparkles size={16} className="text-emerald-400" />
              <h3 className="font-sans text-sm font-bold text-white uppercase tracking-wider">
                Quick Administrative Actions
              </h3>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => onQuickAction("create-assignment")}
                className="p-3.5 rounded-2xl bg-white/[0.01] hover:bg-white/[0.04] border border-white/[0.04] hover:border-indigo-500/20 text-left transition-all duration-300 group cursor-pointer"
              >
                <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 w-9 h-9 flex items-center justify-center mb-2 group-hover:scale-105 transition-all">
                  <FileText size={16} />
                </div>
                <span className="block font-sans text-xs font-bold text-white">New Assignment</span>
                <span className="block font-sans text-[9px] text-white/30 mt-0.5">Publish guidelines</span>
              </button>

              <button
                onClick={() => onQuickAction("send-announcement")}
                className="p-3.5 rounded-2xl bg-white/[0.01] hover:bg-white/[0.04] border border-white/[0.04] hover:border-emerald-500/20 text-left transition-all duration-300 group cursor-pointer"
              >
                <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 w-9 h-9 flex items-center justify-center mb-2 group-hover:scale-105 transition-all">
                  <Megaphone size={16} />
                </div>
                <span className="block font-sans text-xs font-bold text-white">Broadcast Alert</span>
                <span className="block font-sans text-[9px] text-white/30 mt-0.5">Send announcement</span>
              </button>

              <button
                onClick={() => onQuickAction("upload-resource")}
                className="p-3.5 rounded-2xl bg-white/[0.01] hover:bg-white/[0.04] border border-white/[0.04] hover:border-cyan-500/20 text-left transition-all duration-300 group cursor-pointer"
              >
                <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 w-9 h-9 flex items-center justify-center mb-2 group-hover:scale-105 transition-all">
                  <FolderPlus size={16} />
                </div>
                <span className="block font-sans text-xs font-bold text-white">Upload Syllabus</span>
                <span className="block font-sans text-[9px] text-white/30 mt-0.5">Share class resource</span>
              </button>

              <button
                onClick={() => onQuickAction("create-meeting")}
                className="p-3.5 rounded-2xl bg-white/[0.01] hover:bg-white/[0.04] border border-white/[0.04] hover:border-purple-500/20 text-left transition-all duration-300 group cursor-pointer"
              >
                <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 w-9 h-9 flex items-center justify-center mb-2 group-hover:scale-105 transition-all">
                  <Calendar size={16} />
                </div>
                <span className="block font-sans text-xs font-bold text-white">Schedule Meet</span>
                <span className="block font-sans text-[9px] text-white/30 mt-0.5">Add calendar session</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* RECENT ACTIVITY & ADVISORY ROW */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* RECENT ACTIVITY FEED */}
        <div className="lg:col-span-8 bg-[#08080c]/90 border border-white/[0.05] rounded-3xl p-6 text-left">
          <div className="flex items-center gap-2 border-b border-white/[0.04] pb-4 mb-4">
            <Users size={16} className="text-purple-400" />
            <h3 className="font-sans text-sm font-bold text-white uppercase tracking-wider">
              Recent Student Activity Feed
            </h3>
          </div>
          <div className="space-y-4">
            {recentActivities.map((act, i) => (
              <div
                key={i}
                className="flex items-start gap-3 p-3.5 rounded-2xl hover:bg-white/[0.01] transition-colors border border-transparent hover:border-white/[0.03] cursor-pointer"
                onClick={() => onNavigate(act.link)}
              >
                <div className="mt-0.5 flex h-6 w-6 items-center justify-center rounded-lg bg-indigo-500/10 text-indigo-400">
                  <ChevronRight size={12} />
                </div>
                <div className="space-y-0.5">
                  <p className="font-sans text-xs font-semibold text-white/90">
                    {act.text}
                  </p>
                  <p className="font-mono text-[9px] text-white/30 tracking-wide uppercase">
                    {act.time}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* INSTRUCTOR CARD SUMMARY */}
        <div className="lg:col-span-4 bg-[#08080c]/90 border border-white/[0.05] rounded-3xl p-6 text-left flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center gap-2 border-b border-white/[0.04] pb-4">
              <User size={16} className="text-indigo-400" />
              <h3 className="font-sans text-sm font-bold text-white uppercase tracking-wider">
                Faculty Public Profile
              </h3>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="relative">
                <img
                  src={profile.photo}
                  alt={profile.name}
                  className="h-12 w-12 rounded-full border border-white/10 object-cover"
                />
                <div className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-emerald-500 border-2 border-[#08080c]" />
              </div>
              <div>
                <h4 className="font-sans text-xs sm:text-sm font-bold text-white leading-tight">
                  {profile.titlePrefix ? `${profile.titlePrefix} ` : ""}{profile.name}
                </h4>
                <p className="font-sans text-[10px] text-white/40 mt-0.5">
                  {profile.department}
                </p>
                {profile.specialization && (
                  <p className="font-sans text-[10px] text-indigo-400 font-semibold mt-0.5">
                    {profile.specialization}
                  </p>
                )}
              </div>
            </div>

            <p className="font-sans text-xs text-white/60 leading-relaxed italic line-clamp-3">
              "{profile.bio}"
            </p>

            {/* Social Media Links */}
            <div className="pt-2">
              <span className="block text-[10px] text-white/30 font-bold uppercase tracking-wider mb-2 font-sans">
                Verified Connections
              </span>
              <div className="flex flex-wrap gap-2.5">
                {profile.socialLinks?.github && (
                  <a
                    href={profile.socialLinks.github.startsWith("http") ? profile.socialLinks.github : `https://github.com/${profile.socialLinks.github}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-xl bg-white/[0.02] hover:bg-white/[0.08] border border-white/[0.05] hover:border-white/10 text-white/60 hover:text-white transition-all duration-300 cursor-pointer"
                    title="GitHub Profile"
                  >
                    <Github size={14} />
                  </a>
                )}
                {profile.socialLinks?.twitter && (
                  <a
                    href={profile.socialLinks.twitter.startsWith("http") ? profile.socialLinks.twitter : `https://x.com/${profile.socialLinks.twitter.replace(/^@/, "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-xl bg-white/[0.02] hover:bg-white/[0.08] border border-white/[0.05] hover:border-white/10 text-white/60 hover:text-white transition-all duration-300 cursor-pointer"
                    title="X / Twitter Profile"
                  >
                    <Twitter size={14} />
                  </a>
                )}
                {profile.socialLinks?.instagram && (
                  <a
                    href={profile.socialLinks.instagram.startsWith("http") ? profile.socialLinks.instagram : `https://instagram.com/${profile.socialLinks.instagram.replace(/^@/, "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-xl bg-white/[0.02] hover:bg-white/[0.08] border border-white/[0.05] hover:border-white/10 text-white/60 hover:text-white transition-all duration-300 cursor-pointer"
                    title="Instagram Profile"
                  >
                    <Instagram size={14} />
                  </a>
                )}
                {profile.socialLinks?.linkedin && (
                  <a
                    href={profile.socialLinks.linkedin.startsWith("http") ? profile.socialLinks.linkedin : `https://linkedin.com/in/${profile.socialLinks.linkedin}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-xl bg-white/[0.02] hover:bg-white/[0.08] border border-white/[0.05] hover:border-white/10 text-white/60 hover:text-white transition-all duration-300 cursor-pointer"
                    title="LinkedIn Profile"
                  >
                    <Linkedin size={14} />
                  </a>
                )}
                {profile.socialLinks?.telegram && (
                  <a
                    href={profile.socialLinks.telegram.startsWith("http") ? profile.socialLinks.telegram : `https://t.me/${profile.socialLinks.telegram.replace(/^@/, "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-xl bg-white/[0.02] hover:bg-white/[0.08] border border-white/[0.05] hover:border-white/10 text-white/60 hover:text-white transition-all duration-300 cursor-pointer"
                    title="Telegram Contact"
                  >
                    <Send size={14} />
                  </a>
                )}
                {!profile.socialLinks || Object.values(profile.socialLinks).every(v => !v) ? (
                  <span className="text-[10px] text-white/30 italic">No social links configured.</span>
                ) : null}
              </div>
            </div>
          </div>
          <div className="pt-4 mt-4 border-t border-white/[0.04] flex items-center justify-between text-[11px] text-white/30">
            <span>Server: Cloud Workspace Active</span>
            <span>v1.2.0</span>
          </div>
        </div>
      </div>
    </div>
  );
}
