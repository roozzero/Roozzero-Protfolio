import { Course, Student, Session, Assignment, DiscussionThread, Resource, Announcement, GradeRecord, Certificate, CalendarEvent, CourseSeason } from "../../types/teacher";

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: "super-admin" | "admin" | "teacher" | "student";
  status: "Active" | "Suspended" | "Pending";
  lastLogin: string;
  joinedDate: string;
}

export interface CourseRequest {
  id: string;
  teacherId: string;
  teacherName: string;
  type: "New Course Season" | "Reschedule Class" | "Additional Resources" | "Course Change";
  title: string;
  details: string;
  status: "Pending" | "Approved" | "Rejected" | "Revision Needed";
  notes?: string;
  date: string;
}

export interface Enrollment {
  id: string;
  studentId: string;
  studentName: string;
  courseId: string;
  courseTitle: string;
  seasonId: string;
  seasonName: string;
  enrollmentDate: string;
  paymentStatus: "Paid" | "Pending" | "Unpaid";
  courseStatus: "Enrolled" | "Completed" | "Dropped";
}

export interface Exam {
  id: string;
  title: string;
  courseId: string;
  courseTitle: string;
  dueDate: string;
  maxPoints: number;
  passRate: number; // e.g. 85
  avgScore: number;  // e.g. 78
  status: "Draft" | "Published";
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  username: string;
  role: string;
  action: string;
  module: string;
  status: "Success" | "Failed";
}

export interface RolePermission {
  role: string;
  permissions: Record<string, boolean>;
}
