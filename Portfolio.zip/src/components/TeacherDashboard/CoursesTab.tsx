import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  BookOpen,
  Plus,
  Users,
  Clock,
  CheckCircle2,
  AlertCircle,
  X,
  Play,
  Settings,
  Calendar,
  Layers,
  Edit2,
  Trash2,
  Check,
  AlertTriangle
} from "lucide-react";
import { Course, CourseSeason } from "../../types/teacher";

interface CoursesTabProps {
  courses: Course[];
  onToggleStatus: (courseId: string) => void;
  onNavigateToTab: (tab: string) => void;
  courseSeasons: CourseSeason[];
  onCreateSeason: (season: Omit<CourseSeason, "id">) => void;
  onUpdateSeason: (season: CourseSeason) => void;
  onDeleteSeason: (seasonId: string) => void;
  showCustomToast: (msg: string, type?: "info" | "success" | "warning") => void;
}

export default function CoursesTab({
  courses,
  onToggleStatus,
  onNavigateToTab,
  courseSeasons,
  onCreateSeason,
  onUpdateSeason,
  onDeleteSeason,
  showCustomToast
}: CoursesTabProps) {
  // Navigation between Active Courses and Course Seasons
  const [subTab, setSubTab] = useState<"catalog" | "seasons">("catalog");

  // Season Modals State
  const [showAddSeasonModal, setShowAddSeasonModal] = useState(false);
  const [editingSeason, setEditingSeason] = useState<CourseSeason | null>(null);

  // Form Fields for Season
  const [seasonName, setSeasonName] = useState("");
  const [relatedCourseId, setRelatedCourseId] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [maxCapacity, setMaxCapacity] = useState<number>(30);
  const [regStatus, setRegStatus] = useState<"Open" | "Closed" | "Not Available">("Not Available");
  const [notes, setNotes] = useState("");

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!seasonName || !relatedCourseId || !startDate || !endDate) {
      showCustomToast("Please fill in all required fields.", "warning");
      return;
    }

    const course = courses.find((c) => c.id === relatedCourseId);
    onCreateSeason({
      name: seasonName,
      courseId: relatedCourseId,
      courseTitle: course ? course.title : "Academy Course",
      startDate,
      endDate,
      maxCapacity,
      registrationStatus: regStatus,
      notes,
      status: "Pending Admin Approval"
    });

    // Reset Form
    setSeasonName("");
    setRelatedCourseId("");
    setStartDate("");
    setEndDate("");
    setMaxCapacity(30);
    setRegStatus("Not Available");
    setNotes("");
    setShowAddSeasonModal(false);
  };

  const handleEditOpen = (season: CourseSeason) => {
    setEditingSeason(season);
    setSeasonName(season.name);
    setRelatedCourseId(season.courseId);
    setStartDate(season.startDate);
    setEndDate(season.endDate);
    setMaxCapacity(season.maxCapacity);
    setRegStatus(season.registrationStatus);
    setNotes(season.notes);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSeason || !seasonName || !relatedCourseId || !startDate || !endDate) {
      showCustomToast("Please fill in all required fields.", "warning");
      return;
    }

    const course = courses.find((c) => c.id === relatedCourseId);
    onUpdateSeason({
      ...editingSeason,
      name: seasonName,
      courseId: relatedCourseId,
      courseTitle: course ? course.title : "Academy Course",
      startDate,
      endDate,
      maxCapacity,
      registrationStatus: regStatus,
      notes
    });

    // Reset and Close
    setEditingSeason(null);
    setSeasonName("");
    setRelatedCourseId("");
    setStartDate("");
    setEndDate("");
    setMaxCapacity(30);
    setRegStatus("Not Available");
    setNotes("");
  };

  return (
    <div className="space-y-6 animate-fade-in text-left">
      {/* SECTION HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.04] pb-5">
        <div className="space-y-1">
          <h2 className="font-sans text-xl font-bold text-white uppercase tracking-wider">
            Academy Courses
          </h2>
          <p className="font-sans text-xs text-white/40">
            Syllabus configurations, student enrollments, and academic course seasons.
          </p>
        </div>

        {/* Dynamic subtab control */}
        <div className="flex bg-[#08080c] border border-white/[0.05] p-1 rounded-xl self-start sm:self-center">
          <button
            onClick={() => setSubTab("catalog")}
            className={`px-4 py-2 text-xs font-bold font-sans rounded-lg transition-all cursor-pointer ${
              subTab === "catalog" ? "bg-indigo-600 text-white shadow-md" : "text-white/40 hover:text-white/70"
            }`}
          >
            Assigned Courses
          </button>
          <button
            onClick={() => setSubTab("seasons")}
            className={`px-4 py-2 text-xs font-bold font-sans rounded-lg transition-all cursor-pointer ${
              subTab === "seasons" ? "bg-indigo-600 text-white shadow-md" : "text-white/40 hover:text-white/70"
            }`}
          >
            Course Seasons
          </button>
        </div>
      </div>

      {subTab === "catalog" ? (
        /* ASSIGNED COURSES CATALOG PANEL */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((course) => (
            <div
              key={course.id}
              className="rounded-3xl bg-[#08080c]/90 border border-white/[0.05] hover:border-white/10 transition-all duration-300 overflow-hidden flex flex-col justify-between group"
            >
              {/* THUMBNAIL */}
              <div className="h-40 relative overflow-hidden bg-zinc-950">
                <img
                  src={course.image}
                  alt={course.title}
                  className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#08080c] via-transparent to-transparent" />
                <div className="absolute top-4 left-4">
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-mono font-bold bg-black/60 border border-white/10 text-white uppercase tracking-wider">
                    {course.code}
                  </span>
                </div>
                <div className="absolute top-4 right-4">
                  <button
                    onClick={() => onToggleStatus(course.id)}
                    className={`px-2.5 py-1 rounded-full text-[9px] font-sans font-extrabold tracking-widest uppercase cursor-pointer border transition-all ${
                      course.status === "Active"
                        ? "bg-emerald-500/10 border-emerald-500/25 text-emerald-400 hover:bg-emerald-500/20"
                        : "bg-white/[0.04] border-white/10 text-white/40 hover:bg-white/[0.08]"
                    }`}
                    title="Click to toggle status"
                  >
                    {course.status}
                  </button>
                </div>
              </div>

              {/* DETAIL */}
              <div className="p-5 space-y-4 flex-grow flex flex-col justify-between">
                <div className="space-y-1.5">
                  <h3 className="font-sans text-sm sm:text-base font-bold text-white tracking-tight leading-snug group-hover:text-indigo-400 transition-colors">
                    {course.title}
                  </h3>
                  <div className="flex items-center gap-4 text-white/40 text-xs font-sans">
                    <div className="flex items-center gap-1">
                      <Users size={12} />
                      <span>{course.studentsCount} Students Enrolled</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock size={12} />
                      <span>{course.sessionsCount} Sessions</span>
                    </div>
                  </div>
                </div>

                {/* PROGRESS BAR */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-[10px] font-mono font-semibold text-white/40">
                    <span>Syllabus Progress</span>
                    <span className="text-white/80">{course.progress}%</span>
                  </div>
                  <div className="w-full bg-white/[0.02] border border-white/[0.04] rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-indigo-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${course.progress}%` }}
                    />
                  </div>
                </div>

                {/* ACTION ROW */}
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/[0.03]">
                  <button
                    onClick={() => onNavigateToTab("students")}
                    className="flex items-center justify-center gap-1.5 py-2 rounded-xl bg-white/[0.02] hover:bg-white/[0.06] border border-white/10 hover:border-white/15 text-xs font-bold text-white transition-all cursor-pointer"
                  >
                    <Users size={12} className="text-indigo-400" />
                    <span>Enrolled</span>
                  </button>
                  <button
                    onClick={() => onNavigateToTab("schedule")}
                    className="flex items-center justify-center gap-1.5 py-2 rounded-xl bg-[#0a0a10] hover:bg-indigo-600 border border-white/[0.05] hover:border-indigo-500 text-xs font-bold text-white/80 hover:text-white transition-all cursor-pointer"
                  >
                    <Play size={10} className="text-emerald-400 fill-current" />
                    <span>Launch Session</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* COURSE SEASONS / COHORTS PANEL */
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
            <div className="space-y-1">
              <h3 className="font-sans text-base font-bold text-white">Academic Cohorts & Seasons</h3>
              <p className="text-xs text-white/40">View assigned course cohorts, timelines, and registration slots below. Creation and editing is managed by Administrators.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {courseSeasons.length === 0 ? (
              <div className="col-span-2 py-16 text-center bg-[#08080c]/50 border border-white/[0.05] rounded-3xl text-white/30 space-y-2 select-none">
                <Layers className="mx-auto text-white/15" size={28} />
                <p className="font-sans text-xs">No course seasons or cohorts assigned yet.</p>
              </div>
            ) : (
              courseSeasons.map((season) => {
                const isPending = season.status === "Pending Admin Approval";
                return (
                  <div
                    key={season.id}
                    className="p-5 rounded-3xl bg-[#08080c]/90 border border-white/[0.05] hover:border-white/10 transition-all flex flex-col justify-between gap-4"
                  >
                    <div className="space-y-3.5 text-left text-xs">
                      {/* Badge / Status row */}
                      <div className="flex items-center justify-between">
                        <span className="px-2.5 py-0.5 rounded text-[9px] font-mono font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/10">
                          {season.courseTitle}
                        </span>
                        
                        <div className="flex items-center gap-2">
                          {isPending ? (
                            <span className="px-2 py-0.5 rounded text-[9px] font-sans font-extrabold uppercase tracking-wide bg-amber-500/10 border border-amber-500/20 text-amber-400 animate-pulse">
                              Pending Admin Approval
                            </span>
                          ) : season.status === "Active" ? (
                            <span className="px-2 py-0.5 rounded text-[9px] font-sans font-extrabold uppercase tracking-wide bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                              Active
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded text-[9px] font-sans font-extrabold uppercase tracking-wide bg-white/[0.04] border border-white/10 text-white/35">
                              Cancelled
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="space-y-1">
                        <h4 className="font-sans text-base font-bold text-white tracking-tight">{season.name}</h4>
                        <p className="text-[11px] text-white/30 leading-relaxed font-sans">{season.notes || "No extra specifications provided."}</p>
                      </div>

                      {/* Info matrix */}
                      <div className="grid grid-cols-2 gap-3 p-3 bg-white/[0.01] border border-white/[0.03] rounded-2xl font-mono text-[10px] text-white/50">
                        <div>
                          <span className="block text-[8px] uppercase font-bold text-white/30 mb-0.5">Timeline</span>
                          <span className="text-white/80">{season.startDate} to {season.endDate}</span>
                        </div>
                        <div>
                          <span className="block text-[8px] uppercase font-bold text-white/30 mb-0.5">Max Capacity</span>
                          <span className="text-white/80">{season.maxCapacity} Seats</span>
                        </div>
                        <div>
                          <span className="block text-[8px] uppercase font-bold text-white/30 mb-0.5">Registration Status</span>
                          <span className={`font-bold uppercase ${
                            season.registrationStatus === "Open" ? "text-emerald-400" : "text-white/40"
                          }`}>{season.registrationStatus}</span>
                        </div>
                        <div>
                          <span className="block text-[8px] uppercase font-bold text-white/30 mb-0.5">Public State</span>
                          <span className="text-white/80">{isPending ? "Hidden from Students" : "Publicly Visible"}</span>
                        </div>
                      </div>
                    </div>

                    {/* Operational Row */}
                    <div className="flex items-center justify-between border-t border-white/[0.03] pt-3.5 select-none">
                      {isPending ? (
                        <span className="text-[10px] text-amber-400 font-sans font-semibold flex items-center gap-1">
                          <AlertCircle size={11} /> Pending Admin Approval
                        </span>
                      ) : (
                        <span className="text-[10px] text-emerald-400/80 font-sans font-semibold flex items-center gap-1">
                          <CheckCircle2 size={11} /> Registration Live!
                        </span>
                      )}

                      <span className="text-[9px] text-white/20 font-sans font-bold uppercase tracking-widest bg-white/[0.01] border border-white/[0.03] px-2 py-1 rounded-lg select-none">
                        Read-Only
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

    </div>
  );
}
