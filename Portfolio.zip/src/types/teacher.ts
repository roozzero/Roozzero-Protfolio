export interface Course {
  id: string;
  title: string;
  code: string;
  studentsCount: number;
  sessionsCount: number;
  progress: number;
  status: "Active" | "Finished";
  image: string;
}

export interface Student {
  id: string;
  name: string;
  email: string;
  phone: string;
  courseId: string;
  courseTitle: string;
  progress: number;
  attendance: number;
  avgGrade: number;
  status: "Active" | "Inactive";
  joinedDate: string;
}

export interface Session {
  id: string;
  courseId: string;
  courseTitle: string;
  title: string;
  date: string;
  time: string;
  duration: string;
  link: string;
  status: "Scheduled" | "Completed" | "Cancelled";
  studentCount: number;
}

export interface Submission {
  id: string;
  studentId: string;
  studentName: string;
  submittedAt: string;
  githubUrl: string;
  notes: string;
  status: "Submitted" | "Graded";
  grade: number | null;
  feedback: string | null;
  correctedFileName?: string;
}

export interface Assignment {
  id: string;
  courseId: string;
  courseTitle: string;
  title: string;
  description: string;
  publishDate: string;
  dueDate: string;
  maxPoints: number;
  status: "Draft" | "Published";
  submissions: Submission[];
}

export interface DiscussionThread {
  id: string;
  courseId: string;
  courseTitle: string;
  studentName: string;
  title: string;
  text: string;
  time: string;
  status: "New" | "Under Review" | "Replied" | "Closed";
  replies: {
    id: string;
    sender: string;
    role: "Instructor" | "Student";
    time: string;
    text: string;
  }[];
}

export interface Resource {
  id: string;
  title: string;
  courseId: string;
  courseTitle: string;
  fileType: "pdf" | "zip" | "doc" | "code" | "video";
  fileSize: string;
  uploadedAt: string;
  description?: string;
  relatedSessionId?: string;
  relatedSessionTitle?: string;
  visibility?: "Visible" | "Hidden";
  displayOrder?: number;
  fileName?: string;
}

export interface Announcement {
  id: string;
  title: string;
  description: string;
  courseId: string;
  courseTitle: string;
  audience: string;
  publishedAt: string;
  status: "Draft" | "Published";
}

export interface GradeRecord {
  id: string;
  studentId: string;
  studentName: string;
  courseId: string;
  courseTitle: string;
  assignmentId: string;
  assignmentTitle: string;
  score: number;
  maxPoints: number;
  letterGrade: string;
  publishedDate: string;
}

export interface Certificate {
  id: string;
  studentId: string;
  studentName: string;
  courseId: string;
  courseTitle: string;
  gpa: number;
  status: "Draft" | "Signed by Instructor" | "Waiting for Admin Approval" | "Approved" | "Rejected";
  issueDate?: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  date: string;
  type: "Class" | "Exam" | "Deadline" | "Office Hours" | "Holiday";
  courseId?: string;
  time: string;
}

export interface TeacherProfile {
  name: string;
  email: string;
  phone: string;
  department: string;
  bio: string;
  photo: string;
  status: "online" | "offline";
  theme: "dark" | "light" | "system";
  titlePrefix?: "Dr." | "Engineer" | "Mr." | "Ms." | "";
  specialization?: string;
  socialLinks?: {
    github?: string;
    twitter?: string;
    instagram?: string;
    linkedin?: string;
    telegram?: string;
  };
}

export interface CourseSeason {
  id: string;
  name: string;
  courseId: string;
  courseTitle: string;
  startDate: string;
  endDate: string;
  maxCapacity: number;
  registrationStatus: "Open" | "Closed" | "Not Available";
  notes: string;
  status: "Pending Admin Approval" | "Active" | "Cancelled";
}

