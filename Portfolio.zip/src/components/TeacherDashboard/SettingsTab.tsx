import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Settings,
  User,
  Shield,
  Palette,
  Lock,
  Sparkles,
  Camera,
  Check,
  AlertTriangle,
  ClipboardList,
  Eye,
  EyeOff,
  X,
  Github,
  Twitter,
  Instagram,
  Linkedin,
  Send,
  Share2,
  ChevronDown,
  Moon,
  Sun,
  Monitor
} from "lucide-react";
import { TeacherProfile } from "../../types/teacher";

interface SettingsTabProps {
  profile: TeacherProfile;
  onSaveProfile: (updated: TeacherProfile) => void;
  showCustomToast: (msg: string, type?: "info" | "success" | "warning") => void;
}

export default function SettingsTab({
  profile,
  onSaveProfile,
  showCustomToast
}: SettingsTabProps) {
  const [activeSubTab, setActiveSubTab] = useState<"Account" | "Profile" | "Social" | "Appearance" | "Security">("Account");

  // Split name for First & Last name mirroring
  const getSplitName = () => {
    const parts = profile.name.split(" ");
    return {
      first: parts[0] || "Sarah",
      last: parts.slice(1).join(" ") || "Vance"
    };
  };

  const initialSplit = getSplitName();

  // Phone number parsing to get only the 10-digit Iranian mobile format if possible
  const getInitialPhone = (rawPhone: string) => {
    const cleaned = rawPhone.replace(/\D/g, "");
    if (cleaned.endsWith("98") && cleaned.length > 2) {
      const remaining = cleaned.slice(-10);
      if (remaining.startsWith("9") && remaining.length === 10) {
        return remaining;
      }
    }
    if (cleaned.length === 10 && cleaned.startsWith("9")) {
      return cleaned;
    }
    const match = cleaned.match(/9\d{9}$/);
    return match ? match[0] : "9123456789";
  };

  // --- FORM STATES ---
  const [firstName, setFirstName] = useState(initialSplit.first);
  const [lastName, setLastName] = useState(initialSplit.last);
  const [username, setUsername] = useState("sarah_vance_phd");
  const [email, setEmail] = useState(profile.email);
  const [phone, setPhone] = useState(() => getInitialPhone(profile.phone));
  const [titlePrefix, setTitlePrefix] = useState<"Dr." | "Engineer" | "Mr." | "Ms." | "">(profile.titlePrefix || "");
  const [specialization, setSpecialization] = useState(profile.specialization || "");
  const [isTitleDropdownOpen, setIsTitleDropdownOpen] = useState(false);
  const titleOptions: ("Dr." | "Engineer" | "Mr." | "Ms.")[] = ["Dr.", "Engineer", "Mr.", "Ms."];

  const [department, setDepartment] = useState(profile.department);
  const [bio, setBio] = useState(profile.bio);
  const [photo, setPhoto] = useState(profile.photo);
  const [theme, setTheme] = useState(profile.theme);

  // Social link state variables
  const [github, setGithub] = useState(profile.socialLinks?.github || "");
  const [twitter, setTwitter] = useState(profile.socialLinks?.twitter || "");
  const [instagram, setInstagram] = useState(profile.socialLinks?.instagram || "");
  const [linkedin, setLinkedin] = useState(profile.socialLinks?.linkedin || "");
  const [telegram, setTelegram] = useState(profile.socialLinks?.telegram || "");

  // Password fields
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPass, setShowPass] = useState(false);

  // Errors state for inline validation mirroring
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const validateSocialUrlOrUsername = (platform: string, val: string): string => {
    const trimmed = val.trim();
    if (!trimmed) return "";
    
    if (platform === "github") {
      const isUrl = trimmed.includes("github.com/");
      if (isUrl) {
        if (!/^(https?:\/\/)?(www\.)?github\.com\/[a-zA-Z0-9\-_\.\/]+$/.test(trimmed)) {
          return "Please enter a valid GitHub profile URL.";
        }
      } else {
        if (!/^[a-zA-Z0-9\-]+$/.test(trimmed)) {
          return "GitHub username can only contain letters, numbers, and hyphens.";
        }
      }
    }
    
    if (platform === "twitter") {
      const isUrl = trimmed.includes("twitter.com/") || trimmed.includes("x.com/");
      if (isUrl) {
        if (!/^(https?:\/\/)?(www\.)?(twitter|x)\.com\/[a-zA-Z0-9\-_\.\/]+$/.test(trimmed)) {
          return "Please enter a valid X (Twitter) profile URL.";
        }
      } else {
        const cleaned = trimmed.startsWith("@") ? trimmed.slice(1) : trimmed;
        if (!/^[a-zA-Z0-9_]+$/.test(cleaned)) {
          return "X (Twitter) username can only contain letters, numbers, and underscores.";
        }
      }
    }

    if (platform === "instagram") {
      const isUrl = trimmed.includes("instagram.com/");
      if (isUrl) {
        if (!/^(https?:\/\/)?(www\.)?instagram\.com\/[a-zA-Z0-9\-_\.\/]+$/.test(trimmed)) {
          return "Please enter a valid Instagram profile URL.";
        }
      } else {
        const cleaned = trimmed.startsWith("@") ? trimmed.slice(1) : trimmed;
        if (!/^[a-zA-Z0-9_\.]+$/.test(cleaned)) {
          return "Instagram username can only contain letters, numbers, underscores, and periods.";
        }
      }
    }

    if (platform === "linkedin") {
      const isUrl = trimmed.includes("linkedin.com/");
      if (isUrl) {
        if (!/^(https?:\/\/)?(www\.)?linkedin\.com\/[a-zA-Z0-9\-_\.\/]+$/.test(trimmed)) {
          return "Please enter a valid LinkedIn profile URL.";
        }
      } else {
        if (!/^[a-zA-Z0-9\-_\/]+$/.test(trimmed)) {
          return "LinkedIn username can only contain letters, numbers, hyphens, and underscores.";
        }
      }
    }

    if (platform === "telegram") {
      const isUrl = trimmed.includes("t.me/") || trimmed.includes("telegram.me/");
      if (isUrl) {
        if (!/^(https?:\/\/)?(www\.)?(t\.me|telegram\.me)\/[a-zA-Z0-9\-_\.\/]+$/.test(trimmed)) {
          return "Please enter a valid Telegram profile URL.";
        }
      } else {
        const cleaned = trimmed.startsWith("@") ? trimmed.slice(1) : trimmed;
        if (!/^[a-zA-Z0-9_]{5,}$/.test(cleaned)) {
          return "Telegram username must be at least 5 characters (letters, numbers, underscores).";
        }
      }
    }

    return "";
  };

  const validateForm = (): boolean => {
    const tempErrors: { [key: string]: string } = {};
    
    if (activeSubTab === "Account") {
      if (!firstName.trim()) tempErrors.firstName = "First name is required.";
      if (!lastName.trim()) tempErrors.lastName = "Last name is required.";
      if (!username.trim()) tempErrors.username = "Username is required.";
      if (!email.trim()) {
        tempErrors.email = "Email address is required.";
      } else if (!/\S+@\S+\.\S+/.test(email)) {
        tempErrors.email = "Email address is invalid.";
      }
      if (!phone.trim()) {
        tempErrors.phone = "Telephone number is required.";
      } else if (!/^9\d{9}$/.test(phone.trim())) {
        tempErrors.phone = "Iranian mobile number must start with 9 and contain exactly 10 digits (e.g., 9123456789).";
      }
      if (!specialization.trim()) {
        tempErrors.specialization = "Primary specialization is required.";
      } else if (specialization.length > 100) {
        tempErrors.specialization = "Primary specialization cannot exceed 100 characters.";
      }
    } else if (activeSubTab === "Social") {
      const ghErr = validateSocialUrlOrUsername("github", github);
      if (ghErr) tempErrors.github = ghErr;
      const twErr = validateSocialUrlOrUsername("twitter", twitter);
      if (twErr) tempErrors.twitter = twErr;
      const igErr = validateSocialUrlOrUsername("instagram", instagram);
      if (igErr) tempErrors.instagram = igErr;
      const liErr = validateSocialUrlOrUsername("linkedin", linkedin);
      if (liErr) tempErrors.linkedin = liErr;
      const tgErr = validateSocialUrlOrUsername("telegram", telegram);
      if (tgErr) tempErrors.telegram = tgErr;
    } else if (activeSubTab === "Security") {
      if (newPassword || confirmPassword || currentPassword) {
        if (!currentPassword) {
          tempErrors.currentPassword = "Current password is required to set a new password.";
        }
        if (newPassword.length < 6) {
          tempErrors.newPassword = "New password must be at least 6 characters long.";
        }
        if (newPassword !== confirmPassword) {
          tempErrors.confirmPassword = "Passwords do not match.";
        }
      }
    }

    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleGlobalSave = () => {
    if (!validateForm()) {
      showCustomToast("Please resolve outstanding form validation errors first.", "warning");
      return;
    }

    // Save profile logic
    onSaveProfile({
      name: `${firstName.trim()} ${lastName.trim()}`,
      email: email.trim(),
      phone: `+98 ${phone.trim()}`,
      department: department.trim(),
      bio: bio.trim(),
      photo,
      status: "online",
      theme,
      titlePrefix,
      specialization: specialization.trim(),
      socialLinks: {
        github: github.trim(),
        twitter: twitter.trim(),
        instagram: instagram.trim(),
        linkedin: linkedin.trim(),
        telegram: telegram.trim()
      }
    });

    showCustomToast("All configuration modifications persisted successfully!", "success");

    // Clear sensitive password inputs
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  };

  const handleGlobalCancel = () => {
    const freshSplit = getSplitName();
    setFirstName(freshSplit.first);
    setLastName(freshSplit.last);
    setEmail(profile.email);
    setPhone(getInitialPhone(profile.phone));
    setTheme(profile.theme);
    setTitlePrefix(profile.titlePrefix || "");
    setSpecialization(profile.specialization || "");
    setDepartment(profile.department);
    setBio(profile.bio);
    setPhoto(profile.photo);
    setGithub(profile.socialLinks?.github || "");
    setTwitter(profile.socialLinks?.twitter || "");
    setInstagram(profile.socialLinks?.instagram || "");
    setLinkedin(profile.socialLinks?.linkedin || "");
    setTelegram(profile.socialLinks?.telegram || "");
    setErrors({});
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
    showCustomToast("Configuration forms reverted to baseline settings.", "info");
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        if (uploadEvent.target?.result) {
          setPhoto(uploadEvent.target.result as string);
          showCustomToast("Faculty photo updated successfully! (Local Mock Preview)", "success");
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in text-left font-sans">
      {/* SECTION HEADER */}
      <div className="space-y-1.5 text-left border-b border-white/[0.04] pb-5">
        <span className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider block font-mono">Academic Portal Workspace</span>
        <h2 className="font-sans text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
          <Settings className="text-indigo-400" size={24} />
          <span>Portal Settings</span>
        </h2>
        <p className="text-xs text-white/40 max-w-2xl leading-relaxed">
          Redesigned dashboard settings hub. Manage your secure instructor account, edit your academy profile metadata, configure portal aesthetics, and review cryptographic keys.
        </p>
      </div>

      {/* Sub-tab Navigation */}
      <div className="sticky top-0 z-20 backdrop-blur-md bg-[#040407]/80 py-3 border-b border-white/[0.04] overflow-x-auto scrollbar-none flex items-center gap-1.5 transition-all select-none">
        {[
          { id: "Account", label: "Account", icon: User },
          { id: "Profile", label: "Profile", icon: ClipboardList },
          { id: "Social", label: "Social Links", icon: Share2 },
          { id: "Appearance", label: "Appearance", icon: Palette },
          { id: "Security", label: "Security", icon: Shield }
        ].map((tab) => {
          const isActive = activeSubTab === tab.id;
          const TabIcon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveSubTab(tab.id as any);
                setErrors({});
              }}
              className="relative px-4 py-2.5 rounded-xl text-xs font-bold tracking-wide transition-all shrink-0 cursor-pointer flex items-center gap-2"
              style={{ WebkitTapHighlightColor: "transparent" }}
            >
              {isActive && (
                <motion.div
                  layoutId="activeTeacherSettingsTabIndicator"
                  className="absolute inset-0 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-600/20"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                />
              )}
              <TabIcon size={14} className={`relative z-10 ${isActive ? "text-white" : "text-white/40"}`} />
              <span className={`relative z-10 transition-colors duration-200 ${isActive ? "text-white" : "text-white/40 hover:text-white/80"}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>

      {/* Tab Content Panels */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeSubTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
          className="space-y-6"
        >
          {/* ACCOUNT TAB */}
          {activeSubTab === "Account" && (
            <div className="max-w-3xl mx-auto bg-[#08080c] border border-white/[0.06] rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl relative overflow-hidden text-left font-sans">
              <div className="absolute -right-20 -top-20 w-44 h-44 bg-indigo-500/[0.02] rounded-full blur-3xl" />
              
              <div className="border-b border-white/[0.05] pb-4 flex items-center justify-between">
                <div className="space-y-1">
                  <h3 className="font-sans text-base font-black text-white">Instructor Account Information</h3>
                  <p className="text-xs text-white/40">Update your primary registration profile identifiers</p>
                </div>
                <span className="text-[9px] font-bold uppercase tracking-wider text-indigo-400 bg-indigo-500/5 px-2.5 py-1 rounded-full border border-indigo-500/10 font-mono">
                  Verified Instructor
                </span>
              </div>

              <div className="space-y-5">
                {/* Title (Prefix) Dropdown */}
                <div className="space-y-1.5 relative z-30">
                  <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">Title Prefix</label>
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => setIsTitleDropdownOpen(!isTitleDropdownOpen)}
                      className="w-full bg-white/[0.01] hover:bg-white/[0.02] border border-white/10 rounded-2xl px-4 py-3.5 text-xs text-white text-left focus:outline-none focus:border-indigo-500/50 flex items-center justify-between cursor-pointer select-none"
                    >
                      <span>{titlePrefix || "Select Title Prefix"}</span>
                      <ChevronDown size={14} className={`text-white/40 transition-transform ${isTitleDropdownOpen ? "rotate-180" : ""}`} />
                    </button>
                    <AnimatePresence>
                      {isTitleDropdownOpen && (
                        <>
                          <div className="fixed inset-0 z-40" onClick={() => setIsTitleDropdownOpen(false)} />
                          <motion.div
                            initial={{ opacity: 0, y: 5 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 5 }}
                            transition={{ duration: 0.15 }}
                            className="absolute left-0 right-0 mt-2 bg-[#0c0c14] border border-white/10 rounded-2xl shadow-xl z-50 overflow-hidden divide-y divide-white/5"
                          >
                            {titleOptions.map((opt) => (
                              <button
                                key={opt}
                                type="button"
                                onClick={() => {
                                  setTitlePrefix(opt);
                                  setIsTitleDropdownOpen(false);
                                }}
                                className="w-full text-left px-4 py-3 text-xs text-white/80 hover:text-white hover:bg-white/[0.04] transition-colors flex items-center justify-between cursor-pointer"
                              >
                                <span>{opt}</span>
                                {titlePrefix === opt && <Check size={12} className="text-indigo-400" />}
                              </button>
                            ))}
                          </motion.div>
                        </>
                      )}
                    </AnimatePresence>
                  </div>
                </div>

                {/* Name Group */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* First Name */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">First Name</label>
                    <input
                      type="text"
                      required
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      className={`w-full bg-white/[0.01] hover:bg-white/[0.02] border rounded-2xl px-4 py-3.5 text-xs text-white placeholder-white/30 focus:outline-none transition-all ${
                        errors.firstName ? "border-rose-500/40 focus:border-rose-500" : "border-white/10 focus:border-indigo-500/50"
                      }`}
                    />
                    {errors.firstName && (
                      <p className="text-[10px] text-rose-400 font-sans mt-1">⚠️ {errors.firstName}</p>
                    )}
                  </div>

                  {/* Last Name */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">Last Name</label>
                    <input
                      type="text"
                      required
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      className={`w-full bg-white/[0.01] hover:bg-white/[0.02] border rounded-2xl px-4 py-3.5 text-xs text-white placeholder-white/30 focus:outline-none transition-all ${
                        errors.lastName ? "border-rose-500/40 focus:border-rose-500" : "border-white/10 focus:border-indigo-500/50"
                      }`}
                    />
                    {errors.lastName && (
                      <p className="text-[10px] text-rose-400 font-sans mt-1">⚠️ {errors.lastName}</p>
                    )}
                  </div>
                </div>

                {/* Primary Specialization */}
                <div className="space-y-1.5">
                  <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">Primary Specialization</label>
                  <input
                    type="text"
                    maxLength={100}
                    placeholder="e.g. Full Stack Developer, DevOps Engineer, UI/UX Designer"
                    value={specialization}
                    onChange={(e) => {
                      setSpecialization(e.target.value);
                      if (errors.specialization) setErrors(prev => { const n = {...prev}; delete n.specialization; return n; });
                    }}
                    className={`w-full bg-white/[0.01] hover:bg-white/[0.02] border rounded-2xl px-4 py-3.5 text-xs text-white placeholder-white/30 focus:outline-none transition-all ${
                      errors.specialization ? "border-rose-500/40 focus:border-rose-500" : "border-white/10 focus:border-indigo-500/50"
                    }`}
                  />
                  {errors.specialization && (
                    <p className="text-[10px] text-rose-400 font-sans mt-1">⚠️ {errors.specialization}</p>
                  )}
                </div>

                {/* Username Field with 30-Day Policy Logic */}
                <div className="space-y-2 bg-[#0c0c14]/50 border border-white/[0.03] p-4 rounded-2xl">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">Username Handle</label>
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-500/5 text-amber-400 border border-amber-500/10">
                      <Lock size={10} /> Locked for 30 Days
                    </span>
                  </div>
                  <input
                    type="text"
                    disabled
                    value={username}
                    className="w-full bg-transparent border border-white/[0.03] rounded-2xl px-4 py-3.5 text-xs text-white/40 cursor-not-allowed focus:outline-none"
                  />
                  <p className="text-[10px] text-white/30 leading-relaxed font-sans">
                    Usernames can only be updated once every 30 days. To change your verified institutional handle, submit a claim directly through academy support.
                  </p>
                </div>

                {/* Email Address */}
                <div className="space-y-1.5">
                  <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">Email Address</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={`w-full bg-white/[0.01] hover:bg-white/[0.02] border rounded-2xl px-4 py-3.5 text-xs text-white placeholder-white/30 focus:outline-none transition-all ${
                      errors.email ? "border-rose-500/40 focus:border-rose-500" : "border-white/10 focus:border-indigo-500/50"
                    }`}
                  />
                  {errors.email && (
                    <p className="text-[10px] text-rose-400 font-sans mt-1">⚠️ {errors.email}</p>
                  )}
                </div>

                {/* Phone & Department */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">Telephone Number</label>
                    <div className={`flex items-center bg-white/[0.01] hover:bg-white/[0.02] border rounded-2xl overflow-hidden transition-all ${
                      errors.phone ? "border-rose-500/40 focus-within:border-rose-500" : "border-white/10 focus-within:border-indigo-500/50"
                    }`}>
                      <div className="px-4 py-3.5 bg-white/[0.02] border-r border-white/5 text-xs text-white/40 font-semibold font-mono select-none">
                        +98
                      </div>
                      <input
                        type="tel"
                        maxLength={10}
                        placeholder="9123456789"
                        value={phone}
                        onChange={(e) => {
                          const digits = e.target.value.replace(/\D/g, "");
                          setPhone(digits);
                          if (errors.phone) setErrors(prev => { const n = {...prev}; delete n.phone; return n; });
                        }}
                        className="w-full bg-transparent px-4 py-3.5 text-xs text-white placeholder-white/20 focus:outline-none"
                      />
                    </div>
                    {errors.phone && (
                      <p className="text-[10px] text-rose-400 font-sans mt-1">⚠️ {errors.phone}</p>
                    )}
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">Academic Department</label>
                    <input
                      type="text"
                      value={department}
                      onChange={(e) => setDepartment(e.target.value)}
                      className="w-full bg-white/[0.01] hover:bg-white/[0.02] border border-white/10 rounded-2xl px-4 py-3.5 text-xs text-white focus:outline-none focus:border-indigo-500/50"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* PROFILE TAB */}
          {activeSubTab === "Profile" && (
            <div className="max-w-3xl mx-auto bg-[#08080c] border border-white/[0.06] rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl relative overflow-hidden text-left font-sans">
              <div className="border-b border-white/[0.05] pb-4">
                <h3 className="font-sans text-base font-black text-white">Public Profile Credentials</h3>
                <p className="text-xs text-white/40">These specifications are shared with students inside course catalogs</p>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-6 p-4 bg-white/[0.01] border border-white/[0.03] rounded-3xl">
                <div className="relative h-20 w-20 rounded-full overflow-hidden border border-white/15 shrink-0 group select-none">
                  <img src={photo} alt={firstName} className="h-full w-full object-cover group-hover:scale-105 transition-transform" />
                  <label className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-white transition-opacity cursor-pointer">
                    <Camera size={16} />
                    <span className="text-[8px] font-bold mt-1 uppercase font-sans">Edit</span>
                    <input type="file" onChange={handlePhotoUpload} className="hidden" accept="image/*" />
                  </label>
                </div>
                <div className="space-y-1.5 text-center sm:text-left">
                  <span className="block font-sans text-xs font-extrabold uppercase tracking-widest text-indigo-400">Faculty Identity Photo</span>
                  <p className="text-[11px] text-white/40 max-w-sm leading-relaxed">
                    Choose a professional avatar image. Recommended specs: square aspect ratio, minimum 400x400px, PNG/JPG formats.
                  </p>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">Professional Biography</label>
                <textarea
                  rows={4}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full bg-white/[0.01] hover:bg-white/[0.02] border border-white/10 rounded-2xl p-4 text-xs text-white placeholder-white/20 focus:outline-none focus:border-indigo-500/50"
                  placeholder="Sum up your educational credentials, research publications, or industry awards..."
                />
              </div>
            </div>
          )}

          {/* SOCIAL LINKS TAB */}
          {activeSubTab === "Social" && (
            <div className="max-w-3xl mx-auto bg-[#08080c] border border-white/[0.06] rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl relative overflow-hidden text-left font-sans">
              <div className="border-b border-white/[0.05] pb-4">
                <h3 className="font-sans text-base font-black text-white">Social Media Connections</h3>
                <p className="text-xs text-white/40">Provide handles or full URLs. These are shown publicly on your profile.</p>
              </div>

              <div className="space-y-4">
                {/* GitHub */}
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <Github className="text-indigo-400" size={16} />
                    <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">GitHub Profile</label>
                  </div>
                  <input
                    type="text"
                    value={github}
                    onChange={(e) => {
                      setGithub(e.target.value);
                      if (errors.github) setErrors(prev => { const n = {...prev}; delete n.github; return n; });
                    }}
                    placeholder="Username or profile URL (e.g. github.com/username)"
                    className={`w-full bg-white/[0.01] hover:bg-white/[0.02] border rounded-2xl px-4 py-3 text-xs text-white placeholder-white/20 focus:outline-none transition-all ${
                      errors.github ? "border-rose-500/40 focus:border-rose-500" : "border-white/10 focus:border-indigo-500/50"
                    }`}
                  />
                  {errors.github && (
                    <p className="text-[10px] text-rose-400 font-sans mt-1">⚠️ {errors.github}</p>
                  )}
                </div>

                {/* X / Twitter */}
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <Twitter className="text-indigo-400" size={16} />
                    <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">X (Twitter) Profile</label>
                  </div>
                  <input
                    type="text"
                    value={twitter}
                    onChange={(e) => {
                      setTwitter(e.target.value);
                      if (errors.twitter) setErrors(prev => { const n = {...prev}; delete n.twitter; return n; });
                    }}
                    placeholder="Username or profile URL (e.g. x.com/username)"
                    className={`w-full bg-white/[0.01] hover:bg-white/[0.02] border rounded-2xl px-4 py-3 text-xs text-white placeholder-white/20 focus:outline-none transition-all ${
                      errors.twitter ? "border-rose-500/40 focus:border-rose-500" : "border-white/10 focus:border-indigo-500/50"
                    }`}
                  />
                  {errors.twitter && (
                    <p className="text-[10px] text-rose-400 font-sans mt-1">⚠️ {errors.twitter}</p>
                  )}
                </div>

                {/* Instagram */}
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <Instagram className="text-indigo-400" size={16} />
                    <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">Instagram Profile</label>
                  </div>
                  <input
                    type="text"
                    value={instagram}
                    onChange={(e) => {
                      setInstagram(e.target.value);
                      if (errors.instagram) setErrors(prev => { const n = {...prev}; delete n.instagram; return n; });
                    }}
                    placeholder="Username or profile URL (e.g. instagram.com/username)"
                    className={`w-full bg-white/[0.01] hover:bg-white/[0.02] border rounded-2xl px-4 py-3 text-xs text-white placeholder-white/20 focus:outline-none transition-all ${
                      errors.instagram ? "border-rose-500/40 focus:border-rose-500" : "border-white/10 focus:border-indigo-500/50"
                    }`}
                  />
                  {errors.instagram && (
                    <p className="text-[10px] text-rose-400 font-sans mt-1">⚠️ {errors.instagram}</p>
                  )}
                </div>

                {/* LinkedIn */}
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <Linkedin className="text-indigo-400" size={16} />
                    <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">LinkedIn Profile</label>
                  </div>
                  <input
                    type="text"
                    value={linkedin}
                    onChange={(e) => {
                      setLinkedin(e.target.value);
                      if (errors.linkedin) setErrors(prev => { const n = {...prev}; delete n.linkedin; return n; });
                    }}
                    placeholder="Username or profile URL (e.g. linkedin.com/in/username)"
                    className={`w-full bg-white/[0.01] hover:bg-white/[0.02] border rounded-2xl px-4 py-3 text-xs text-white placeholder-white/20 focus:outline-none transition-all ${
                      errors.linkedin ? "border-rose-500/40 focus:border-rose-500" : "border-white/10 focus:border-indigo-500/50"
                    }`}
                  />
                  {errors.linkedin && (
                    <p className="text-[10px] text-rose-400 font-sans mt-1">⚠️ {errors.linkedin}</p>
                  )}
                </div>

                {/* Telegram */}
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <Send className="text-indigo-400" size={16} />
                    <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">Telegram Handle</label>
                  </div>
                  <input
                    type="text"
                    value={telegram}
                    onChange={(e) => {
                      setTelegram(e.target.value);
                      if (errors.telegram) setErrors(prev => { const n = {...prev}; delete n.telegram; return n; });
                    }}
                    placeholder="Username or t.me/ link (e.g. t.me/username)"
                    className={`w-full bg-white/[0.01] hover:bg-white/[0.02] border rounded-2xl px-4 py-3 text-xs text-white placeholder-white/20 focus:outline-none transition-all ${
                      errors.telegram ? "border-rose-500/40 focus:border-rose-500" : "border-white/10 focus:border-indigo-500/50"
                    }`}
                  />
                  {errors.telegram && (
                    <p className="text-[10px] text-rose-400 font-sans mt-1">⚠️ {errors.telegram}</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* APPEARANCE TAB */}
          {activeSubTab === "Appearance" && (
            <div className="max-w-3xl mx-auto bg-[#08080c] border border-white/[0.06] rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl relative overflow-hidden text-left font-sans">
              <div className="border-b border-white/[0.05] pb-4">
                <h3 className="font-sans text-base font-black text-white">Portal Aesthetics</h3>
                <p className="text-xs text-white/40">Configure theme environments and layout options</p>
              </div>

              <div className="space-y-5">
                <div className="space-y-3">
                  <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">Select Theme Mode</label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {[
                      { id: "dark" as const, label: "Dark Theme", desc: "Premium obsidian black aesthetic", icon: Moon },
                      { id: "light" as const, label: "Light Theme", desc: "Clean and crisp style", icon: Sun },
                      { id: "system" as const, label: "System Sync", desc: "Matches operating system appearance", icon: Monitor }
                    ].map((opt) => {
                      const isSelected = theme === opt.id;
                      const IconComp = opt.icon;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => setTheme(opt.id)}
                          className={`relative p-5 rounded-2xl bg-white/[0.01] hover:bg-white/[0.03] border transition-all text-left flex flex-col justify-between gap-4 cursor-pointer min-h-[140px] group ${
                            isSelected ? "border-indigo-500/30 bg-indigo-500/[0.03]" : "border-white/[0.04]"
                          }`}
                        >
                          <div className="flex items-center justify-between w-full">
                            <div className={`p-2.5 rounded-xl border transition-all ${
                              isSelected ? "bg-indigo-500/10 border-indigo-500/20 text-indigo-400" : "bg-white/[0.01] border-white/[0.03] text-white/40 group-hover:text-white/60"
                            }`}>
                              <IconComp size={16} />
                            </div>
                            <div className={`h-4 w-4 rounded-full border flex items-center justify-center transition-all ${
                              isSelected ? "border-indigo-500 bg-indigo-600" : "border-white/20"
                            }`}>
                              {isSelected && <div className="h-1.5 w-1.5 rounded-full bg-white" />}
                            </div>
                          </div>
                          <div className="space-y-1 text-left">
                            <h4 className="font-sans text-xs font-bold text-white tracking-wide">{opt.label}</h4>
                            <p className="font-sans text-[10px] text-white/40 leading-normal">{opt.desc}</p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECURITY TAB */}
          {activeSubTab === "Security" && (
            <div className="max-w-3xl mx-auto bg-[#08080c] border border-white/[0.06] rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl relative overflow-hidden text-left font-sans">
              <div className="border-b border-white/[0.05] pb-4">
                <h3 className="font-sans text-base font-black text-white">Cryptographic Security</h3>
                <p className="text-xs text-white/40">Adjust sign-in passwords and cryptographic security keys</p>
              </div>

              <div className="space-y-5">
                <div className="p-4 bg-amber-500/5 border border-amber-500/15 rounded-2xl flex items-start gap-3">
                  <AlertTriangle className="text-amber-400 shrink-0 mt-0.5" size={16} />
                  <div className="space-y-0.5 text-xs text-amber-400 leading-normal">
                    <span className="font-extrabold uppercase text-[9px] tracking-wider block">Security Protocol</span>
                    <p>Changing password forces logout on all secondary sessions. Choose a strong, verifiable passphrase.</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Current */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">Current Password</label>
                    <input
                      type={showPass ? "text" : "password"}
                      placeholder="••••••••"
                      value={currentPassword}
                      onChange={(e) => {
                        setCurrentPassword(e.target.value);
                        if (errors.currentPassword) setErrors(prev => { const n = {...prev}; delete n.currentPassword; return n; });
                      }}
                      className={`w-full bg-[#030304] border rounded-2xl px-4 py-3 text-xs text-white focus:outline-none ${
                        errors.currentPassword ? "border-rose-500/40 focus:border-rose-500" : "border-white/10 focus:border-indigo-500/50"
                      }`}
                    />
                    {errors.currentPassword && (
                      <p className="text-[10px] text-rose-400 font-sans mt-1">⚠️ {errors.currentPassword}</p>
                    )}
                  </div>

                  {/* New */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">New Password</label>
                    <input
                      type={showPass ? "text" : "password"}
                      placeholder="••••••••"
                      value={newPassword}
                      onChange={(e) => {
                        setNewPassword(e.target.value);
                        if (errors.newPassword) setErrors(prev => { const n = {...prev}; delete n.newPassword; return n; });
                      }}
                      className={`w-full bg-[#030304] border rounded-2xl px-4 py-3 text-xs text-white focus:outline-none ${
                        errors.newPassword ? "border-rose-500/40 focus:border-rose-500" : "border-white/10 focus:border-indigo-500/50"
                      }`}
                    />
                    {errors.newPassword && (
                      <p className="text-[10px] text-rose-400 font-sans mt-1">⚠️ {errors.newPassword}</p>
                    )}
                  </div>

                  {/* Verify */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-white/50 font-bold uppercase tracking-wider block font-sans">Verify Password</label>
                    <input
                      type={showPass ? "text" : "password"}
                      placeholder="••••••••"
                      value={confirmPassword}
                      onChange={(e) => {
                        setConfirmPassword(e.target.value);
                        if (errors.confirmPassword) setErrors(prev => { const n = {...prev}; delete n.confirmPassword; return n; });
                      }}
                      className={`w-full bg-[#030304] border rounded-2xl px-4 py-3 text-xs text-white focus:outline-none ${
                        errors.confirmPassword ? "border-rose-500/40 focus:border-rose-500" : "border-white/10 focus:border-indigo-500/50"
                      }`}
                    />
                    {errors.confirmPassword && (
                      <p className="text-[10px] text-rose-400 font-sans mt-1">⚠️ {errors.confirmPassword}</p>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setShowPass(!showPass)}
                    className="text-[10px] font-sans font-bold text-white/40 hover:text-white flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    {showPass ? <EyeOff size={11} /> : <Eye size={11} />}
                    <span>{showPass ? "Hide Passwords" : "Show Passwords"}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* GLOBAL ACTIONS BAR (SINGLE PERSISTENT CONTROL AT THE BOTTOM OF CARDS) */}
          <div className="max-w-3xl mx-auto flex items-center justify-end gap-3.5 pt-4 select-none">
            <button
              onClick={handleGlobalCancel}
              className="px-5 py-2.5 rounded-xl border border-white/10 bg-white/[0.01] hover:bg-white/[0.04] text-xs font-bold text-white/70 hover:text-white transition-all cursor-pointer active:scale-98"
            >
              Cancel
            </button>
            <button
              onClick={handleGlobalSave}
              className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-sans font-extrabold text-[11px] tracking-widest uppercase transition-all shadow-[0_4px_15px_rgba(79,70,229,0.25)] cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
            >
              <Check size={13} />
              <span>Save Changes</span>
            </button>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
